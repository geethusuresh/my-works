from __future__ import unicode_literals
from django.contrib.auth.models import User
from django.contrib.postgres.fields import JSONField
from django.db import models

from const import (EMPLOYEE_TYPE, TICKET_TYPE_LIST, NOTI_TYPE,
                   RESPONSE_CHOICES, RESOLUTION_CHOICES, STATUS_LIST,
                   MSG_SENT_TYPE, DIVISION_TYPE_CHOICE,
                   CLIENT_TYPE_CHOICE, WORK_LOCATION_CHOICE, COST_TYPE_CHOICE)


class Privilege(models.Model):
    """
        Privilege
    """
    privilege = models.TextField(max_length=30, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    rowstamp = models.IntegerField(default=1)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.privilege


class Customer(models.Model):

    """ Customer Details """

    customerid = models.CharField(max_length=5, null=True, blank=True,
                                  unique=True)
    customername = models.CharField(max_length=100, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    currency = models.CharField(null=True, blank=True, max_length=50)
    enterby = models.ForeignKey(User, null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    logo = models.FileField(upload_to='customer/logo/', null=True, blank=True)
    rowstamp = models.CharField(null=True, blank=True, max_length=100)
    from_time = models.TimeField(null=True, blank=True)
    to_time = models.TimeField(null=True, blank=True)
    help_text = models.CharField(max_length=100, null=True, blank=True)
    from_mailid = models.CharField(null=True, blank=True, max_length=300)
    default_timezone = models.CharField(max_length=100, null=True, blank=True)

    is_active = models.BooleanField(default=True)
    is_ldap_auth = models.BooleanField(default=True)
    allow_all_updations = models.BooleanField(default=False)
    is_send_mail = models.BooleanField(default=True)
    sr_approval_enabled = models.BooleanField(default=False)
    email_suppresed = models.BooleanField(default=False)
    cc_capture_email_ticket = models.BooleanField(default=False)
    category_change = models.BooleanField(default=False)
    reopen_closed_tickets = models.BooleanField(default=False)
    add_attachment = models.BooleanField(default=False)
    shrink_to_emails = models.BooleanField(default=False)
    send_attachments = models.BooleanField(default=False)
    edit_source = models.BooleanField(default=False)
    edit_location = models.BooleanField(default=False)

    def __str__(self):
        return self.customername

    class Meta:
        verbose_name_plural = "Customers"


class UserProfile(models.Model):

    """ Userprofile table to capture all the basic details of the users  """

    user = models.OneToOneField(User, on_delete=models.CASCADE,
                                primary_key=True)
    customer = models.ForeignKey(Customer, null=True, blank=True)
    gender = models.CharField(null=True, blank=True, max_length=20)
    status = models.CharField(null=True, blank=True, max_length=100)
    department = models.TextField(null=True, blank=True)
    title = models.CharField(null=True, blank=True, max_length=100)
    employeetype = models.CharField(null=True, blank=True, max_length=100,
                                    choices=EMPLOYEE_TYPE)
    jobcode = models.CharField(null=True, blank=True, max_length=100)
    lastvaldate = models.DateTimeField(null=True, blank=True)
    nextvaldate = models.DateTimeField(null=True, blank=True)
    hiredate = models.DateTimeField(null=True, blank=True)
    terminationdate = models.DateTimeField(null=True, blank=True)
    location = models.CharField(null=True, blank=True, max_length=50)
    locationsite = models.CharField(null=True, blank=True, max_length=50)
    mobile = models.CharField(blank=True, null=True, max_length=20)
    secondary_mobile = models.CharField(blank=True, null=True, max_length=20)
    delegate_person = models.ForeignKey('self', null=True, blank=True)
    is_delegated = models.NullBooleanField(default=None)
    delegate_fromdate = models.DateTimeField(null=True, blank=True)
    delegate_todate = models.DateTimeField(null=True, blank=True)
    addressline1 = models.TextField(null=True, blank=True)
    addressline2 = models.TextField(null=True, blank=True)
    city = models.CharField(null=True, blank=True, max_length=200)
    regiondistrict = models.CharField(null=True, blank=True, max_length=200)
    country = models.CharField(null=True, blank=True, max_length=200)
    postalcode = models.CharField(null=True, blank=True, max_length=30)
    locale = models.TextField(null=True, blank=True)
    user_timezone = models.CharField(null=True, blank=True, max_length=100)
    rowstamp = models.TextField(null=True, blank=True)
    password_key = models.CharField(null=True, blank=True, max_length=50)
    notify = models.BooleanField(default=True)
    is_admin = models.NullBooleanField(default=False, null=True, blank=True)
    image = models.FileField(upload_to="customer/user/", null=True, blank=True)
    is_devel_admin = models.BooleanField(default=False, blank=True)
    work_station = models.CharField(max_length=300, null=True, blank=True)
    is_vip = models.BooleanField(default=False)
    cust_access = models.ManyToManyField(Customer, related_name="cust_pem")

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural = "UserProfiles"


class RolePrivilege(models.Model):
    customer = models.ForeignKey(Customer, null=True, blank=True)
    privileges = models.ManyToManyField(Privilege)
    members = models.ManyToManyField(UserProfile)
    rolename = models.TextField(null=True, blank=True, max_length=30)

    description = models.TextField(null=True, blank=True)
    rowstamp = models.TextField(null=True, blank=True)


class Workgroup(models.Model):

    ''' Workgroup are added here '''

    customer = models.ForeignKey(Customer, null=True, blank=True)
    workgroup = models.CharField(max_length=50, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    rowstamp = models.IntegerField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.workgroup

    class Meta:
        verbose_name_plural = "Groups"


class Subgroup(models.Model):

    """ Subgroup """

    workgroup = models.ForeignKey(Workgroup)
    subgroupname = models.CharField(max_length=50, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    rowstamp = models.IntegerField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    group_leader = models.ForeignKey(UserProfile, null=True, blank=True,
                                     related_name="leader")
    subgroup_members = models.ManyToManyField(
                        UserProfile, blank=True,
                        related_name="subgroup_members")

    def __str__(self):
        return self.subgroupname + " - " + \
         self.workgroup.workgroup + " - " + \
         self.workgroup.customer.customername

    class Meta:
        verbose_name_plural = "Subgroups"


class Category(models.Model):

    """ Category """

    customer = models.ForeignKey(Customer, null=True, blank=True)
    name = models.TextField(max_length=30)
    parent = models.IntegerField()
    description = models.TextField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = "Ticket Category"

    def __unicode__(self):
        return self.name


class TicketLocation(models.Model):

    """ Table to Store TicketLocation """
    customer = models.ForeignKey(Customer)
    name = models.TextField(null=True, blank=True)

    def __str__(self):
        return str(self.name)


class ResolutionCode(models.Model):

    """ Resolution Code  """

    created_by = models.ForeignKey(UserProfile, null=True, blank=True)
    customer = models.ForeignKey(Customer, null=True, blank=True)
    code_name = models.CharField(max_length=100, null=True, blank=True)
    code_description = models.TextField(null=True, blank=True)
    created_date = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return str(self.customer.customername)+str(" - ") + str(self.code_name)

    class Meta:
        verbose_name_plural = "Resolution Code"


class TimeShift(models.Model):
    name = models.TextField(null=True, blank=True)
    from_time = models.TimeField(null=True, blank=True)
    to_time = models.TimeField(null=True, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Time Shift"


class SLA(models.Model):
    customer = models.ForeignKey(Customer, null=True, blank=True)
    name = models.CharField(max_length=30, null=True, blank=True)
    condition = models.TextField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    table = models.CharField(max_length=100, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    sla_value = models.IntegerField(default=0)
    time_shift = models.ForeignKey(TimeShift, null=True, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Servive Lic Agreement"


class CustomerPriority(models.Model):

    """ Dynamic customer priority """

    customer = models.ForeignKey(Customer, null=True, blank=True)
    created_by = models.ForeignKey(UserProfile, null=True, blank=True)
    ticket_type = models.CharField(
                null=True, blank=True, choices=TICKET_TYPE_LIST, max_length=50)
    priority = models.CharField(max_length=40, null=True, blank=True)
    created_date = models.DateTimeField(auto_now_add=True, null=True,
                                        blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return str(self.priority)

    class Meta:
        verbose_name_plural = "Customer Priority"


class CustomerSeverity(models.Model):

    """ Customer Severity """

    created_by = models.ForeignKey(UserProfile, null=True, blank=True)
    customer_priority = models.ForeignKey(
                                CustomerPriority, null=True, blank=True)
    customer = models.ForeignKey(Customer, null=True, blank=True)
    severity = models.TextField(null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return str(self.customer.customername) + str(" - ") + \
         str(self.severity)


class Ticket(models.Model):

    """ Core Ticket Table  """

    category = models.ForeignKey(Category, null=True, blank=True,
                                 related_name="category")
    subcategory = models.ForeignKey(Category, null=True, blank=True,
                                    related_name="subcategory")
    reportedby = models.ForeignKey(UserProfile, null=True,
                                   related_name="reportedby")
    affectedperson = models.ForeignKey(UserProfile, null=True, blank=True)
    owner = models.ForeignKey(UserProfile, null=True, blank=True,
                              related_name="tick_owner")
    group = models.ForeignKey(Workgroup, null=True, related_name="group")
    subgroup = models.ForeignKey(Subgroup, null=True, related_name="sub")
    customer = models.ForeignKey(Customer, null=True, blank=True)
    modifiedperson = models.ForeignKey(UserProfile, null=True, blank=True,
                                       related_name="modifiedperson")
    sla = models.ForeignKey(SLA, null=True, blank=True)
    priority = models.ForeignKey(CustomerPriority, null=True, blank=True)
    severity = models.ForeignKey(CustomerSeverity, null=True, blank=True)
    ticket_location = models.ForeignKey(TicketLocation, blank=True, null=True)
    resolution_cod = models.ForeignKey(ResolutionCode, null=True, blank=True)

    ticketid = models.CharField(max_length=40, null=True, blank=True)
    ticket_cls = models.CharField(max_length=12, null=True, blank=True)
    summary = models.TextField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    html_description = models.TextField(null=True, blank=True)
    status = models.CharField(null=True, max_length=40, blank=True)
    approve = models.CharField(null=True, max_length=40, blank=True)
    reportedpriority = models.CharField(null=True, max_length=40, blank=True)

    created = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    reportdate = models.DateTimeField(null=True, blank=True)
    targetstart = models.DateTimeField(null=True, blank=True)
    targetfinish = models.DateTimeField(null=True, blank=True)
    actualstart = models.DateTimeField(null=True, blank=True)
    actualfinish = models.DateTimeField(null=True, blank=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    closedate = models.DateTimeField(null=True, blank=True)
    last_modified = models.DateTimeField(auto_now=True, null=True, blank=True)

    source = models.CharField(max_length=40, null=True, blank=True)
    isglobal = models.BooleanField(default=False)
    is_important = models.BooleanField(default=False)

    affectedemail = models.TextField(null=True, blank=True)
    reportedemail = models.TextField(null=True, blank=True)
    accumulatedholdtime = models.FloatField(default=0)
    rowstamp = models.IntegerField(default=0)
    flag = models.CharField(max_length=40, null=True, blank=True)


class TicketAttribute(models.Model):
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    project = models.TextField(null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    division = models.CharField(
                            max_length=20, null=True, blank=True,
                            choices=DIVISION_TYPE_CHOICE)
    requster_name = models.CharField(max_length=200, null=True, blank=True)
    account_manager = models.CharField(max_length=200, null=True, blank=True)
    client_name = models.CharField(max_length=200, null=True, blank=True)
    client_address = models.TextField(null=True, blank=True)
    client_type = models.CharField(
                                max_length=20, null=True, blank=True,
                                choices=CLIENT_TYPE_CHOICE)
    description = models.TextField(null=True, blank=True)
    work_location = models.CharField(max_length=20, null=True, blank=True,
                                     choices=WORK_LOCATION_CHOICE)
    cost_type = models.CharField(max_length=20, null=True, blank=True,
                                 choices=COST_TYPE_CHOICE)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    deal = models.CharField(max_length=500, null=True, blank=True)

    def __str__(self):
        return self.ticket.ticketid


class Worklog(models.Model):
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    owner = models.ForeignKey(UserProfile, null=True, blank=True)
    notify = models.CharField(null=True, blank=True, max_length=5)
    flag = models.CharField(max_length=40, null=True, blank=True)
    note = models.TextField(null=True, blank=True)
    ticket_status = models.CharField(max_length=40, null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    remark = models.TextField(null=True, blank=True)
    from_group = models.CharField(max_length=100, null=True, blank=True)
    from_subgroup = models.CharField(max_length=100, null=True, blank=True)
    to_group = models.CharField(max_length=100, null=True, blank=True)
    to_subgroup = models.CharField(max_length=100, null=True, blank=True)
    priority = models.CharField(max_length=100, null=True, blank=True)
    attachment = models.FileField(
        upload_to='t_attachment/%Y/%m/%d', null=True, blank=True,
        max_length=500)
    html_description = models.TextField(null=True, blank=True)
    is_read = models.BooleanField(default=False)
    read_by = models.ForeignKey(
            UserProfile, null=True, blank=True, related_name='worklog_read_by')
    read_on = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.ticket.ticketid

    def __unicode__(self):
        return self.ticket.ticketid

    class Meta:
        verbose_name_plural = "Ticket Worklogs"


class AlertMessage(models.Model):

    """ Alert Message """

    title = models.CharField(max_length=50, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    is_active = models.NullBooleanField(default=False, null=True, blank=True)
    viewable_custs = models.ManyToManyField(Customer, blank=True)

    def __str__(self):
        return self.title


class CustTicketSource(models.Model):
    """
       Model to store the source
    """
    name = models.CharField(max_length=100, null=True, blank=True)
    customer = models.ForeignKey(Customer)
    source_image = models.ImageField(
            'Source Logo', upload_to='source/logo', null=True, blank=True,
            help_text='(Image size should be '+str(91)+"x"+str(90)+' pixels)')
    color_code = models.CharField(
                            'Color Code', max_length=50, null=True, blank=True)

    def __str__(self):
        return str(self.name)


class DashboardFilter(models.Model):
    """
        Table dashboard filter
    """
    filter_name = models.TextField(null=True, blank=True)
    table_name = models.TextField(null=True, blank=True)
    customer = models.ForeignKey(Customer, null=True, blank=True)
    filter_condition = models.TextField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.filter_name


class AdminSettingsLog(models.Model):
    """
        Capture data changes
    """
    who_added = models.ForeignKey(UserProfile, null=True, blank=True)
    added_time = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    affected_model = models.TextField(null=True, blank=True)
    field_name = models.TextField(null=True, blank=True)
    old_value = models.TextField(null=True, blank=True)
    new_value = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.who_added


class ScriptNotifyMail(models.Model):
    """
        Mail details
    """
    script_name = models.TextField(null=True, blank=True)
    to_email = models.TextField(null=True, blank=True)
    cc_email = models.TextField(null=True, blank=True)
    bcc_email = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.script_name


class Notitype(models.Model):
    """
        Notification Types
    """
    name = models.CharField(choices=NOTI_TYPE, max_length=20, null=True,
                            blank=True, unique=True)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name


class Notification(models.Model):
    """
        Saves the notifications related to each user
    """
    user = models.ForeignKey(UserProfile, null=True, blank=True)
    notify = models.TextField(null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    os = models.CharField(max_length=20, null=True, blank=True)
    browser = models.CharField(max_length=20, null=True, blank=True)
    visibility = models.BooleanField(default=False)
    is_login = models.BooleanField(default=False)
    ip = models.CharField(max_length=20, null=True, blank=True)
    country = models.CharField(max_length=50, null=True, blank=True)
    unread = models.BooleanField(default=True)
    type_of = models.ForeignKey(Notitype, null=True, blank=True)

    def __str__(self):
        return self.user.user.username


class NotiPreference(models.Model):
    """
        Notification visibility settings
    """
    user = models.OneToOneField(UserProfile, null=True, blank=True)
    notifications = models.ManyToManyField(Notitype)

    def __str__(self):
        return self.user.user.username


class FavouriteTicket(models.Model):
    """
        Mark a ticket as favourite
    """
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    profile = models.ForeignKey(UserProfile, null=True, blank=True)


class TicketResponseDetails(models.Model):

    """ This table handles the ticket response details.
        This table is updated on daily basis by management command to reduce
        report fetching time
    """
    ticketid = models.ForeignKey(Ticket)
    response_status = models.NullBooleanField(blank=True, default=None,
                                              null=True,
                                              choices=RESPONSE_CHOICES)
    responded_time = models.TextField(blank=True, null=True)
    response_duration = models.TextField(blank=True, null=True)
    created_on = models.DateTimeField(auto_now_add=True)
    modifed_on = models.DateTimeField(auto_now=True)
    priority = models.TextField(blank=True, null=True)
    resolution_status = models.NullBooleanField(
            blank=True, default=None, null=True,  choices=RESOLUTION_CHOICES)
    resolution_duration = models.TextField(blank=True, null=True)
    resolution_time = models.TextField(blank=True, null=True)
    _tabular_report = JSONField()
    _popup_report = JSONField()

    def __str__(self):
        return self.priority


class CustomizeTable(models.Model):
    """
    Customize table columns
    """
    name = models.CharField(max_length=200, null=True, blank=True)
    is_active = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Customize Table"


class FaqCategory(models.Model):
    """
    FaqCategory
    """
    category = models.TextField(null=True, blank=True)
    createtime = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    isvalid = models.BooleanField(default=True)
    customer = models.ForeignKey(Customer, null=True, blank=True)

    def __unicode__(self):
        return self.category

    class Meta:
        verbose_name_plural = "Faq Category"


class FaqSubcategory(models.Model):
    """
    FaqSubcategory
    """
    category = models.ForeignKey(FaqCategory, null=True, blank=True)
    subcategory = models.TextField(null=True, blank=True)
    createtime = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    isvalid = models.BooleanField(default=True)

    def __unicode__(self):
        return self.subcategory

    class Meta:
        verbose_name_plural = "Faq subCategory"


class FaqDetails(models.Model):
    """
    FaqDetails
    """
    faqquestion = models.TextField(null=True, blank=True)
    faqanswer = models.TextField(null=True, blank=True)
    faqattachment = models.FileField(upload_to="faq", null=True, blank=True)
    category = models.ForeignKey(FaqCategory, null=True, blank=True)
    faqtitle = models.TextField(null=True, blank=True)
    subcategory = models.ForeignKey(FaqSubcategory, null=True, blank=True)
    faqkeyword = models.TextField(null=True, blank=True)

    def __unicode__(self):
        return self.faqquestion

    class Meta:
        verbose_name_plural = "Faq Details"


class FaqImages(models.Model):
    """
    FaqImages
    """
    faq = models.ForeignKey(FaqDetails, null=True, blank=True)
    faqimage = models.FileField(upload_to='faq/images/', null=True, blank=True)
    category = models.ForeignKey(FaqCategory, null=True, blank=True)
    subcategory = models.ForeignKey(FaqSubcategory, null=True, blank=True)
    enabledisable = models.BooleanField(default=True)

    def __unicode__(self):
        return self.faq.faqquestion

    class Meta:
        verbose_name_plural = "Faq Image Details"


class Dummy_images(models.Model):
    """
    Dummy images
    """
    faq_search = models.FileField(upload_to='faq/images/users_search_images',
                                            null=True, blank=True)


class SlaTicketHistory(models.Model):
    """
    SlaTicketHistory
    """
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    sla = models.ForeignKey(SLA, null=True, blank=True)
    applied_date = models.DateTimeField(auto_now_add=True,
                                        null=True, blank=True)

    def __unicode__(self):
        return self.ticket.ticketid

    class Meta:
        verbose_name_plural = "SLA Active"


class KnowledgeBaseDB(models.Model):
    """
    Knowledge Base DB
    """
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    customer = models.ForeignKey(Customer)
    approver = models.ForeignKey(UserProfile, null=True, blank=True,
                                 related_name="approver")
    submited_person = models.ForeignKey(UserProfile, null=True, blank=True,
                                        related_name="submitted_person")
    symptom = models.TextField(null=True, blank=True)
    cause = models.TextField(null=True, blank=True)
    resolution = models.TextField(null=True, blank=True)
    is_global = models.BooleanField(default=False)
    visits = models.IntegerField(default=0, null=True, blank=True)
    created_date = models.DateTimeField(auto_now_add=True, null=True,
                                        blank=True)
    reviewed_date = models.DateTimeField(null=True, blank=True)
    is_approved = models.NullBooleanField(default=None, blank=True)
    approved_date = models.DateTimeField(null=True, blank=True)
    remarks_by_approver = models.TextField(null=True, blank=True)
    modified_date = models.DateTimeField(auto_now=True, null=True, blank=True)

    def __unicode__(self):
        return self.symptom

    class Meta:
        verbose_name_plural = "Knowledge Base"


class EmailCommunicationTemplate(models.Model):
    """
    EmailCommunication Template
    """
    customer = models.ForeignKey(Customer)
    templatename = models.CharField(null=True, blank=True, max_length=100)
    templatebody = models.TextField(null=True, blank=True)
    templatesubject = models.CharField(null=True, blank=True, max_length=150)

    def __unicode__(self):
        return self.templatename

    class Meta:
        verbose_name_plural = "Email Templates"


class EmailLog(models.Model):
    """
    Email Log
    """
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    sent_time = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    from_email = models.TextField(null=True, blank=True)
    to_addresses = models.TextField(null=True, blank=True)
    cc_address = models.TextField(null=True, blank=True)
    bcc_address = models.TextField(null=True, blank=True)
    subject = models.TextField(null=True, blank=True)
    body = models.TextField(null=True, blank=True)
    status = models.BooleanField(default=False)

    def __unicode__(self):
        if self.ticket:
            return str(self.ticket.ticketid)
        else:
            return str(self.id)

    class Meta:
        verbose_name_plural = "Email Log"


class EmailCron(models.Model):
    """
    Email Cron
    """
    customer = models.ForeignKey(Customer)
    workgroup = models.ForeignKey(Workgroup, null=True, blank=True)
    subgroup = models.ForeignKey(Subgroup, null=True, blank=True)
    category = models.ForeignKey(Category, null=True, blank=True)
    customer_priority = models.ForeignKey(CustomerPriority, null=True,
                                          blank=True)
    server = models.TextField(null=True, blank=True)
    protocol = models.TextField(null=True, blank=True)
    port = models.TextField(null=True, blank=True)
    login = models.TextField(null=True, blank=True)
    paswd = models.TextField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    from_email = models.TextField(null=True, blank=True)
    ticket_type = models.CharField(max_length=10, null=True, blank=True,
                                   choices=TICKET_TYPE_LIST)
    default_ticket_assign = models.BooleanField(default=False)

    def __unicode__(self):
        return self.customer.customername

    class Meta:
        verbose_name_plural = "Email Cron"


class RegisterVerification(models.Model):
    """
    Register Verification
    """
    email = models.TextField(null=True, blank=True)
    invitation_sent = models.DateTimeField(null=True, blank=True)
    is_verified = models.BooleanField(default=False)
    verified_on = models.DateTimeField(null=True, blank=True)
    key_val = models.CharField(max_length=50, null=True, blank=True)

    def __unicode__(self):
        return self.email

    class Meta:
        verbose_name_plural = 'Register Verification'


class WorklogReplyHistory(models.Model):
    """
    worklog reply history
    """
    worklog = models.ForeignKey(Worklog, null=True, blank=True)
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    body_content = models.TextField(null=True, blank=True)
    cc_email = models.TextField(null=True, blank=True)
    to_email = models.TextField(null=True, blank=True)
    subject = models.TextField(null=True, blank=True)
    send_on = models.DateTimeField(auto_now_add=True, null=True, blank=True)

    def __unicode__(self):
        return str(self.subject)

    class Meta:
        verbose_name_plural = 'Worklog Reply History'


class TicketAttachments(models.Model):

    """ Attachments for a ticket and worklog"""

    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    uploader = models.ForeignKey(UserProfile, null=True, blank=True)
    attachname = models.TextField(null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    attachment = models.FileField(
                    upload_to='t_attachment/%Y/%m/%d', max_length=250)
    ticket_attachment_type = models.TextField(null=True, blank=True)
    worklog = models.ForeignKey(Worklog, null=True, blank=True)

    def __str__(self):
        return self.ticket.ticketid if self.ticket else "None"


class Visitors(models.Model):

    """ Frequency of ticket visiting is captured here """

    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    visitor = models.ForeignKey(UserProfile, null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True, null=True, blank=True)

    def __str__(self):
        return self.visitor.user.username

    class Meta:
        verbose_name_plural = "Ticket Visitors"


class Approval(models.Model):

    """ Details regarding ticket Approval """

    approver = models.ForeignKey(UserProfile, null=True, blank=True)
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    approve = models.NullBooleanField(default=None, null=True, blank=True)
    note = models.TextField(null=True, blank=True)
    approval_type = models.TextField(null=True, blank=True)
    cc_field = models.TextField(null=True, blank=True)
    created_date = models.DateTimeField(auto_now_add=True, null=True,
                                        blank=True)
    approved_date = models.DateTimeField(null=True, blank=True)
    status = models.NullBooleanField(default=None, null=True, blank=True)

    def __str__(self):
        return str(self.ticket.ticketid)

    class Meta:
        verbose_name_plural = "Ticket Approvals"


class EmailSendHistory(models.Model):
    """
    Email Send History for auto approval reminder
    """
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    user = models.ForeignKey(User, null=True, blank=True)
    approval = models.ForeignKey(Approval, null=True, blank=True)
    msg_sent_type = models.CharField(
                max_length=100, choices=MSG_SENT_TYPE, null=True, blank=True)
    status = models.BooleanField(default=False)

    def __unicode__(self):
        return str(self.msg_sent_type)

    class Meta:
        verbose_name_plural = 'Email Sent History'


class ServiceCatalog(models.Model):

    """ Table to store all Privilege wise Service Catalogs """

    customer = models.ForeignKey(Customer, null=True)
    category = models.ForeignKey(
                Category, null=True, blank=True, related_name="Category")
    subcategory = models.ForeignKey(
                Category, null=True, blank=True, related_name="subCategory")
    privilege = models.ForeignKey(Privilege, null=True, blank=True)
    summary = models.TextField(null=True, blank=True)
    text = models.TextField(null=True, blank=True)

    is_approval_needed = models.BooleanField(default=False)

    def __str__(self):
        return self.summary

    class Meta:
        verbose_name_plural = "Service Catalog"


class LdapAuthSettings(models.Model):

    """ Ldap Auth Settings """

    customer = models.ForeignKey(Customer)
    ldapserverip = models.TextField(null=True, blank=True, max_length=100)
    ldapbasedn = models.TextField(null=True, blank=True, max_length=100)
    ldapusername = models.TextField(null=True, blank=True, max_length=100)
    ldappassword = models.TextField(null=True, blank=True, max_length=30)
    ldapsearchfilter = models.TextField(null=True, blank=True, max_length=200)
    ldapsearchattribute = models.TextField(
                                        null=True, blank=True, max_length=200)

    def __str__(self):
        return self.ldapserverip

    class Meta:
        verbose_name_plural = "Ldap Settings"


class StatusLabel(models.Model):

    """ Customer wise Status Labels """

    customer = models.ForeignKey(Customer, null=True, blank=True)
    added_by = models.ForeignKey(UserProfile, null=True, blank=True)
    status = models.CharField(
                    max_length=25, null=True, blank=True, choices=STATUS_LIST)
    status_label = models.CharField(max_length=45, null=True, blank=True)
    created_date = models.DateTimeField(auto_now_add=True, null=True,
                                        blank=True)

    def __str__(self):

        return self.status_label

    class Meta:
        verbose_name_plural = "Status Labels"


class DeactivationDetails(models.Model):

    """ User Deactivation Details """

    deactivation_reason = models.TextField(null=True, blank=True)
    deactivation_date = models.DateTimeField(null=True, blank=True)
    activation_date = models.DateTimeField(null=True, blank=True)
    activation_reason = models.TextField(null=True, blank=True)


class UserDeactivation(models.Model):

    """ Contents of UserDeactivated """

    user = models.ForeignKey(UserProfile, null=True, blank=True)
    details = models.ManyToManyField(DeactivationDetails, blank=True)

    def __str__(self):
        return self.user.user.email


class DeactivateList(models.Model):

    """ DeactivateList """

    user = models.ForeignKey(UserProfile, null=True, blank=True)
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    status = models.TextField(null=True, blank=True)
    reason = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.user.user.email


class UserDelegationHistory(models.Model):

    """ User Delegation History """

    user = models.ForeignKey(UserProfile, null=True, blank=True)
    created_date = models.DateTimeField(auto_now_add=True)
    reason = models.TextField(null=True, blank=True)


class Relatedtickets(models.Model):

    """ Related Tickets """

    parent = models.ForeignKey(
                            Ticket, null=True, blank=True, related_name="one")
    child = models.ForeignKey(
                            Ticket, null=True, blank=True, related_name="two")
    person = models.ForeignKey(UserProfile, null=True, blank=True)
    is_global = models.BooleanField(default=False)
    date = models.DateTimeField(auto_now_add=True, null=True, blank=True)

    def __str__(self):
        return self.ticketone.summary


class TicketHistory(models.Model):

    """ Ticket History """

    user = models.ForeignKey(UserProfile, null=True, blank=True)
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    status = models.TextField(null=True, blank=True)
    time = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    spendtime = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.ticket.ticketid

    class Meta:

        ordering = ['-time']


class ResolvedKBDetails(models.Model):
    ticket = models.ForeignKey(Ticket)
    symptom = models.TextField(null=True, blank=True)
    cause = models.TextField(null=True, blank=True)
    resolution = models.TextField(null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "{0}".format(self.symptom)


class TicketResolution(models.Model):
    ticket = models.ForeignKey(Ticket, null=True, blank=True)
    user = models.ForeignKey(UserProfile, null=True, blank=True)
    workgroup = models.ForeignKey(Workgroup, null=True, blank=True)
    plan_subgroup = models.ForeignKey(Subgroup, null=True, blank=True)
    sla = models.ForeignKey(SLA, null=True, blank=True)
    customer_priority = models.ForeignKey(
                                    CustomerPriority, null=True, blank=True)
    severity = models.ForeignKey(CustomerSeverity, null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    time_taken = models.FloatField(null=True, blank=True, default=0)
    time_used = models.FloatField(default=0)

    def __str__(self):
        return self.ticket.ticketid
