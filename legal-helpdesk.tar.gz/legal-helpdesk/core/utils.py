import datetime

from django.apps import apps


class ModelDiff(object):

    def __init__(self, new_obj_data, id_val, model_name, app_name):
        """
            new_obj_data - indicated for the changed values
            id_val - id of the object, used to fetch the old values
            model_name - name of the model you need to check
            app_name - name of the app in which the model resides
        """
        self.d2 = new_obj_data.__dict__
        model = apps.get_model(app_name, model_name)
        if id_val:
            self.model_obj = model.objects.get(id=id_val)
            self.d1 = self.model_obj.__dict__

    def _model_dict(self):

        dict_val = dict(
            (x.name, getattr(self.model_obj, x.name))
            for x in self.model_obj._meta.fields)
        return dict_val

    def has_changed(self):

        diff_dat_list = self.diff_data()
        if len(diff_dat_list) > 0:
            return True
        else:
            return False

    def diff_data(self):

        diffs = [{'field_value': k, 'old': v, 'new': self.d2[k]}
                 for k, v in self.d1.items()
                 if type(v) != datetime.datetime and v != self.d2[k]]
        date_diffs = [
         {'field_value': k, 'old': v, 'new': self.d2[k]}
         for k, v in self.d1.items() if type(v) == datetime.datetime and
         v.replace(tzinfo=None) != self.d2[k].replace(tzinfo=None)]
        if len(date_diffs) > 0:
            diffs.extend(date_diffs)
        diffs[:] = [d for d in diffs if d.get('field_value') != '_state']
        self.list_val = diffs
        return self.list_val

    def new_model_diff_data(self):
        # fetching the field value details of the newly created object
        diffs = [
            {'field_value': k, 'old': '', 'new': v}
            for k, v in self.d2.items() if k != '_state']
        return diffs
