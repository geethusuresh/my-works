from django.conf.urls import url
# from django.contrib.auth.decorators import login_required

from . import views
from admin_settings import (
    CreateCategory, PrivilegeManagement, CreatePrivilege, PrivilegeList,
    Common_List, RoleManagement, RoleList, CustomerManagement, CustomerList,
    CreateCustomer, CreateRole, AddPrivilegeRole, GetUsers, AddMemberRole,
    DeleteRole)
from core.models import Category

urlpatterns = [
    url(r'^$', views.DashboardView.as_view(), name='dashboard'),
    url(r'^login/$', views.LoginAuthenticate.as_view(), name='login'),
    url(r'^logout/$', views.logout_view, name='logout'),
    url(r'^settings/privilege_management/$',
        PrivilegeManagement.as_view(), name='privilege_management'),
    url(r'^settings/privilege/all/$', PrivilegeList.as_view(),
        name='privilege_list'),
    url(r'^settings/privileges/create/$',
        CreatePrivilege.as_view(), name='create_privilege'),
    url(r'^settings/role_management/$', RoleManagement.as_view(),
        name='role_management'),
    url(r'^settings/users/all/$', GetUsers.as_view(), name='users_list'),
    url(r'^settings/role/all/$', RoleList.as_view(), name='role_list'),
    url(r'^settings/roles/create/$', CreateRole.as_view(), name='create_role'),
    url(r'^settings/roles/delete/(?P<role_id>\d+)/$',
        DeleteRole.as_view(), name='create_role'),
    url(r'^settings/roles/(?P<role_id>\d+)/add/privilege/$',
        AddPrivilegeRole.as_view(), name='add_privilege_to_role'),
    url(r'^settings/roles/(?P<role_id>\d+)/add/members/$',
        AddMemberRole.as_view(), name='add_user_to_role'),
    url(r'^settings/customer_management/$', CustomerManagement.as_view(),
        name='customer_management'),
    url(r'^settings/customers/create/$', CreateCustomer.as_view(),
        name='create_customer'),
    url(r'^settings/customer/all/$', CustomerList.as_view(),
        name='customer_list'),
    url(r'^create_category/(?P<customer_id>\d+)/$',
        CreateCategory.as_view(), name='add-categories'),
    url(r'category/list', Common_List.as_view(model=Category),
        name='category-list'),
]
