import json
import pytz
import ast
from datetime import datetime
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.views.generic import View, TemplateView, ListView

from .support import UserPrivilegeCheck
#  AssignEmailTemplate, AddToSettingsLog,

from core.models import (
    Customer, Privilege, RolePrivilege, Category,
    UserProfile)


class PrivilegeManagement(TemplateView):

    template_name = 'settings/privilege_management.html'

    def get_context_data(self, **kwargs):
        context = super(PrivilegeManagement, self).get_context_data(**kwargs)
        return context


class PrivilegeList(View):

    def get(self, request):
        priv_list = Privilege.objects.all()
        privileges = []
        if request.is_ajax() and request.GET.get('json'):
            if request.GET.get('role_id'):
                existing_privileges = RolePrivilege.objects.get(
                    id=request.GET['role_id']).privileges.all()
                if existing_privileges:
                    privileges = priv_list.exclude(
                        id__in=existing_privileges.values_list('id', flat=True)
                    ).values('id', 'privilege')
                else:
                    privileges = priv_list.values('id', 'privilege')
                list_data = {
                    'privs': list(privileges),
                    'existing': list(existing_privileges.values(
                        'id', 'privilege'))
                }
                return HttpResponse(
                    json.dumps(list_data), content_type="application/json")
            else:
                privileges = priv_list.values(
                    'id', 'privilege', 'description')
                list_data = {
                    'privs': list(privileges)
                }
                return HttpResponse(
                    json.dumps(list_data), content_type="application/json")
        return HttpResponseRedirect("/")


class CreatePrivilege(View):

    def post(self, request):
        try:
            Privilege.objects.get(privilege=request.POST['name'])
            if self.request.is_ajax():
                response_data = {'response': 'error',
                                 'message': 'Privilege already exists'}
                return HttpResponse(
                    json.dumps(response_data), content_type="application/json")
            messages.error(request, "Privilege already exists")
        except:
            new_priv = Privilege.objects.create(
                privilege=request.POST['name'],
                description=request.POST['desc'])
            if self.request.is_ajax():
                new = {
                    'id': new_priv.id,
                    'privilege': new_priv.privilege,
                    'description': new_priv.description
                }
                response_data = {'response': 'ok', 'new': new}
                return HttpResponse(
                    json.dumps(response_data), content_type="application/json")
            messages.success(request, "Successfully created the privilege")
        return HttpResponseRedirect(request.META['HTTP_REFERER'])


class CustomerManagement(TemplateView):

    template_name = 'settings/customer_management.html'

    def get_context_data(self, **kwargs):
        context = super(CustomerManagement, self).get_context_data(**kwargs)
        return context


class CustomerList(View):

    def get(self, request):
        customers = Customer.objects.all().values(
            'id', 'customername', 'customerid', 'default_timezone')
        timezone_list = pytz.all_timezones
        if request.is_ajax() and request.GET.get('json'):
            list_data = {
                'customers': list(customers),
                'timezones': timezone_list
            }
            return HttpResponse(
                json.dumps(list_data), content_type="application/json")
        return HttpResponseRedirect("/")


class CreateCustomer(View):

    def post(self, request):

        data = ast.literal_eval(request.POST['customer_details'])
        is_active = True if data['is_active'] == 'yes' else False
        is_ldap_auth = True if data['is_ldap_auth'] == 'yes' else False
        sr_appr_enabled = True if data['is_sr_approval'] == 'yes' else False
        allow_updations = True if data['is_all_updation'] == 'yes' else False
        is_cat_change = True if data['is_category_change'] == 'yes' else False
        try:
            customer = Customer.objects.get(customerid=data['customerid'])
            return HttpResponse(
                    json.dumps({
                        'response': 'error',
                        'msg': "Customer already exists"}),
                    content_type="application/json")
        except:
            customer = Customer.objects.create(
                customername=data['customername'],
                customerid=data['customerid'],
                description=data['cust_desc'],
                currency=data['currency'],
                help_text=data['help_text'],
                from_mailid=data['from_mail_id'],
                default_timezone=data['default_timezone'],
                enterby=request.user,
                created=datetime.now(),
                is_active=is_active,
                is_ldap_auth=is_ldap_auth,
                sr_approval_enabled=sr_appr_enabled,
                allow_all_updations=allow_updations,
                category_change=is_cat_change,
            )
            if request.FILES:
                customer.logo = request.FILES['logo']
                customer.save()
            new = {
                'id': customer.id,
                'customername': customer.customername,
                'customerid': customer.customerid,
                'default_timezone': customer.default_timezone
            }
            return HttpResponse(
                    json.dumps({'response': 'ok', 'new': new}),
                    content_type="application/json")


class RoleManagement(TemplateView):

    template_name = "settings/role_management.html"

    def get_context_data(self, **kwargs):
        context = super(RoleManagement, self).get_context_data(**kwargs)
        return context


class RoleList(View):

    def get(self, request):
        roles = RolePrivilege.objects.all().values(
            'id', 'rolename', 'description', 'customer__id',
            'customer__customername')
        if request.is_ajax() and request.GET.get('json'):
            list_data = {
                'roles': list(roles)
            }
            return HttpResponse(
                json.dumps(list_data), content_type="application/json")
        return HttpResponseRedirect("/")


class CreateRole(View):

    def post(self, request):
        data = ast.literal_eval(request.POST['role_details'])
        customer = Customer.objects.get(id=data['customer']['id'])
        try:
            RolePrivilege.objects.get(
                customer=customer, rolename=data['name'])
            return HttpResponse(
                    json.dumps({
                        'response': 'error',
                        'msg': "Role already exists"}),
                    content_type="application/json")
        except:
            role = RolePrivilege.objects.create(
                customer=customer, rolename=data['name'],
                description=data['desc'])
            new = {
                'id': role.id,
                'rolename': role.rolename,
                'description': role.description,
                'customer__id': role.customer.id,
                'customer__customername': role.customer.customername
            }
            return HttpResponse(
                    json.dumps({'response': 'ok', 'new': new}),
                    content_type="application/json")


class AddPrivilegeRole(View):

    def post(self, request, role_id):
        try:
            role = RolePrivilege.objects.get(id=role_id)
            role.privileges.clear()
            privs_data = ast.literal_eval(request.POST['privs'])
            for priv in privs_data:
                priv_data = Privilege.objects.get(id=priv['id'])
                role.privileges.add(priv_data)
                role.save()
            return HttpResponse(
                    json.dumps({'response': 'ok',
                                'msg': 'Successfully updated the privilege '}),
                    content_type="application/json")
        except Exception as ex:
            print str(ex)
            return HttpResponse(
                    json.dumps({'response': 'error',
                                'msg': 'Something went wrong '}),
                    content_type="application/json")


class AddMemberRole(View):

    def post(self, request, role_id):
        try:
            role = RolePrivilege.objects.get(id=role_id)
            role.members.clear()
            users_data = ast.literal_eval(request.POST['users'])
            for usr in users_data:
                usr_data = UserProfile.objects.get(pk=usr['pk'])
                role.members.add(usr_data)
                role.save()
            return HttpResponse(
                    json.dumps({'response': 'ok',
                                'msg': 'Successfully updated the members '}),
                    content_type="application/json")
        except Exception as ex:
            print str(ex)
            return HttpResponse(
                    json.dumps({'response': 'error',
                                'msg': 'Something went wrong '}),
                    content_type="application/json")


class GetUsers(View):
    def get(self, request):
        if request.GET.get('role_id') and request.GET.get('person_role'):
            role = RolePrivilege.objects.get(id=request.GET.get('role_id'))
            profiles = UserProfile.objects.filter(
                cust_access__id=role.customer.id, user__email__isnull=False)
            existing_users = role.members.all()
            profile_list = []
            if existing_users:
                profile_list = profiles.exclude(
                    pk__in=existing_users.values_list('pk', flat=True)).values(
                        'pk', 'user__email')
            elif profiles:
                profile_list = profiles.values('pk', 'user__email')
            list_data = {
                'users': list(profile_list),
                'existing': list(existing_users.values(
                    'pk', 'user__email'))
            }
            return HttpResponse(
                json.dumps(list_data), content_type="application/json")


class DeleteRole(View):

    def get(self, request, role_id):
        try:
            role = RolePrivilege.objects.get(id=role_id)
            role.delete()
            list_data = {
                'msg': "Successfully removed the role",
                'response': 'ok'
            }
        except:
            list_data = {
                'msg': "Something went wrong",
                'response': 'error'
            }
        return HttpResponse(
            json.dumps(list_data), content_type="application/json")


class CreateCategory(View):

    def post(self, request, customer_id):

        if request.user.is_authenticated():
            if UserPrivilegeCheck().check_has_privilege(
                    request.user, "admin_settings_dashboard") or \
                    UserPrivilegeCheck().check_has_privilege(
                        request.user, "Devel_admin_access"):
                customer = Customer.objects.get(id=customer_id)
                parent = request.POST['parent']
                try:
                    Category.objects.get(
                        name=request.POST['name'], customer=customer,
                        parent=parent)
                    messages.error(
                        request, "Unable to create, category already exists")
                except Exception as ex:
                    print str(ex)
                    Category.objects.create(
                        name=request.POST['name'], customer=customer,
                        description=request.POST['desc'], parent=parent)
                    messages.success(
                        request, "Successfully created the category")
                return HttpResponseRedirect(
                    "/admin_settings/customers/"+str(customer_id)+"/")
            messages.error(
                request, "You dont have the permision to access this page")
            return HttpResponseRedirect("/")
        return HttpResponseRedirect("/login")


class WorkgroupList(View):

    def get(self, request, *args, **kwargs):
        if UserPrivilegeCheck().check_has_privilege(
                request.user, "admin_settings_dashboard") \
                or UserPrivilegeCheck().check_has_privilege(
                    request.user, "Devel_admin_access"):
            if request.is_ajax():
                groups = list(Workgroup.objects.filter(
                    customer__id=kwargs['customer_id']).values_list(
                            'id', 'workgroup', 'description', 'active'))
                groups = json.dumps(groups, cls=DjangoJSONEncoder)
                return HttpResponse(groups, content_type="application/json")
        m = "We are so sorry, you dont have the permission to access this page"
        messages.error(request, m)
        return HttpResponseRedirect("/")


class WorkgroupDetails(View):

    def get(self, request, *args, **kwargs):

        if UserPrivilegeCheck().check_has_privilege(
                request.user, "admin_settings_dashboard") or \
                    UserPrivilegeCheck().check_has_privilege(
                        request.user, "Devel_admin_access"):
            workgroup = Workgroup.objects.get(id=kwargs['workgroup_id'])
            profile = UserProfile.objects.get(user=request.user)
            customers = Customer.objects.all()
            if request.is_ajax():
                subgroups = list(Subgroup.objects.filter(
                    workgroup__id=kwargs['workgroup_id']).values_list(
                        'id', 'subgroupname', 'description', 'active'))
                subgroups = json.dumps(subgroups, cls=DjangoJSONEncoder)
                return HttpResponse(subgroups, content_type="application/json")
            group_members = workgroup.subgroupmember_set.filter(active=True)
            if request.GET.get("activate"):
                if request.GET.get("activate") == "1":
                    workgroup.active = True
                    messages.success(request, 'Workgroup has activated')
                elif request.GET.get("activate") == "0":
                    workgroup.active = False
                    messages.success(request, 'Workgroup has deactivated')
                workgroup.save()
                return HttpResponseRedirect(
                    "/admin_settings/workgroup/"+str(workgroup.id)+"/")
            c = RequestContext(request, {
                                        'profile': profile,
                                        'workgroup': workgroup,
                                        'customers': customers,
                                        'group_members': group_members
                                        })
            return render(
                request, 'admin_settings/workgroup_details.html',
                context_instance=c)
        m = "We are so sorry, you dont have the permission to access this page"
        messages.error(request, m)
        return HttpResponseRedirect("/")

    def post(self, request, *args, **kwargs):

        if UserPrivilegeCheck().check_has_privilege(
                request.user, "admin_settings_dashboard") or \
                    UserPrivilegeCheck().check_has_privilege(
                        request.user, "Devel_admin_access"):
            profile = UserProfile.objects.get(user=request.user)
            workgroup = Workgroup.objects.get(id=kwargs['workgroup_id'])
            workgroup.workgroup = request.POST['name']
            workgroup.description = request.POST['desc']
            if request.POST.get('group_leader', ''):
                group_leader = UserProfile.objects.get(
                    id=request.POST['group_leader'])
                workgroup.group_leader = group_leader
            # edit in customer change will result in the
            # conflict with the tickets and users having
            # old customer.
            # new_customer = Customer.objects.get(id=request.POST['customer'])
            # workgroup.customer = new_customer
            # adding the changed field data to the log file
            settings_log_creator.add_log(
                workgroup, "core", "Workgroup", kwargs['workgroup_id'],
                profile)
            workgroup.save()
            messages.success(request, "Workgroup has updated successfully")
            return HttpResponseRedirect(
                "/admin_settings/workgroup/"+str(workgroup.id)+"/")
        m = "We are so sorry, you dont have the permission to access this page"
        messages.error(request, m)
        return HttpResponseRedirect("/")


class SubgroupDetails(View):

    def get(self, request, *args, **kwargs):

        subgroup = Subgroup.objects.get(id=kwargs['subgroup_id'])
        profile = UserProfile.objects.get(user=request.user)
        if request.is_ajax():
            # fetching subgroup members
            members = list(subgroup.subgroupmember_set.filter(
                person__active=True, person__user__is_active=True).values_list(
                    'id', 'person__user__email', 'active'))
            members = json.dumps(members, cls=DjangoJSONEncoder)
            return HttpResponse(members, content_type="application/json")
        if UserPrivilegeCheck().check_has_privilege(
            request.user, "admin_settings_dashboard") or \
                UserPrivilegeCheck().check_has_privilege(
                    request.user, "Devel_admin_access"):
            # activate or deactivate the subgroup
            if request.GET.get('activate'):
                if request.GET.get('activate') == "1":
                    subgroup.active = True
                elif request.GET.get('activate') == "0":
                    subgroup.active = False
                subgroup.save()
                return HttpResponseRedirect(
                    "/admin_settings/subgroup/"+str(subgroup.id)+"/")
            c = RequestContext(request, {
                    'profile': profile,
                    'subgroup': subgroup
                })
            return render(
                request, 'admin_settings/subgroup_details.html',
                context_instance=c)
        m = "We are so sorry, you dont have the permission to access this page"
        messages.error(request, m)
        return HttpResponseRedirect("/")


class CreateSubgroup(View):

    def post(self, request, *args, **kwargs):

        if UserPrivilegeCheck().check_has_privilege(
                request.user, "admin_settings_dashboard") or \
                    UserPrivilegeCheck().check_has_privilege(
                        request.user, "Devel_admin_access"):
            profile = UserProfile.objects.get(user=request.user)
            workgroup = Workgroup.objects.get(id=kwargs['workgroup_id'])
            try:
                subgroup = Subgroup.objects.get(
                                workgroup=workgroup,
                                subgroupname=request.POST['name'])
                messages.error(request, "Subgroup already exists")
            except Exception as ex:
                print str(ex)
                subgroup = Subgroup.objects.create(
                                workgroup=workgroup,
                                description=request.POST['desc'],
                                subgroupname=request.POST['name'])
                settings_log_creator.add_log(
                    subgroup, "core", "Subgroup", subgroup.id, profile, True)
                messages.success(
                    request, "Successfully created a new subgroup")
            return HttpResponseRedirect(
                "/admin_settings/workgroup/"+str(workgroup.id)+"/")
        m = "We are so sorry, you dont have the permission to access this page"
        messages.error(request, m)
        return HttpResponseRedirect("/")


class NonSubgroupMembers(View):

    def get(self, request, *args, **kwargs):

        if UserPrivilegeCheck().check_has_privilege(
                request.user, "admin_settings_dashboard") or \
                    UserPrivilegeCheck().check_has_privilege(
                        request.user, "Devel_admin_access"):
            subgroup = Subgroup.objects.get(id=kwargs['subgroup_id'])
            members_list = subgroup.subgroupmember_set.all().values_list(
                'person__id', flat=True)
            if request.is_ajax():
                # fetch the list of the non members in the subgroup
                profiles = list(UserProfile.objects.filter(
                    ~Q(id__in=members_list),
                    active=True, user__is_active=True,
                    custpem__customer=subgroup.workgroup.customer).values_list(
                        'id', 'user__email', 'user__username'))
                profiles = json.dumps(profiles, cls=DjangoJSONEncoder)
                return HttpResponse(profiles, content_type="application/json")
        m = "We are so sorry, you dont have the permission to access this page"
        messages.error(request, m)
        return HttpResponseRedirect("/")


class RemoveSubgroupMember(View):

    def post(self, request, *args, **kwargs):

        if UserPrivilegeCheck().check_has_privilege(
                request.user, "admin_settings_dashboard") or \
                    UserPrivilegeCheck().check_has_privilege(
                        request.user, "Devel_admin_access"):
            subgroup = Subgroup.objects.get(id=kwargs['subgroup_id'])
            removed_ids = request.POST['remove_data'].split(',')
            SubgroupMember.objects.filter(
                id__in=removed_ids, subgroup=subgroup).delete()
            return HttpResponse(
                json.dumps({"message": "ok"}), content_type="application/json")
        m = "We are so sorry, you dont have the permission to access this page"
        messages.error(request, m)
        return HttpResponseRedirect("/")


class CategoryList(View):

    model = None
    template_name = "category_details.html"

    def get(self, request, *args, **kwargs):

        category_list = Category.objects.all()
        return render(request, 'category_details.html', locals())


class Common_List(ListView):

    context_object_name = "item_list"
    template_name = "category_details.html"

    def get_context_data(self, **kwargs):
        context = super(Common_List, self).get_context_data(**kwargs)
        return context
