# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from core.models import (
    UserProfile, Workgroup, Worklog, Customer, TicketHistory, Relatedtickets,
    Ticket, ResolvedKBDetails, WorklogReplyHistory, FaqCategory, Visitors,
    FaqDetails, FaqImages, FaqSubcategory, SLA, Approval,
    EmailCommunicationTemplate, TicketResponseDetails, Category, StatusLabel,
    EmailLog, EmailCron, Privilege)


class UserProfileAdmin(admin.ModelAdmin):
    search_fields = ('user__username', 'user__first_name')


class WorkgroupAdmin(admin.ModelAdmin):
    list_display = ['workgroup', 'description', 'customer', ]
    search_fields = ('workgroup', 'customer__customername')


class TicketHistoryAdmin(admin.ModelAdmin):
    search_fields = ['ticket__ticketid']


class CategoryAdmin(admin.ModelAdmin):
    search_fields = ['name']


admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(Workgroup, WorkgroupAdmin)
admin.site.register(TicketHistory, TicketHistoryAdmin)
admin.site.register(Category, CategoryAdmin)

admin.site.register(Worklog)
admin.site.register(Privilege)
admin.site.register(Customer)
admin.site.register(Relatedtickets)
admin.site.register(Ticket)
admin.site.register(ResolvedKBDetails)
admin.site.register(WorklogReplyHistory)
admin.site.register(FaqCategory)
admin.site.register(Visitors)
admin.site.register(FaqDetails)
admin.site.register(FaqImages)
admin.site.register(FaqSubcategory)
admin.site.register(SLA)
admin.site.register(Approval)
admin.site.register(EmailCommunicationTemplate)
admin.site.register(TicketResponseDetails)
admin.site.register(StatusLabel)
admin.site.register(EmailLog)
admin.site.register(EmailCron)
