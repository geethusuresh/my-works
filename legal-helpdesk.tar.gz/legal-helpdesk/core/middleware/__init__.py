from django.http import HttpResponseRedirect
from django.conf import settings
import re
from re import compile

EXEMPT_URLS = [compile(settings.LOGIN_URL.lstrip('/'))]
if hasattr(settings, 'LOGIN_EXEMPT_URLS'):
    EXEMPT_URLS += [compile(expr) for expr in settings.LOGIN_EXEMPT_URLS]

REDIRECT_URI_REGEX = '(login/)|(/admin/)'


class LoginRequiredMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):

        assert hasattr(request, 'user')
        path = request.path_info.lstrip('/')
        url_is_exempt = any(m.match(path) for m in EXEMPT_URLS)

        if request.user.is_authenticated():
            return None
        elif not url_is_exempt:
            url = settings.LOGIN_URL
            if not re.match(REDIRECT_URI_REGEX, request.path):
                if request.path:
                    url = settings.LOGIN_URL + "?next=%s" % (request.path)
            return HttpResponseRedirect(url)
