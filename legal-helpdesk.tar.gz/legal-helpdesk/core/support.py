from core.models import (
    EmailCommunicationTemplate, Customer, RolePrivilege, AdminSettingsLog,
    UserProfile)
from .utils import ModelDiff


class AssignEmailTemplate:

    def create_email_template(self, customer_id, template_id):
        # Creating email communication template from
        # reference email communication templates
        customer = Customer.objects.get(id=customer_id)
        email_template = EmailCommunicationTemplate.objects.get(
            id=template_id)
        new_template, created = EmailCommunicationTemplate.\
            objects.get_or_create(
                customer=customer,
                templatename=email_template.templatename)
        if created:
            new_template.templatebody = email_template.templatebody
            new_template.templatesubject = email_template.templatesubject
            new_template.save()
            return True
        return False

    def create_new_template(self, customer_id, post_data):
        # Direct creation of an email communication template
        customer = Customer.objects.get(id=customer_id)
        EmailCommunicationTemplate.objects.create(
            customer=customer,
            templatename=post_data['name'],
            templatesubject=post_data['subject'],
            templatebody=post_data['body'])
        return True

    def copy_all_templates(self, copy_from, copy_to):

        copy_from_cust = Customer.objects.get(id=copy_from)
        copy_to_cust = Customer.objects.get(id=copy_to)
        templates = EmailCommunicationTemplate.objects.filter(
            customer=copy_from_cust)
        for email_template in templates:
            new_template, created = EmailCommunicationTemplate.\
                objects.get_or_create(
                    customer=copy_to_cust,
                    templatename=email_template.templatename)
            if created:
                new_template.templatebody = email_template.templatebody
                new_template.templatesubject = email_template.templatesubject
                new_template.save()
        return True


class AddToSettingsLog(object):

    def add_log(self, new_object, app_name, model, id_val, profile,
                is_new=False, is_delete=False):

        if is_new is True:
            excl_lis = ['id', 'rowstamp', '_state']
            change_dat_list = [
                {'field_value': k, 'old': '', 'new': v}
                for k, v in new_object.__dict__.items() if k not in excl_lis]
            for change_dat in change_dat_list:
                AdminSettingsLog.objects.create(
                        who_added=profile,
                        affected_model=model,
                        field_name=change_dat['field_value'],
                        old_value=change_dat['old'],
                        new_value=change_dat['new'])
        elif is_delete is True:
            excl_lis = ['id', 'rowstamp', '_state']
        else:
            model_diff = ModelDiff(new_object, id_val, model, app_name)
            diff = model_diff.has_changed()
            if diff:
                changed_result = model_diff.diff_data()
                for change_dat in changed_result:
                    AdminSettingsLog.objects.create(
                        who_added=profile,
                        affected_model=model,
                        field_name=change_dat['field_value'],
                        old_value=change_dat['old'],
                        new_value=change_dat['new'])


class UserPrivilegeCheck(object):

    def get_privilege_list(self, profile_user):

        profile = UserProfile.objects.get(user=profile_user)
        user_privileges = RolePrivilege.objects.filter(
                members=profile).privileges.all().values_list('privilege')
        if profile.is_devel_admin is True:
            user_privileges.append("Devel_admin_access")
        if profile.is_admin is True:
            user_privileges.append("admin_settings_dashboard")
        return user_privileges

    def check_has_privilege(self, profile_user, privilege=None):

        privs = self.get_privilege_list(profile_user)
        if privilege:
            if privilege in privs:
                return True
            else:
                return False
        else:
            return privs
