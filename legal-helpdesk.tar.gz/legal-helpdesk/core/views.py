# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from django.views.generic import TemplateView
from django.urls import reverse

# from email.parser import Parser
# import json as simplejson
# import StringIO, base64, csv, zipfile, ldap,  pytz, uuid, os, imp, imaplib
# # xlsxwriter to be added
# from django.core.exceptions import ObjectDoesNotExist
# from django.db import connection, connections
# from django.shortcuts import render
# from django.core.urlresolvers import reverse
# from django.template.loader import render_to_string, get_template
# from datetime import datetime, timedelta
# from django.utils.timezone import utc
# from django.views.decorators.csrf import csrf_exempt
# # from django_mailbox.models import Message, Mailbox
# # from ldap.controls import SimplePagedResultsControl
# from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
# from django.core import serializers
# from django.contrib.auth.models import User
# from django.contrib.auth import logout
# from django.db.models import Q, Max, Sum
# from django.utils.safestring import mark_safe
# from django.core.mail import send_mail, EmailMultiAlternatives, EmailMessage
# from bs4 import BeautifulSoup

# from django.views.decorators.cache import cache_control
# from django.core.serializers.json import DjangoJSONEncoder
# from django.contrib.auth.decorators import login_required
# from django.contrib.sites.models import Site
# from xhtml2pdf import pisa
# from PIL import Image
# from django.http import StreamingHttpResponse
# from legal_helpdesk.settings import MEDIA_ROOT, STATICFILES_DIRS, SITE_ROOT
# from django.conf import settings


from core.models import Ticket, Category


class LoginAuthenticate(TemplateView):
    template_name = "login.html"

    def get_context_data(self, **kwargs):
        context = super(LoginAuthenticate, self).get_context_data(**kwargs)
        context['next'] = self.request.GET.get('next', '')
        print " context['next'] = ", context['next']
        return context

    def post(self, request, **kwargs):
        username = self.request.POST['username']
        password = self.request.POST['password']
        user = authenticate(self.request, username=username, password=password)
        # ldap authentication
        # check customer exists or not
        next_url = request.POST.get('next', None)
        print "next_url=", next_url
        if not request.POST.get('remember_me', None):
            request.session.set_expiry(0)
        if user is not None:
            login(self.request, user)
            if next_url:
                return HttpResponseRedirect(next_url)
            return HttpResponseRedirect('/')
        else:
            messages.error(self.request, "Please check the username \
                and password")
            return HttpResponseRedirect(request.META['HTTP_REFERER'])


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse('login'))


class DashboardView(TemplateView):
    template_name = "dashboard.html"

    def get_context_data(self, **kwargs):
        context = super(DashboardView, self).get_context_data(**kwargs)
        # profile = UserProfile.objects.get(user=self.request.user)
        context['new_tickets'] = Ticket.objects.filter(status="NEW")
        context['category_data'] = Category.objects.filter(parent=1)
        return context
