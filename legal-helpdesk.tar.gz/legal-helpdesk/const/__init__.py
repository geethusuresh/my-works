
TICKET_TYPE_LIST = (
    ('SR', 'Service Request'),
)


WORK_LOCATION_CHOICE = (
    ('Onsite', 'Onsite'),
    ('Offshore', 'Offshore'),
)


EMPLOYEE_TYPE = (('PERMANANT', 'PERMANANT'),
                 ('TEMPORARY', 'TEMPORARY'),
                 ('CONTRACT', 'CONTRACT'))

NOTI_TYPE = (('LOGIN', "login notification"), ('TICKET', "TIcket Related"),
             ('MOBILE', 'MOBILE'))

TICKET_TYPE_LIST = (
    ('SR', 'Service Request'),
)

RESPONSE_CHOICES = ((0, 'Within_SLA'),
                    (1, 'Crossed_SLA'))

RESOLUTION_CHOICES = ((0, 'Within_SLA'),
                      (1, 'Crossed_SLA'))

MSG_SENT_TYPE = (
    ('manager_closure', 'manager_closure'),
    ('manager_firstremain', 'manager_firstremain'),
    ('manager_secondremain', 'manager_secondremain'),
    ('manager_thirdremain', 'manager_thirdremain'),
    ('fn_head_closure', 'fn_head_closure'),
    ('fn_head_firstremain', 'fn_head_firstremain'),
    ('fn_head_secondremain', 'fn_head_secondremain'),
    ('fn_head_thirdremain', 'fn_head_thirdremain'),
    ('enduser_manager_close', 'enduser_manager_close'),
    ('enduser_fn_head_close', 'enduser_fn_head_close'),
    ('enduser_reply_remain', 'enduser_reply_remain'),
    ('enduser_reply_close', 'enduser_reply_close'),
    ('customer_await_reminder', 'customer_await_reminder'),
    ('customer_await_closure', 'customer_await_closure'),
)

DIVISION_TYPE_CHOICE = (
    ('Solutions', 'Solutions'),
    ('PS', 'PS'),
)


STATUS_LIST = (("NEW", "New"), ("INPROG", "In Progress"),
               ("RESOLVED", "Resolved"), ("CLOSED", "Closed"),
               ("CANCELLED", "Cancelled"))

CLIENT_TYPE_CHOICE = (
    ('End Client', 'End Client'),
    ('Direct Client', 'Direct Client'),
    ('Middle Layer', 'Middle Layer'),
)


WORK_LOCATION_CHOICE = (
    ('Onsite', 'Onsite'),
    ('Offshore', 'Offshore'),
)


COST_TYPE_CHOICE = (
    ('FP', 'FP'),
    ('TM', 'TM'),
    ('No Charge', 'No Charge'),
)
