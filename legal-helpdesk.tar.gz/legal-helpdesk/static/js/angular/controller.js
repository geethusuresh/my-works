
legalhHomeApp.controller('PrivilegeController', ['$scope', '$http', '$timeout', '$filter', 'filterFilter', function ($scope, $http, $timeout, $filter, filterFilter) {
    $scope.init = function(csrf_token) {
        $scope.csrf_token = csrf_token;
        $scope.privileges = [];
        $scope.entryLimit = 10;
        $scope.noOfPages = 5;
        $scope.get_privilege_list();
    }
    $scope.get_privilege_list = function() {
        $http({
            method: "get",
            url: "/settings/privilege/all/?json=True",
        }).success(function(data){
            $scope.privileges = data['privs']
            $scope.currentPage = 1;
            update_pagination_length($scope, filterFilter, $scope.privileges)
        });
    }
    $scope.privilege_validation = function(){
        $scope.error_message_data = '';
        if ($scope.priv_name == '' || $scope.priv_name == undefined) {
            $scope.error_message_data = 'Please enter the privilege name';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_subcateg_create_submited = false;
            return false;
        } else if ($scope.priv_desc == '' || $scope.priv_desc == undefined) {
            $scope.error_message_data = 'Please enter the description';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_subcateg_create_submited = false;
            return false;
        }
        return true;
    }
    $scope.create_privilege = function() {
        params = {
            'csrfmiddlewaretoken': $scope.csrf_token,
            'name': $scope.priv_name,
            'desc': $scope.priv_desc
        }
        if ($scope.privilege_validation()) {
            $http({
                method: "post",
                data: $.param(params),
                url: "/settings/privileges/create/",
                headers : {
                    'Content-Type' : 'application/x-www-form-urlencoded'
                }
            }).success(function(data){
                if (data.response == "ok") {
                    $scope.error_message_data = '';
                    $scope.privileges.push(data['new']);
                    update_pagination_length($scope, filterFilter, $scope.privileges)
                    $('#create_privilege').modal('hide');
                    $scope.message_data = "Successfully added the new privilege"
                    $timeout(function () { $scope.message_data = ''; }, 3000);
                } else {
                    $scope.error_message_data = data['message'];
                    $timeout(function () { $scope.error_message_data = ''; }, 3000);
                }
            });
        }
    }
    $scope.clear_privilege_modal =function(){
        $scope.priv_name = '';
        $scope.priv_desc = '';
    }
    $scope.$watch('search', function(term) {
        if (term) {
            $scope.filtered = filterFilter($scope.privileges, term);
            $scope.totalItems = $scope.filtered.length;
            $scope.reverse = !$scope.reverse;
        } else {
            $scope.filtered = filterFilter($scope.privileges);
            if ($scope.filtered) {
                $scope.totalItems = $scope.filtered.length;
            }
        }
    });
}])

legalhHomeApp.controller('RoleController', ['$scope', '$http', '$timeout', '$filter', 'filterFilter', function ($scope, $http, $timeout, $filter, filterFilter) {
    $scope.init = function(csrf_token) {
        $scope.csrf_token = csrf_token;
        $scope.roles = [];
        $scope.entryLimit = 10;
        $scope.noOfPages = 5;
        $scope.get_role_list();
        $scope.get_customer_list();
        $scope.is_role_create_submited = false;
        $scope.role_privileges = [];
        $scope.privileges = [];
        $scope.users = [];
        $scope.role_members = [];
    }
    $scope.get_customer_list = function() {
        $http({
            method: "get",
            url: "/settings/customer/all/?json=True",
        }).success(function(data){
            $scope.customers = data['customers'];
        });
    }
    $scope.get_members_data = function(role) {
        $scope.person_role = role;
        $scope.role_data = role;
        $http({
            method: "get",
            url: "/settings/users/all/?person_role=True&role_id="+role.id,
        }).success(function(data){
            $scope.users = data['users'];
            $scope.role_members = data['existing'];
        });
    }
    $scope.add_members_to_role = function(member) {
        $scope.role_members.push(member);
        var index = $scope.users.indexOf(member);
        $scope.users.splice(index, 1);
    }
    $scope.remove_members_from_role = function(member) {
        $scope.users.push(member);
        var index = $scope.role_members.indexOf(member);
        $scope.role_members.splice(index, 1);
    }
    $scope.save_role_members = function() {
        $scope.is_membr_add_role = true;
        params = {
            'users': angular.toJson($scope.role_members),
            'csrfmiddlewaretoken': $scope.csrf_token,
        }
        data = $.param(params);
        url = "/settings/roles/"+ $scope.role_data.id+"/add/members/"
        $http({
            method: "post",
            url: url,
            data: $.param(params),
            headers : {
                'Content-Type' : 'application/x-www-form-urlencoded'
            }
        }).success(function(data){
            $scope.is_membr_add_role = false;
            if (data['response'] == 'ok') {
                // $('#add_privilege').modal('hide');
                $scope.error_message_data = data['msg'];
                $timeout(function () { $scope.error_message_data = ''; }, 3000);
            } else if (data['response'] == 'error') {
                $scope.error_message_data = data['msg'];
                $timeout(function () { $scope.error_message_data = ''; }, 3000);
            }
        }).error(function(data){
            console.log(data);
        });
    }
    $scope.get_privilege_data = function(role) {
        $scope.role_data = role;
        $http({
            method: "get",
            url: "/settings/privilege/all/?json=True&role_id="+role.id,
        }).success(function(data){
            $scope.privileges = data['privs'];
            $scope.role_privileges = data['existing'];
        });
    }
    $scope.save_role_privilege = function() {
        if ($scope.role_privileges.length > 0) {
            $scope.is_priv_add_role = true;
            params = {
                'privs': angular.toJson($scope.role_privileges),
                'csrfmiddlewaretoken': $scope.csrf_token,
            }
            data = $.param(params);
            url = "/settings/roles/"+ $scope.role_data.id+"/add/privilege/"
            $http({
                method: "post",
                url: url,
                data: $.param(params),
                headers : {
                    'Content-Type' : 'application/x-www-form-urlencoded'
                }
            }).success(function(data){
                $scope.is_priv_add_role = false;
                if (data['response'] == 'ok') {
                    // $('#add_privilege').modal('hide');
                    $scope.error_message_data = data['msg'];
                    $timeout(function () { $scope.error_message_data = ''; }, 3000);
                } else if (data['response'] == 'error') {
                    $scope.error_message_data = data['msg'];
                    $timeout(function () { $scope.error_message_data = ''; }, 3000);
                }
            }).error(function(data){
                console.log(data);
            });
        } else {
            $scope.is_priv_add_role = false;
            $scope.error_message_data = data['msg'];
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
        }
    }
    $scope.add_privilege_to_role = function(priv) {
        $scope.role_privileges.push(priv);
        var index = $scope.privileges.indexOf(priv);
        $scope.privileges.splice(index, 1);
    }
    $scope.remove_privilege_from_role = function(priv) {
        $scope.privileges.push(priv);
        var index = $scope.role_privileges.indexOf(priv);
        $scope.role_privileges.splice(index, 1);
    }
    $scope.get_role_list = function() {
        $http({
            method: "get",
            url: "/settings/role/all/?json=True",
        }).success(function(data){
            $scope.roles = data['roles'];
            $scope.customers = data['customers'];
            $scope.currentPage = 1;
            update_pagination_length($scope, filterFilter, $scope.roles)
        });
    }
    $scope.role_initialize = function() {
        $scope.role = {
            'customer': '',
            'name': '',
            'desc': ''
        }
    }
    $scope.$watch('search', function(term) {
        if (term) {
            $scope.filtered = filterFilter($scope.roles, term);
            $scope.totalItems = $scope.filtered.length;
            $scope.reverse = !$scope.reverse;
        } else {
            $scope.filtered = filterFilter($scope.roles);
            if ($scope.filtered) {
                $scope.totalItems = $scope.filtered.length;
            }
        }
    });
    $scope.validate_role_creation = function() {
        $scope.error_message_data = '';
        if ($scope.role.name == '' || $scope.role.name == undefined) {
            $scope.error_message_data = 'Please enter the role name';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_role_create_submited = false;
            return false;
        } else if ($scope.role.desc == '' || $scope.role.desc == undefined) {
            $scope.error_message_data = 'Please enter the role description';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_role_create_submited = false;
            return false;
        } else if ($scope.role.customer == '' || $scope.role.customer == undefined) {
            $scope.error_message_data = 'Please choose the customer';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_role_create_submited = false;
            return false;
        }
        return true;
    }
    $scope.create_role = function() {
        if ($scope.validate_role_creation()) {
            $scope.is_role_create_submited = true;
            params = {
                'role_details': angular.toJson($scope.role),
                'csrfmiddlewaretoken': $scope.csrf_token,
            }
            data = $.param(params);
            url = "/settings/roles/create/"
            $http({
                method: "post",
                url: url,
                data: $.param(params),
                headers : {
                    'Content-Type' : 'application/x-www-form-urlencoded'
                }
            }).success(function(data){
                if (data['response'] == 'ok') {
                    $scope.roles.push(data['new']);
                    $scope.is_role_create_submited = false;
                    $('#create_role').modal('hide');
                } else if (data['response'] == 'error') {
                    $scope.is_role_create_submited = false;
                    $scope.error_message_data = data['msg'];
                    $timeout(function () { $scope.error_message_data = ''; }, 3000);
                }
            }).error(function(data){
                console.log(data);
            });
        }
    }
    $scope.delete_role_modal_open = function(role) {
        $scope.delete_role = role;
        $('#delete_role').modal('show');
    }
    $scope.delete_role_data = function(){
        $http({
            method: "get",
            url: "/settings/roles/delete/"+ $scope.delete_role.id+"/",
        }).success(function(data){
            if (data['response'] == 'ok') {
                $('#delete_role').modal('hide');
                var index = $scope.roles.indexOf($scope.delete_role);
                $scope.roles.splice(index, 1);
                update_pagination_length($scope, filterFilter, $scope.roles)
            } else {
                $scope.error_message_data = data['msg'];
                $timeout(function () { $scope.error_message_data = ''; }, 3000);
            }
        });
    }
}])

// legalhHomeApp.controller('CustomerController', ['$scope', '$http', '$timeout', '$filter', 'filterFilter', function ($scope, $http, $timeout, $filter, filterFilter) {
legalhHomeApp.controller('CustomerController', function ($scope, $http, $timeout, $filter, filterFilter, RoleService) {
    $scope.init = function(csrf_token) {
        $scope.csrf_token = csrf_token;
        $scope.entryLimit = 10;
        $scope.noOfPages = 5;
        $scope.data_file = {};
        $scope.data_file.src = "";
        $scope.get_customer_list();
        $scope.timezone = [];
    }
    $scope.get_customer_list = function() {
        $http({
            method: "get",
            url: "/settings/customer/all/?json=True",
        }).success(function(data){
            $scope.customers = data['customers'];
            $scope.timezone = data['timezones'];
            $scope.currentPage = 1;
            update_pagination_length($scope, filterFilter, $scope.customers)
        });
    }
    $scope.$watch('search', function(term) {
        if (term) {
            $scope.filtered = filterFilter($scope.customers, term);
            $scope.totalItems = $scope.filtered.length;
            $scope.reverse = !$scope.reverse;
        } else {
            $scope.filtered = filterFilter($scope.customers);
            if ($scope.filtered) {
                $scope.totalItems = $scope.filtered.length;
            }
        }
    });
    $scope.customer_initialization = function() {
        $scope.customer_details = {
            'customername' : '',
            'customerid': '',
            'currency': '',
            'default_timezone': 'UTC',
            'cust_desc': '',
            'help_text': '',
            'from_mail_id': '',
            'is_active': 'yes',
            'is_ldap_auth': 'no',
            'is_sr_approval': 'no',
            'is_all_updation': 'no',
            'is_category_change': 'no',
        }
        is_customer_create_submited = false;
    }
    $scope.customer_create_validation =  function() {
        $scope.error_message_data = '';
        if ($scope.customer_details.customername == '' || $scope.customer_details.customername == undefined) {
            $scope.error_message_data = 'Please enter the customer name';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_customer_create_submited = false;
            return false;
        } else if ($scope.customer_details.customerid == '' || $scope.customer_details.customerid == undefined) {
            $scope.error_message_data = 'Please enter the customer id';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_customer_create_submited = false;
            return false;
        } else if ($scope.customer_details.currency == '' || $scope.customer_details.currency == undefined) {
            $scope.error_message_data = 'Please enter the currency';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_customer_create_submited = false;
            return false;
        } else if ($scope.customer_details.default_timezone == '' || $scope.customer_details.default_timezone == undefined) {
            $scope.error_message_data = 'Please enter the default timezone';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_customer_create_submited = false;
            return false;
        } else if ($scope.customer_details.cust_desc == '' || $scope.customer_details.cust_desc == undefined) {
            $scope.error_message_data = 'Please enter the customer description';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_customer_create_submited = false;
            return false;
        } else if ($scope.customer_details.help_text == '' || $scope.customer_details.help_text == undefined) {
            $scope.error_message_data = 'Please enter the help text';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_customer_create_submited = false;
            return false;
        } else if ($scope.customer_details.from_mail_id == '' || $scope.customer_details.from_mail_id == undefined) {
            $scope.error_message_data = 'Please enter the from mail id';
            $timeout(function () { $scope.error_message_data = ''; }, 3000);
            $scope.is_customer_create_submited = false;
            return false;
        }
        return true;
    }
    $scope.create_customer = function() {
        $scope.is_customer_create_submited = true;
        if($scope.customer_create_validation()){
            if ($scope.data_file.src) {
                var split_name = $scope.data_file.src.name.split('.');
                split_name = split_name[split_name.length - 1];
                var extensions = ["exe", "rar", "dll"];
                var index = extensions.indexOf(split_name);
                if(index >= 0 ){
                    $scope.error_msg = "Upload error try again, exe,rar,dll file types are not allowed";
                    return false;
                }
            }
            var fd = new FormData();
            if ($scope.data_file.src) {
                fd.append('logo', $scope.data_file.src);
            }
            params = {
                'customer_details': angular.toJson($scope.customer_details),
                'csrfmiddlewaretoken': $scope.csrf_token,
            }
            for(var key in params){
                fd.append(key, params[key]);
            }
            var url = '/settings/customers/create/';
            $http.post(url, fd, {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined
                }
            }).success(function(data){
                if (data['response'] == 'ok') {
                    $scope.data_file.src = '';
                    $scope.customers.push(data['new']);
                    $scope.is_customer_create_submited = false;
                    $('#create_customer').modal('hide');
                } else if (data['response'] == 'error') {
                    $scope.is_customer_create_submited = false;
                    $scope.error_message_data = data['msg'];
                    $timeout(function () { $scope.error_message_data = ''; }, 3000);
                }
            }).error(function(data){
                console.log(data);
            });
        }
    }
    $scope.add_role = function(customer) {
        console.log(customer);
        $scope.role = {
            'customer': customer,
            'name': '',
            'desc': ''
        }
        RoleService.save($scope.role);
    }
});
// }])

legalhHomeApp.controller('CategoryController', ['$scope','$http','$timeout','$filter','filterFilter', function($scope, $http, $timeout,$filter,filterFilter){

    $scope.init = function(csrf_token)
    {
        $scope.csrf_token = csrf_token;
        $scope.get_message_templates();
        $scope.entryLimit = 10;
        $scope.noOfPages = 5;
        $scope.user_name = '';
        $scope.collected_customers = [];
    }
    $scope.create_category = function(){

        params = {
            'csrfmiddlewaretoken':$scope.csrf_token,
            //'customer': $scope.customer
            'name': $scope.category
            }

        $http({
            method: "post",
            url:"/create/category/",
            data : $.param(params),
            headers:{
                'Content-Type':'application/x-www-form-urlencoded'
            }
        }).success(function(data){
            console.log('say hello');
        })
    }
}])
