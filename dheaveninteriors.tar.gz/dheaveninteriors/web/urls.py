from django.conf.urls import patterns, include, url

from django.contrib import admin
admin.autodiscover()

from .views import HomePage, SettingsView

urlpatterns = patterns('',
    url(r'home', SettingsView.as_view(), name='home'),
    
)
