from django.contrib import admin
from .models import Tag, Gallery, Quote, Customer
# Register your models here.
admin.site.register(Tag)
admin.site.register(Gallery)
admin.site.register(Quote)
admin.site.register(Customer)