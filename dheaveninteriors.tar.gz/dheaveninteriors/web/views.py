from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.views.generic import TemplateView, View

from .models import *


class HomePage(TemplateView):

    template_name = "home.html"

    def get_context_data(self, **kwargs):

        context = super(HomePage, self).get_context_data(**kwargs)
        context['slide_images'] = Gallery.objects.filter(
            tag__tag_name__icontains='Slider').order_by(
            '-id')[:3]
        context['tags'] = Tag.objects.filter(is_visible=True).values_list(
            'id', 'tag_name')
        context['customer'] = Customer.objects.latest('id')
        return context


class SettingsView(TemplateView):

    template_name = "admin_base.html"


class GetQuoteView(View):

    def post(self, request):
        type_of_work = Tag.objects.get(id=request.POST['tag'])
        name =  request.POST['name']
        mobile_india = request.POST['ph_india']
        mobile_abroad = request.POST['code'] + request.POST['number']
        email = request.POST['email']
        message = request.POST['message']
        quote = Quote.objects.create(
            type_of_work=type_of_work,
            name=name,
            mobile_abroad=mobile_abroad,
            mobile_india=mobile_india,
            email=email,
            message=message
        )
        # send mail
        messages.success(
            request,
            "Successfully saved your contact.\
             We will contact you very soon")
        return HttpResponseRedirect(request.META['HTTP_REFERER'])