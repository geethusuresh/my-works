from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User


class Tag(models.Model):

    tag_name = models.CharField(max_length=100, null=True, blank=True)
    is_visible = models.BooleanField(default=False)

    def __str__(self):
        return self.tag_name

class Gallery(models.Model):

    uploaded = models.ForeignKey(User)
    tag = models.ForeignKey(Tag)
    created_date = models.DateTimeField(null=True, blank=True)
    image = models.FileField(upload_to='uploads/gallery/', null=True, blank=True)
    is_visible_gallery = models.BooleanField(default=False)

class Quote(models.Model):

    type_of_work = models.ForeignKey(Tag)
    name = models.CharField(max_length=100)
    mobile_abroad = models.CharField(max_length=30)
    mobile_india = models.CharField(max_length=30)
    email = models.CharField(max_length=60)
    message = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.email

class Customer(models.Model):

    name = models.CharField(max_length=100)
    mobile = models.CharField(max_length=30)
    address = models.TextField(null=True)

