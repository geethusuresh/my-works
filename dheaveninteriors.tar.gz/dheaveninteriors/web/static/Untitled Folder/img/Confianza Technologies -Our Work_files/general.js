$(function() {
	$('#slidorion').slidorion({
		first: 1,
		easing: 'easeInOutCubic',
		effect: 'random'
	});
	var menu_ul = $('.menu > li > ul'),
		   menu_a  = $('.menu > li > a');
	
	menu_ul.hide();

	menu_a.click(function(e) {
		e.preventDefault();
		if(!$(this).hasClass('active')) {
			menu_a.removeClass('active');
			menu_ul.filter(':visible').slideUp('normal');
			$(this).addClass('active').next().stop(true,true).slideDown('normal');
		} else {
			$(this).removeClass('active');
			$(this).next().stop(true,true).slideUp('normal');
		}
	});

});
$(document).ready(function(){

	$(".pop").click(function(){
		$("#newsletter_form").fadeIn(1000);
		  positionPopup();
	});
		
	$(".close").click(function(){
		$("#newsletter_form").fadeOut(500);
	});
});
function positionPopup(){
  if(!$("#newsletter_form").is(':visible')){
	return;
  } 
  $("#newsletter_form").css({
	  right: ($(window).width()-1240)/2,
	  top: 66,
	  position:'absolute'
  });
}
$(window).bind('resize',positionPopup);

function sendNewsLetter(){
	
	var nameNewsLetter  = $("#nameNewsLetter").val();
	var emailNewsLetter = $("#emailNewsLetter").val();
	
	if( nameNewsLetter == '' ){
		showMessage("statusNewsLetter","nameNewsLetter","Please Enter Name",-1);
		return false;
	}else if( emailNewsLetter == '' ){
		showMessage("statusNewsLetter","emailNewsLetter","Please Enter Email",-1);
		return false;
	}else if( !validEmail(emailNewsLetter) ){
		showMessage("statusNewsLetter","emailNewsLetter","Please Enter Valid Email",-1);
		return false;
	}
	
	showMessage("statusNewsLetter","","",0);
	
	var data = 'nameNewsLetter='+nameNewsLetter+'&emailNewsLetter='+emailNewsLetter;
	
	$.ajax({  
		type: "POST", url: 'ajax.php?action=registerNewsLetter', data: data,  
		complete: function(data){
			if( data.responseText == 'ok' ){
				showMessage("statusNewsLetter","","Your subscription has been confirmed. You've been added to our list and will hear from us soon.",1);
				return false;
			}else{
				showMessage("statusNewsLetter","",data.responseText,0);
				return false;
			}
		}  
	});  
}
function validEmail(e) {
    var filter = /^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/;
    return String(e).search (filter) != -1;
}
function showMessage(idMessage,idElement,textMessage,idType){

	if( idType == 0){
		textMessage = textMessage;
	}else if( idType == -1){
		textMessage = '<div class="errorMessage">'+textMessage+'</div>';
	}else{
		textMessage = '<div class="successMessage">'+textMessage+'</div>';
	}
	
	$("#"+idMessage).html(textMessage);	
	
	if(idElement != '' )
	$("#"+idElement).focus();	
	
	return true;
}
var _gaq = _gaq || [];_gaq.push(['_setAccount', 'UA-18077265-4']);_gaq.push(['_trackPageview']);(function() {var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);  })();
