(function(){function r(r){try{if(!window.location.ancestorOrigins)return;for(var n=0,t=window.location.ancestorOrigins.length;n<t;n++){r.call(null,window.location.ancestorOrigins[n],n)}}catch(o){}return[]}function n(r){var n=[],t;do{t=t?t.parent:window;try{r.call(null,t,n)}catch(o){n.push({})}}while(t!=window.top);return n}var t=n(function(r,n){n.push({referrer:r.document.referrer||null,location:r.location.href||null})});r(function(r,n){t[n].ancestor=r});var o='';for(var e=t.length-1;e>=0;e--){o=t[e].location;if(!o&&e>0){o=t[e-1].referrer;if(!o){o=t[e-1].ancestor}}if(o){break}}o=encodeURIComponent(o);var h12_tags = '<scr' + 'ipt src="\/\/tags.h12-media.com\/v2\/tags.js?site=bba959a13bb36b6550d8ac991dfce89b&type=300x250&size=&pname=&debug=&name=&code=&freq=&pb=&bref=' + o + '&rnd='+Math.random()%99999999+'"><\/scr'+'ipt>';

try {
var prnd=Math.floor(Math.random()*1000000);
var h12divcid = 'h12c_300x250_' + prnd;
var w = '300'; var h = '250';
var i = document.createElement('iframe');
i.id = h12divcid + '_ifrm';
i.scrolling = 'no';i.frameBorder = 0;i.style.margin = 0;i.style.padding = 0;i.style.width = w + 'px';i.style.height = h + 'px';
document.write('<div id="' + h12divcid +'"></div>');
var h12_cnt_div = document.getElementById(h12divcid);    
if((typeof (h12_cnt_div) != 'undefined') && (h12_cnt_div != null)) { h12_cnt_div.appendChild(i); }
i = (i.contentWindow) ? i.contentWindow : (i.contentDocument.document) ? i.contentDocument.document : i.contentDocument;
i.document.open();i.document.write('<html><head><title><\/title><\/head><body style="margin:0;padding:0">' + h12_tags + '<\/body><\/html>');i.document.close();
i.width = w; i.height = h;
} catch(err) {document.write(h12_tags);}
})();