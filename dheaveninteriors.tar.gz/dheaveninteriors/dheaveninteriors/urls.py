from django.conf.urls import patterns, include, url
from django.conf import settings
from django.contrib import admin
admin.autodiscover()

from web.views import HomePage, SettingsView, GetQuoteView

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'dheaveninteriors.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^admin/', include(admin.site.urls)),
    # url(r'^$', include('web.urls')),
    url(r'^home/$', HomePage.as_view(), name='home'),
    url(r'settings/$', SettingsView.as_view(), name='settings'),
    url(r'^media/(?P<path>.*)$', 'django.views.static.serve',
       {'document_root': settings.MEDIA_ROOT, }),
    url(r'get_a_quote/$', GetQuoteView.as_view(), name='get_a_quote')
)
# urlpatterns = [
#     # ... the rest of your URLconf goes here ...
# ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
