

def site_variables(request):
    pass