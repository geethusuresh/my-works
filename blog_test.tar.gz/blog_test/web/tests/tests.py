from datetime import datetime, timedelta

from django.core.urlresolvers import reverse
from django.test import TestCase
from django.test.client import Client

from web.models import *


class BlogsTestCase(TestCase):

    def login_user(self, username = 'test', password = 'password1', client = None):
        if not client:
            client = Client()

        user = User.objects.create_user(username = username, password = password, email = username + '@test.com')
        user.first_name = 'Geethu'
        user.last_name = 'Suresh'
        user.save()
        dob = datetime.now().replace(year=datetime.now().year - 30)
        profile = Profile.objects.create(user = user, contact='9876543210', dob=dob, is_admin=True)

        self.assertTrue(client.login(username = user.username, password = password))
        return client, profile

    def test_blogs_list_view_django_render(self):
        client = Client()
        response = client.get(reverse('blogs_django_list'))
        self.assertEquals(200, response.status_code)

    def test_blog_details_django_render(self):
        client, profile = self.login_user()
        blog = Blog.objects.create(title="What is Lorem Ipsum?", \
            content="""Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
            when an unknown printer took a galley of type and scrambled it to make a type specimen book.
            It has survived not only five centuries, but also the leap into electronic typesetting, 
            remaining essentially unchanged. It was popularised in the 1960s with the release of 
            Letraset sheets containing Lorem Ipsum passages, and more recently with desktop 
            publishing software like Aldus PageMaker including versions of Lorem Ipsum. """,
            published_on=datetime.now(), created_by=profile)

        response = client.get(reverse('blog_details_django', kwargs = {'pk': blog.id}))
        self.assertEquals(200, response.status_code)

    def test_blog_creation_django_render(self):
        pass