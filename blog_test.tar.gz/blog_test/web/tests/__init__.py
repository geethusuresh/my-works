import doctest

__test__ = {
    'Doctest': doctest
}