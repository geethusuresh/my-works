from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):

    user = models.ForeignKey(User, null=True, blank=True)
    contact = models.CharField(max_length=15)
    dob = models.DateTimeField()
    is_admin = models.BooleanField(default=False)

class Blog(models.Model):

    created_by = models.ForeignKey(Profile)
    title = models.CharField('Title', max_length=300)
    content = models.TextField('Blog Content')
    # attachment = models.ImageField(uploads='/blog/image/')
    created_on = models.DateTimeField(auto_now_add=True)
    published_on = models.DateTimeField(null=True, blank=True)
    is_publish = models.BooleanField(default=True)