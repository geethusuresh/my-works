from django.shortcuts import render, get_object_or_404
from django.views.generic import TemplateView
from django.views.generic.edit import CreateView

from web.models import Profile, Blog
from web.forms import BlogForm


class BlogsDjangoView(TemplateView):
    template_name = "blogs_django_view.html"

    def get_context_data(self, **kwargs):
        context = super(BlogsDjangoView, self).get_context_data(**kwargs)
        context['blogs'] = Blog.objects.all()
        return context


class BlogDetailsView(TemplateView):

    template_name = "blog_details_view.html"

    def get_context_data(self, **kwargs):
        context = super(BlogDetailsView, self).get_context_data(**kwargs)
        context['blog'] = get_object_or_404(Blog, pk=kwargs['pk'])
        return context


class BlogCreateview(CreateView):

    form_class = BlogForm
    template_name = 'blog_form.html'
    success_url = '/blogs/d/'