from django import forms
from django.forms.widgets import TextInput, HiddenInput, Textarea, FileInput

from .models import Blog

class BlogForm(forms.ModelForm):

    class Meta:
        model = Blog
        fields = ('title', 'content',)
        widgets = {
                   'title': TextInput(attrs = {'placeholder': 'Enter a title', "style":  "outline: none; font-size: 18px; width: 85%; border: none; padding: 0", 'autofocus': 'autofocus', "data-step": "2", "data-intro": "then do a quick lookup for the item to pre-fill some of the information" }),
                   'content': Textarea(attrs = {'placeholder': 'Brief description', 'class': 'text', 'rows': 10, 'cols': 20 }),
                   }