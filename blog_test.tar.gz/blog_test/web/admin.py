from django.contrib import admin
from web.models import Blog, Profile

admin.site.register(Profile)
admin.site.register(Blog)