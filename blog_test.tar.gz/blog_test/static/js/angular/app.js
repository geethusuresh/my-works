var legalhHomeApp = angular.module('LegalHomeApp', ['LegalHomeApp.directives', 'ngRoute', 'ui.bootstrap', 'ngSanitize']);
legalhHomeApp.config(function($interpolateProvider){
    $interpolateProvider.startSymbol('[[');
    $interpolateProvider.endSymbol(']]');
})

legalhHomeApp.config(['$routeProvider','$locationProvider',function($routes, $location){}]);

legalhHomeApp.config(['$httpProvider', function($httpProvider){
    $httpProvider.defaults.headers.common["X-RequestContext-With"] = 'XMLHttpRequest';
    $httpProvider.defaults.headers.common["HTTP_X_REQUESTED_WITH"] = 'XMLHttpRequest';
    // for http get requests
    $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    
}]);

legalhHomeApp.filter('startFrom', function () {
    return function (input, start) {
        if (input) {
            start = +start;
            return input.slice(start);
        }
        return [];
    };
});