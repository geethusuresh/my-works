function update_pagination_length($scope, filterFilter,list_data){
    if ($scope.search) {
        $scope.filtered = filterFilter(list_data, $scope.search);
    } else {
        $scope.filtered = filterFilter(list_data);
    }
    $scope.totalItems = $scope.filtered.length;
}