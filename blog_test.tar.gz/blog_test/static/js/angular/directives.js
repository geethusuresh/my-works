var directives = angular.module('LegalHomeApp.directives', []);

directives.directive('appVersion', [ 'version', function(version)
{
    return function(scope, elm, attrs)
    {
        elm.text(version);
    };
} ]);


directives.directive("fileread", [function () {
    return {
        scope: {
            fileread: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                scope.$apply(function () {
                    scope.fileread = changeEvent.target.files[0];
                });
            });
        }
    }
}]);