legalhHomeApp.service('RoleService', function($http){
    this.save = function(role) {
        console.log(role);
        $http({
            method: "get",
            url: "/settings/customer/all/?json=True",
        }).success(function(data){
            console.log(data);
            // $scope.customers = data['customers'];
            // $scope.timezone = data['timezones'];
            // $scope.currentPage = 1;
            // update_pagination_length($scope, filterFilter, $scope.customers)
        });
    }
})
// legalhHomeApp.factory('RoleFactory', ['$http', function ($http) {
//     RoleFactory.save = function(role) {
//         console.log("Hiiiiiiiiiiiiiii", role);
//     }
// }]);