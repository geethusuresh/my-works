import time
import json
from datetime import datetime, timedelta, date

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch

from casb.settings import ELASTIC_SEARCH_URL
from dashboard.models import UserProfile, Customer

es = Elasticsearch(ELASTIC_SEARCH_URL)


class HttpExtendedDashboardAjax(object):
    def perdelta(self, start, end, delta):
        while start < end:
            yield start
            start += delta

    def getTimeChart(self):
        es = Elasticsearch('http://192.168.61.108:9200')
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        gen_obj = self.perdelta(ex_date, to_date, timedelta(minutes=10))
        query = {
            "facets": {
                "0": {
                    "date_histogram": {
                        "field": "@timestamp",
                        "interval": "1h"
                    },
                    "global": "true",
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "query_string": {
                                            "query": "event_type:\"http\""
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        series_dict = {
            '2': 'New flows',
            '1': 'Established flows',
            '0': 'Closed flows'
        }
        for i in res['facets']:
            d = {}
            data = []
            total_count = 0
            for x in res['facets'][i]['entries']:
                ts = x['time'] / 1000
                time = datetime.fromtimestamp(ts).strftime('%Y %b %d %H:%M')
                data.append({"label": time, "value": x['count']})
        final_response = {'dataset': data}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getHttpUrl(self):
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.url.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getHttpHostname(self):
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.hostname.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getHttpContentType(self):
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.content_type.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getUserAgent(self):
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.http_user_agent.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getAcceptEncoding(self):
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.accept_encoding.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getXff(self):

        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.xff.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {}
        data_list = []
        for item in res['facets']['terms']['terms']:
            data_list.append({'label': item['term'], 'value': item['count']})
        final_response['data_list'] = data_list
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getHttpMethod(self):

        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.http_method.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {}
        data_list = []
        for item in res['facets']['terms']['terms']:
            data_list.append({'label': item['term'], 'value': item['count']})
        final_response['data_list'] = data_list
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getHttpLength(self):

        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.length",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {}
        data_list = []
        for item in res['facets']['terms']['terms']:
            data_list.append({'label': item['term'], 'value': item['count']})
        final_response['data_list'] = data_list
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getHttpStatusCode(self):
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.status",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_date,
                                                            "to": to_date
                                                        }
                                                    }
                                                }
                                            ],
                                            "must_not": [
                                                {
                                                    "fquery": {
                                                        "query": {
                                                            "query_string": {
                                                                "query": "http.hostname:(\"192.168.61.108\")"
                                                            }
                                                        },
                                                        "_cache": "true"
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    #
    def getHttpDocuments(self):
        """

        """
        from_date = datetime.now() - timedelta(hours=24)
        ex_date = from_date
        from_date = from_date.isoformat()
        to_date = datetime.now()
        query = {
            "query": {
                "filtered": {
                    "query": {
                        "bool": {
                            "should": [
                                {
                                    "query_string": {
                                        "query": "event_type:\"http\""
                                    }
                                }
                            ]
                        }
                    },
                    "filter": {
                        "bool": {
                            "must": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "from": from_date,
                                            "to": to_date
                                        }
                                    }
                                }
                            ],
                            "must_not": [
                                {
                                    "fquery": {
                                        "query": {
                                            "query_string": {
                                                "query": "http.hostname:(\"192.168.61.108\")"
                                            }
                                        },
                                        "_cache": "true"
                                    }
                                }
                            ]
                        }
                    }
                }
            },
            "highlight": {
                "fields": {},
                "fragment_size": 2147483647,
                "pre_tags": [
                    "@start-highlight@"
                ],
                "post_tags": [
                    "@end-highlight@"
                ]
            },
            "size": 100,
            "sort": [
                {
                    "_score": {
                        "order": "desc"
                    }
                }
            ]
        }
        base = datetime.today()
        date_list = [base - timedelta(days=x) for x in range(2)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        temp_response = []
        for i in res['hits']['hits']:
            item = i['_source']
            temp_response.append({'timestamp': item['@timestamp'],
                                  'src_ip': item['src_ip'],
                                  'src_port': item['src_port'],
                                  'dest_ip': item['dest_ip'],
                                  'dest_port': item['dest_port'],
                                  'host_name': item['http']['hostname'],
                                  'url': item['http']['url'],
                                  'status': item['http']['status'],
                                  })
        final_response = {'data': temp_response}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response
