import re
import time
import pytz
import json
from datetime import datetime,timedelta,date

from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch

from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from dashboard.common import CommonInfo, get_timezone

es = Elasticsearch(ELASTIC_SEARCH_URL,timeout=ELASTIC_TIMEOUT)

class FileDashboardAjax:

        def __init__(self,filters, request=None):
            date_duration = filters['date_minutes']
            self.elsatic_interval = date_duration['elastic_interval']
            self.duration_info = date_duration['date_duration']
            self.index_range = CommonInfo().elastic_index_range(self.duration_info)
            self.base = date_duration['base']
            self.date_start = date_duration['base1']

            self.request = request
            self.timezone = get_timezone(self.request)

            hostid = filters['host_details']
            self.hostquery = []
            for hostitem in hostid:
                self.hostquery.append({"term" : {"casbuid.raw":hostitem["ip"]}})

            try:
                self.additional_filters = []
                self.additional_filters = CommonInfo().make_filter(filters)
            except:
                pass

        def perdelta(self, start, end, delta):
            while start<end:
                    yield start
                    start += delta

        def getEvents(self):
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                gen_obj = self.perdelta(time, base, timedelta(minutes=10))
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                from_date = datetime.now() - timedelta(minutes=self.duration_info)
                time = from_date.isoformat()
                to_date = datetime.now()
                gen_obj = self.perdelta(from_date, to_date, timedelta(minutes=10))
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "0": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"PDF document\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "1": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:*"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "2": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"binary\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "3": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "4": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"executable\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "5": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"Windows Installer\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "6": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"image data\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "7": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"Macromedia Flash\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "8": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": 'true',
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "fileinfo.magic:\"video\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            series_dict = {
                '8': 'Video',
                '7': 'Macromedia Flash',
                '6': 'Image Data',
                '5': 'Windows Installer',
                '4': 'Executable',
                '3': 'MS Office',
                '2': 'Binaries',
                '1': 'Total Files',
                '0': 'PDF'
            }
            cat_time = list(gen_obj)
            category = []
            temp_cat = []
            dataset = []
            for i in res['facets']:
                for x in res['facets'][i]['entries']:
                    if x['time'] not in temp_cat:
                        ts = x['time'] / 1000
                        time = datetime.fromtimestamp(ts)
                        local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(self.timezone))
                        time = local_time.strftime("%Y %b %d %H:%M")
                        category.append({"label": time})
                        temp_cat.append(x['time'])

            temp_cat = sorted(temp_cat)
            cat_length = len(temp_cat)
            for i in res['facets']:
                d = {}
                data = []
                total_count = 0
                t = 0
                for x in res['facets'][i]['entries']:
                    while (x['time'] != temp_cat[t]):
                        data.append({"value": 0})
                        t += 1
                    ts = x['time'] / 1000
                    data.append({"value": x['count']})
                    t += 1
                    total_count += x['count']
                data.extend([{"value": 0} for j in xrange(t, cat_length)])
                d['seriesname'] = series_dict[i]
                d["data"] = data
                dataset.append(d)
            final_response = {'category': category, 'dataset': dataset}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getDownloadedFiles(self):
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.hostname.raw",
                            "size": 15,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            final_response = {'data': res['facets']['terms']['terms']}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getTypesofFiles(self):
            """
                    Function returns types for files.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "fileinfo.type.raw",
                            "size": 15,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            final_response = {'data': res['facets']['terms']['terms']}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getTotalHits(self):
            """
                    Function returns total hits of files.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "0": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"PDF document\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "1": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:*"
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "2": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"binary\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "3": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "4": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"executable\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "5": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Windows Installer\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "6": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"image data\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "7": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Macromedia Flash\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "8": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"video\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            series_dict = {
                '8': 'Video',
                '7': 'Macromedia Flash',
                '6': 'Image Data',
                '5': 'Windows Installer',
                '4': 'Executable',
                '3': 'MS Office',
                '2': 'Binaries',
                '1': 'Total Files',
                '0': 'PDF',
            }
            final_response = {}
            data_list = []
            for i in res['facets']:
                final_response[series_dict[i]] = res['facets'][i]['count']
                data_list.append({'label': series_dict[i], 'value': res['facets'][i]['count']})
            final_response['data_list'] = data_list
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getTopDestinationIP(self):
            """
                    Function returns top destination ips.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "dest_ip.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            final_response = {}
            final_response = {'data': res['facets']['terms']['terms']}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getTopDestinationPORT(self):
            """
                Function returns top destination ips.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "dest_port",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            final_response = {}
            final_response = {'data': res['facets']['terms']['terms']}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getTopSrcIP(self):
            """
                    Function returns top Source ips.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "src_ip.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            final_response = {}
            final_response = {'data': res['facets']['terms']['terms']}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getTopSrcPort(self):
            """
                    Function returns top Source ports.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "src_port",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            final_response = {}
            final_response = {'data': res['facets']['terms']['terms']}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getFileTransactions(self):
            """
                    Function returns all file transactions.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
            query = {
                "query": {
                    "filtered": {
                        "query": {
                            "bool": {
                                "should": [
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"PDF document\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:*"
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"binary\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"executable\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"Windows Installer\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"image data\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "fileinfo.magic:\"video\""
                                        }
                                    }
                                ]
                            }
                        },
                        "filter": {
                            "bool": {
                                "must": [
                                    ranges,
                                    {"bool": {
                                        "should": self.hostquery
                                    }
                                    }
                                ],
                                "should": self.additional_filters
                            }
                        }
                    }
                },
                "highlight": {
                    "fields": {},
                    "fragment_size": 2147483647,
                    "pre_tags": [
                        "@start-highlight@"
                    ],
                    "post_tags": [
                        "@end-highlight@"
                    ]
                },
                "size": 500,
                "sort": [
                    {
                        "_score": {
                            "order": "desc"
                        }
                    }
                ]
            }

            date_list = [base - timedelta(days=x) for x in range(self.index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            temp_response = []
            for i in res['hits']['hits']:
                item = i['_source']

                try:
                    utc_time = datetime.strptime(i['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                    local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                    local_time = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    local_time = i['_source']['@timestamp']

                temp_response.append({'timestamp': local_time,
                                      'src_ip': item['src_ip'],
                                      'src_port': item['src_port'],
                                      'dest_ip': item['dest_ip'],
                                      'filename': item['fileinfo']['filename'],
                                      'md5': item['fileinfo'].get('md5'),
                                      'magic': item['fileinfo']['magic']})
            final_response = {'data': temp_response}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getTrends(self):
            """
            Function returns all file trends.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                index_range = self.index_range
            else:
                base = datetime.today()
                index_range = self.index_range + self.index_range

            # time calculation for 1 day trend
            time = base - timedelta(minutes=self.duration_info)
            time_1day_new_from = time.isoformat()

            time_1day = time - timedelta(days=1)
            time_1day_old_from = time_1day.isoformat()

            time_1day_old = time_1day + timedelta(minutes=self.duration_info)
            time_1day_old_to = time_1day_old.isoformat()

            # time calculation for 4 hour trend
            time = base - timedelta(minutes=self.duration_info)
            time_4hour_new_from = time.isoformat()

            time_4hours = time - timedelta(hours=4)
            time_4hours_old_from = time_4hours.isoformat()

            time_4hour_old = time_4hours + timedelta(minutes=self.duration_info)
            time_4hour_old_to = time_4hour_old.isoformat()

            # time calculation for 1 hour trend
            time = base - timedelta(minutes=self.duration_info)
            time_1hour_new_from = time.isoformat()

            time_1hours = time - timedelta(hours=1)
            time_1hours_old_from = time_1hours.isoformat()

            time_1hour_old = time_1hours + timedelta(minutes=self.duration_info)
            time_1hour_old_to = time_1hour_old.isoformat()

            date_list = [(base - timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, index_range)]
            index_list = [('logstash-' + date) for date in date_list]

            time_1hour_old = time_1hours + timedelta(minutes=self.duration_info)
            time_1hour_old_to = time_1hour_old.isoformat()

            query = {
                "facets": {
                    "0": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"PDF document\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "1": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:*"
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "2": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"binary\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "3": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "4": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"executable\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "5": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Windows Installer\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "6": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"image data\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "7": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Macromedia Flash\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "8": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"video\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_new_from,
                                                        "to": "now"
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_0": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"PDF document\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_1": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:*"
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_2": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"binary\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_3": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_4": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"executable\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_5": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Windows Installer\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_6": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"image data\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_7": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"Macromedia Flash\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    },
                    "old_8": {
                        "query": {
                            "filtered": {
                                "query": {
                                    "query_string": {
                                        "query": "fileinfo.magic:\"video\""
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            {
                                                "match_all": {}
                                            },
                                            {
                                                "range": {
                                                    "@timestamp": {
                                                        "from": time_1day_old_from,
                                                        "to": time_1day_old_to
                                                    }
                                                }
                                            },
                                            {"bool": {
                                                "should": self.hostquery
                                            }
                                            }
                                        ],
                                        "should": self.additional_filters
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
            else:
                base = datetime.today()
            date_list = [base - timedelta(days=x) for x in range(index_range)]
            index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            temp_response = []
            series_dict = {
                '8': 'Video',
                '7': 'Macromedia Flash',
                '6': 'Image Data',
                '5': 'Windows Installer',
                '4': 'Executable',
                '3': 'MS Office',
                '2': 'Binaries',
                '1': 'Total Files',
                '0': 'PDF'
            }
            old_list = []
            old_dict = {}
            percent_diff_1day = {}
            for i in res['facets']:
                if re.match(r'old_', i):
                    old_dict[i.split('_')[1]] = res['facets'][i]
                else:
                    count_1day_new = res['facets'][i]['count']
                    count_1day_old = old_dict[i]['count']

                    print series_dict[i], count_1day_new, count_1day_old

                    if count_1day_old:
                        perc_1day = (float(count_1day_new) / float(count_1day_old)) * float(100)
                        percent_diff_1day[series_dict[i]] = perc_1day - 100
                        percent_diff_1day[series_dict[i]] = round(percent_diff_1day[series_dict[i]], 2)
                    elif count_1day_new:
                        percent_diff_1day[series_dict[i]] = "?"
                        # temp_response.append({series_dict[i]:value})
                        # print i,res['facets'][i]
            print "per diff", percent_diff_1day

            final_response = {'data': percent_diff_1day}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

        def getWorldData(self):
            """
            Function returns data for world map.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

            date_list = [(base - timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
            index_list = [('logstash-' + date) for date in date_list]
            query = {
                "facets": {
                    "map": {
                        "terms": {
                            "field": "geoip.continent_code",
                            "size": 100,
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            map_details = res['facets']['map']['terms']
            map_info = []
            for map_item in map_details:
                map_count = map_item['count']
                map_term = map_item['term']
                map_info.append({"id": map_term, "value": map_count})
            # map_info = [{'id':'us',"value":2000}]
            map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
            return map_info

        def getUSAData(self):
            """
            Function returns data for world map.
            """
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
            else:
                base = datetime.today()
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

            date_list = [(base - timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
            index_list = [('logstash-' + date) for date in date_list]
            query = {
                "facets": {
                    "map": {
                        "terms": {
                            "field": "geoip.region_name.raw",
                            "size": 100,
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"PDF document\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"binary\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Microsoft PowerPoint\" OR fileinfo.magic:\"Microsoft Excel\" OR fileinfo.magic:\"Microsoft Word\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"executable\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Windows Installer\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"image data\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"Macromedia Flash\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "fileinfo.magic:\"video\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool": {
                                                        "should": self.hostquery
                                                    }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            map_details = res['facets']['map']['terms']
            map_info = []
            for map_item in map_details:
                map_count = map_item['count']
                map_term = map_item['term']
                map_info.append({"id": map_term, "value": map_count})
            map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
            return map_info
