import json
import pytz
from datetime import datetime
from datetime import timedelta

from elasticsearch import Elasticsearch
from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from django.core.serializers.json import DjangoJSONEncoder
from dashboard.common import CommonInfo, get_timezone

es = Elasticsearch(ELASTIC_SEARCH_URL,timeout=ELASTIC_TIMEOUT)


class FlowPopup(object):
    """handles request for Http details in chart click"""

    def __init__(self, filters, request=None):
        date_duration = filters['date_minutes']     
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)
        self.base = date_duration['base']
        self.date_start = date_duration['base1']

        self.request = request
        self.timezone = get_timezone(self.request)

        hostid = filters['host_details']        
        self.hostquery = []
        for hostitem in hostid:
            self.hostquery.append({ "term" : {"casbuid.raw":hostitem["ip"]}})

        try:
            self.additional_filters = []            
            self.additional_filters = CommonInfo().make_filter(filters)
        except:            
            pass

    def executeQuery(self, query_condition, category=None):
        try:
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
            else:
                base = datetime.today()
            date_list = [(base - timedelta(days=x)).strftime('%Y.%m.%d') for x in range(self.index_range)]
            index_list = [('logstash-'+date )for date in date_list]
            query = {
                      "query": {
                        "filtered": {
                          "query": {
                            "bool": {
                              "should": category
                            }
                          },
                          "filter": {
                            "bool": {
                              "must": query_condition,
                              "should": self.additional_filters
                            }
                          }
                        }
                      },
                      "highlight": {
                        "fields": {},
                        "fragment_size": 2147483647,
                        "pre_tags": [
                          "@start-highlight@"
                        ],
                        "post_tags": [
                          "@end-highlight@"
                        ]
                      },
                      "size": 300,
                      "sort": [
                        {
                          "@timestamp": {
                            "order": "desc"
                          }
                        }
                      ]
                    }
            res = es.search(index=index_list,body=query,ignore_unavailable=index_list)          
            flow_details = {}
            flow_details['body'] = res['hits']['hits']
            for item in flow_details['body']:
                try:
                    utc_time = datetime.strptime(item['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                    local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                    item['_source']['timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    pass
            flow_details['header'] = ['Timestamp','Source IP','Source Port','Destination IP','Destination Port']
            flow_details['keys'] = ['timestamp','src_ip','src_port','dest_ip',\
                                    'dest_port']
            flow_details['title'] = 'Flow'
            flow_details = json.dumps(flow_details, cls=DjangoJSONEncoder)
            return flow_details
        except Exception as ex:
            print "error",ex

    def flow_events(self,item, category):
        """
        Function for flow Details
        """
        try:
            date_obj = datetime.strptime(item,"%Y %b %d %H:%M")
            date_obj = pytz.timezone(self.timezone).localize(date_obj).astimezone(pytz.timezone("UTC"))
            from_date = date_obj.isoformat()
            if ((self.elsatic_interval).endswith('h')):
                to_date = date_obj + timedelta(hours=int((self.elsatic_interval)[:-1]))
            else:
                to_date = date_obj + timedelta(minutes= int((self.elsatic_interval)[:-1]))
            to_date = to_date.isoformat()   
            query_condition = [
                                    {
                                        "range":{
                                            "@timestamp":{
                                                "gte": from_date,
                                                "lte": to_date
                                            }
                                        }
                                    },
                                    { "bool" : {
                                        "should": self.hostquery
                                        }
                                    }
                                ]
            if category == "New flows":
                category = [
                            {
                              "query_string": {
                                    "query": "event_type:\"flow\" AND flow.state:\"new\""
                                }
                            }
                        ]
            elif category == "Established flows":
                category = [
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"established\""
                            }
                        }
                    ]
            elif category == "Closed flows":
                category = [
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"closed\""
                            }
                        }
                    ]

            return self.executeQuery(query_condition, category)
        except Exception as ex:
            print "exception",ex

    def packet_to_server(self,item):
        try:
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": time1
                            }
                        }
                    }
            else:
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": "now"
                            }
                        }
                    }
            query_condition = [
                                ranges,
                                {"term": {
                                    "flow.pkts_toserver":item
                                    }
                                },
                                { "bool" : {
                                    "should": self.hostquery
                                    }
                                }
                            ]
            category =  [
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"new\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"established\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"closed\""
                            }
                        }
                    ]
            return self.executeQuery(query_condition, category)
        except Exception as ex:
            print "exception",ex


    def packet_to_client(self,item):
        try:
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": time1
                            }
                        }
                    }
            else:
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": "now"
                            }
                        }
                    }
            query_condition = [
                                ranges,
                                {"term": {
                                    "flow.pkts_toclient": item
                                    }
                                },
                                { "bool" : {
                                    "should": self.hostquery
                                    }
                                }
                            ]
            category =  [
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"new\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"established\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"closed\""
                            }
                        }
                    ]
            return self.executeQuery(query_condition, category)
        except Exception as ex:
            print "exception",ex
    def bytes_to_server(self,item):
        try:
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": time1
                            }
                        }
                    }
            else:
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": "now"
                            }
                        }
                    }
            query_condition = [
                                ranges,
                                {"term": {
                                    "flow.bytes_toserver": item
                                    }
                                },
                                { "bool" : {
                                    "should": self.hostquery
                                    }
                                }
                            ]
            category =  [
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"new\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"established\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"closed\""
                            }
                        }
                    ]
            return self.executeQuery(query_condition, category)
        except Exception as ex:
            print "exception",ex


    def bytes_to_client(self,item):
        try:
            if self.base:
                base = datetime.strptime(self.base, '%Y.%m.%d')
                time = datetime.strptime(self.date_start, '%Y.%m.%d')
                time = time.isoformat()
                time1 = base.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": time1
                            }
                        }
                    }
            else:
                time = datetime.now() - timedelta(minutes=self.duration_info)
                time = time.isoformat()
                ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": "now"
                            }
                        }
                    }
            query_condition = [
                                ranges,
                                {"term": {
                                    "flow.bytes_toclient": item
                                    }
                                },
                                { "bool" : {
                                    "should": self.hostquery
                                    }
                                }
                            ]
            category =  [
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"new\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"established\""
                            }
                        },
                        {
                            "query_string": {
                                "query": "event_type:\"flow\" AND flow.state:\"closed\""
                            }
                        }
                    ]
            return self.executeQuery(query_condition, category)
        except Exception as ex:
            print "exception",ex
