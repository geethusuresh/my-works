import json

from django.http import HttpResponse

from dashboard.models import UserProfile


def admin_user_required(function):
    """
    custom decorator used for verifying
    current user is admin user or not.
    """
    def wrap(request, *args, **kwargs):

        profile = UserProfile.objects.get(user=request.user)
        if profile.is_admin:
            return function(request, *args, **kwargs)
        else:
            return HttpResponse(json.dumps({"error": "Admin user required"}), content_type="application/json")

    wrap.__name__=function.__name__
    return wrap
