import json
import pytz
import datetime

from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch

from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from common import CommonInfo, get_timezone

es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class TLSInfo:
    def __init__(self, filters, request=None):
        date_duration = filters['date_minutes']
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)
        self.base = date_duration['base']
        self.date_start = date_duration['base1']

        self.request = request
        self.timezone = get_timezone(self.request)

        hostid = filters['host_details']
        self.hostquery = []
        for hostitem in hostid:
            self.hostquery.append({"term": {"casbuid.raw": hostitem["ip"]}})

        try:
            self.additional_filters = []            
            self.additional_filters = CommonInfo().make_filter(filters)
        except:            
            pass

    def tls_event_details(self):
        """
        Function for TLS graph
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "0": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "event_type:\"tls\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            events_details = res['facets']['0']['entries']
            event_list = []
            for event_info in events_details:
                event_time = event_info['time'] / 1000
                time = datetime.datetime.fromtimestamp(event_time)
                local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(self.timezone))
                time = local_time.strftime("%Y %b %d %H:%M")
                event_count = int(event_info['count'])
                tooltip = "TLS/SSL Transactions{br} " + str(event_count) + " @ " + time
                event_list.append({"label": time, "value": event_count, "tooltext": tooltip})
            event_list = json.dumps(event_list, cls=DjangoJSONEncoder)
            return event_list

    def tls_subject(self):
        """
        Function for TLS Subject
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "tls.subject.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"tls\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            tls_details = res['facets']['terms']['terms']
            tls_list = []
            for tlsinfo in tls_details:
                tls_count = tlsinfo['count']
                tls_name = tlsinfo['term']
                tls_list.append({"label": tls_name, "value": tls_count})
            tls_list = json.dumps(tls_list, cls=DjangoJSONEncoder)
            return tls_list

    def tls_issuer_dn(self):
        """
        Function for TLS Issuer Dn
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "tls.issuerdn.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"tls\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            tls_details = res['facets']['terms']['terms']
            tls_list = []
            for tlsinfo in tls_details:
                tls_count = tlsinfo['count']
                tls_name = tlsinfo['term']
                tls_list.append({"label": tls_name, "value": tls_count})
            tls_list = json.dumps(tls_list, cls=DjangoJSONEncoder)
            return tls_list

    def tls_version_details(self):
        """
        Function for TLS version details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "tls.version.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"tls\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            version_details = res['facets']['terms']['terms']
            version_list = []
            for versioninfo in version_details:
                version_count = versioninfo['count']
                version_name = versioninfo['term']
                version_list.append({"label": version_name, "value": version_count})
            version_list = json.dumps(version_list, cls=DjangoJSONEncoder)
            return version_list

    def tls_finger_details(self):
        """
        Function for TLS finger print details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "tls.fingerprint.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"tls\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            finger_details = res['facets']['terms']['terms']
            finger_list = []
            for finger_item in finger_details:
                finger_name = finger_item['term']
                finger_count = finger_item['count']
                tooltext = finger_name + " (" + str(finger_count) + ")"
                finger_list.append({"label": finger_name, "value": finger_count, "tooltext": tooltext})
            finger_list = json.dumps(finger_list, cls=DjangoJSONEncoder)
            return finger_list

    def tls_port_details(self):
        """
        Function for TLS Port details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "dest_port",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"tls\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            port_details = res['facets']['terms']['terms']
            port_list = []
            for portinfo in port_details:
                port_count = portinfo['count']
                port_name = portinfo['term']
                port_list.append({"label": port_name, "value": port_count})
            port_list = json.dumps(port_list, cls=DjangoJSONEncoder)
            return port_list

    def tls_transaction_details(self):
        """
        Function for TLS Transaction details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "query": {
                    "filtered": {
                        "query": {
                            "bool": {
                                "should": [
                                    {
                                        "query_string": {
                                            "query": "event_type:\"tls\""
                                        }
                                    }
                                ]
                            }
                        },
                        "filter": {
                            "bool": {
                                "must": [
                                        ranges,
                                    { "bool" : {
                                        "should": self.hostquery
                                        }
                                    }
                                ],
                                "should": self.additional_filters
                            }
                        }
                    }
                },
                "highlight": {
                    "fields": {},
                    "fragment_size": 2147483647,
                    "pre_tags": [
                        "@start-highlight@"
                    ],
                    "post_tags": [
                        "@end-highlight@"
                    ]
                },
                "size": 500,
                "sort": [
                    {
                        "@timestamp": {
                            "order": "desc"
                        }
                    }
                ]
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            trans_details = res['hits']['hits']
            for item in trans_details:
                try:
                    utc_time = datetime.datetime.strptime(item['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                    local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                    item['_source']['timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    pass
            trans_details = json.dumps(trans_details, cls=DjangoJSONEncoder)
            return trans_details

    def tls_trend(self):
        """
        Function for TLS Trend Details
        """

        index_range = self.index_range + self.index_range
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
        else:
            base = datetime.datetime.today()
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        # time calculation for 1 day trend
        time = datetime.datetime.now() - datetime.timedelta(minutes=self.duration_info)
        time_1day_new_from = time.isoformat()

        time_1day = time - datetime.timedelta(days=1)
        time_1day_old_from = time_1day.isoformat()

        time_1day_old = time_1day + datetime.timedelta(minutes=self.duration_info)
        time_1day_old_to = time_1day_old.isoformat()

        # time calculation for 4 hour trend
        time = datetime.datetime.now() - datetime.timedelta(minutes=self.duration_info)
        time_4hour_new_from = time.isoformat()

        time_4hours = time - datetime.timedelta(hours=4)
        time_4hours_old_from = time_4hours.isoformat()

        time_4hour_old = time_4hours + datetime.timedelta(minutes=self.duration_info)
        time_4hour_old_to = time_4hour_old.isoformat()

        # time calculation for 1 hour trend
        time = datetime.datetime.now() - datetime.timedelta(minutes=self.duration_info)
        time_1hour_new_from = time.isoformat()

        time_1hours = time - datetime.timedelta(hours=1)
        time_1hours_old_from = time_1hours.isoformat()

        time_1hour_old = time_1hours + datetime.timedelta(minutes=self.duration_info)
        time_1hour_old_to = time_1hour_old.isoformat()

        query = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"tls\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1day_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"tls\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1day_old_from,
                                                    "to": time_1day_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        # print query

        query1 = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"tls\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_4hour_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"tls\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_4hours_old_from,
                                                    "to": time_4hour_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        # print query1

        query2 = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"tls\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1hour_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"tls\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1hours_old_from,
                                                    "to": time_1hour_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        # print query2

        tls_trend_details = {}
        # calculation for 1 day trend
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        count_1day_new = res['facets']['0']['count']
        count_1day_old = res['facets']['old_0']['count']

        if count_1day_old > 0:
            perc_1day = (float(count_1day_new) / float(count_1day_old)) * float(100)
            percent_diff_1day = perc_1day - 100
            percent_diff_1day = round(percent_diff_1day, 2)
        else:
            # percent_diff_1day = float(count_1day_new) * float(100)
            percent_diff_1day = "?"

        # calculation for 4 hour trend
        res = es.search(index=index_list, body=query1, ignore_unavailable=index_list)
        count_4hour_new = res['facets']['0']['count']
        count_4hour_old = res['facets']['old_0']['count']

        if count_4hour_old > 0:
            perc_4hour = (float(count_4hour_new) / float(count_4hour_old)) * float(100)
            percent_diff_4hour = perc_4hour - 100
            percent_diff_4hour = round(percent_diff_4hour, 2)
        else:
            # percent_diff_4hour = float(count_4hour_new) * float(100)
            percent_diff_4hour = "?"

        # calculation for 1 hour trend
        res = es.search(index=index_list, body=query2, ignore_unavailable=index_list)
        count_1hour_new = res['facets']['0']['count']
        count_1hour_old = res['facets']['old_0']['count']

        if count_1hour_old > 0:
            perc_1hour = (float(count_1hour_new) / float(count_1hour_old)) * float(100)
            percent_diff_1hour = perc_1hour - 100
            percent_diff_1hour = round(percent_diff_1hour, 2)
        else:
            # percent_diff_1hour = float(count_1hour_new) * float(100)
            percent_diff_1hour = "?"

        tls_trend_details = {"count_1day_new": count_1day_new, "count_1day_old": count_1day_old,
                             "perc_1day": percent_diff_1day, "count_4hour_new": count_4hour_new,
                             "count_4hour_old": count_4hour_old, "perc_4hour": percent_diff_4hour,
                             "count_1hour_new": count_1hour_new, "count_1hour_old": count_1hour_old,
                             "perc_1hour": percent_diff_1hour}

        tls_trend_details = json.dumps(tls_trend_details, cls=DjangoJSONEncoder)
        return tls_trend_details

    def tls_world(self):
        """
        Function for TLS world map Details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.continent_code",
                        "size": 100,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"tls\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})

        # map_info.append({"id":"23","value":"2340"})
        # map_info.append({"id":"104","value":"123"})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info

    def tls_usa(self):
        """
        Function for tls usa map Details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.region_name.raw",
                        "size": 100,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"tls\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info
