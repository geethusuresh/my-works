import json
import datetime

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core.serializers.json import DjangoJSONEncoder
from django.views.decorators.csrf import csrf_exempt

from elasticsearch import Elasticsearch

from dashboard.models import UserProfile, Customer, Watchlist, Severity
from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from common import CommonInfo


es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class EventGroupInfo:
    """
    Class for Event grouping
    """

    def __init__(self,filters):
        date_duration = filters['date_minutes']
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.base = date_duration['base']
        self.date_start = date_duration['base1']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)

        hostid = filters['host_details']
        self.hostquery = []
        for hostitem in hostid:
            self.hostquery.append({"term": {"casbuid.raw": hostitem["ip"]}})

        try:
            self.additional_filters = []            
            self.additional_filters = CommonInfo().make_filter(filters)
        except:            
            pass

    def alert_group(self, request, action, group_item):
        """
        function for alert grouping
        """               

        userprofile = UserProfile.objects.get(user=request.user)

        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": time1
                            }
                        }
                    }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()                       
            ranges = {
                        "range": {
                            "@timestamp": {
                                "from": time,
                                "to": "now"
                            }
                        }
                    }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        group_condition = CommonInfo().events_group_condition(action,group_item)

        if index_list:
            query = { 
                      "aggs" : {
                            "alert_group" : group_condition               
                        },
                        "query": {
                            "filtered": {
                                "query": {
                                    "bool": {
                                        "should": [
                                            {
                                                "query_string": {
                                                    "query": "event_type:\"alert\""
                                                }
                                            }
                                        ]
                                    }
                                },
                                "filter": {
                                    "bool": {
                                        "must": [
                                            ranges,
                                            { "bool" : {
                                                    "should": self.hostquery
                                                }
                                            }
                                        ],
                                        "should": self.additional_filters                            
                                    }
                                }
                            }
                        }                                                  
                    }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)                        
            alerts_info = res['hits']['hits']            
            total_count = len(alerts_info)            
            aggregation = res['aggregations']
            
            agg_info = []
            if aggregation:
                for agg_item in aggregation['alert_group']['buckets']:
                    alert_sig = agg_item['key']
                    alert_count = agg_item['doc_count']
                    alert_severity = []
                    for sev_item in agg_item['alert_severity']['buckets']:                        
                        severity_details = Severity.objects.get(customer=userprofile.customer, severity_number=int(sev_item['key']))
                        alert_severity.append({"sev_name":severity_details.priority,"sev_color":severity_details.color,"sev_count":sev_item['doc_count']})
                    agg_info.append({"sig":alert_sig,"count":alert_count,"risk":alert_severity})
            agg_info = json.dumps(agg_info,cls=DjangoJSONEncoder)
            return agg_info










