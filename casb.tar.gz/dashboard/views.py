import ast
import sys
import json
import pytz
import requests
import traceback
from datetime import datetime, timedelta

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core import serializers
from django.core.serializers.json import DjangoJSONEncoder
from django.template.loader import get_template
from django.http import HttpResponse
from django.http import StreamingHttpResponse
from django.core.validators import URLValidator
from django.core.exceptions import ValidationError
from django.conf import settings

import postfile
from dateutil import parser
import ssl
import socket

from casb.settings import ONECONSOLE_API_URL, ONECONSOLE_API_DOMAIN
from dashboard.alerts import AlertInfo
from dashboard.http import HttpInfo
from dashboard.ssh import SSHInfo
from dashboard.tls import TLSInfo
from dashboard.privacy import PrivacyInfo
from dashboard.http_extended import HttpExtendedDashboardAjax
from dashboard.flow import FlowDashboardAjax
from dashboard.file import FileDashboardAjax
from dashboard.common import CommonInfo, get_timezone
from dashboard.infra import InfraInfo
from dashboard.alert_popup import *
from dashboard.http_popup import *
from dashboard.tls_popup import *
from dashboard.file_popup import *
from dashboard.privacy_popup import *
from dashboard.ssh_popup import *
from dashboard.flow_popup import *
from dashboard.profile import ProfileInfo
from dashboard.models import UserProfile, Customer, PreventionSettings, BlockedIPS, Severity, HostInfo,\
    CloudProvider, DefaultDashsettings, Dashsettings, DashboardSettings, Help, HttpTraffic, Services, Watchlist,\
    Filters
from threat_intelligence.models import IpIntelligenceConfiguration, VirusScanConfiguration, OpswatVirusScanConfiguration
from dashboard.watchlist import WatchListInfo
from dashboard.group import EventGroupInfo
from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from casb.settings import SITE_ROOT

es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)

class CasbDashboard(View):
    def get(self, request, *args, **kwargs):
        userprofile = UserProfile.objects.get(user=request.user)
        if not userprofile.theme or userprofile.theme.isspace():
            userprofile.theme = "custom"
            userprofile.save()

        if userprofile.theme == "dark":
            graph_theme = "carbon"
        else:
            graph_theme = "zune"   
                 
        c = RequestContext(request, {"profile": userprofile, "graph_theme": graph_theme})
        return render(request, 'dashboard/dashboard.html', context_instance=c)


class HttpDashboard(View):
    """
    Class for Http Dashboard view
    """
    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/http_dashboard.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        if request.is_ajax():
            if request.POST:
                graph_type = request.POST.get('graph_type')
                duration = request.POST.get('duration')
                host_id = request.POST.get('host')
                custome_date = request.POST.get('custome_date')
                optional_filter = request.POST.get('optional_filter')

                if optional_filter:
                    optional_filter = json.loads(optional_filter)
                               
                date_minutes = CommonInfo().duration_details(duration, custome_date)
                host_details = CommonInfo().hostdetails_from_id(request, host_id)
                filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

                if graph_type == "http_events":
                    events_details = HttpInfo(filters, request=request).httpeventdetails()
                    return HttpResponse(events_details, content_type="application/json")
                elif graph_type == "http_trend":
                    trend_details = HttpInfo(filters).http_trend()
                    return HttpResponse(trend_details, content_type="application/json")
                elif graph_type == "http_useragent":
                    useragent_details = HttpInfo(filters).httpuseragent()
                    return HttpResponse(useragent_details, content_type="application/json")
                elif graph_type == "http_method":
                    httpmethod_details = HttpInfo(filters).httpmethod_details()
                    return HttpResponse(httpmethod_details, content_type="application/json")
                elif graph_type == "http_hostname":
                    http_hostname = HttpInfo(filters).httphostname_details()
                    return HttpResponse(http_hostname, content_type="application/json")
                elif graph_type == "http_status":
                    http_status = HttpInfo(filters).httpstatus_details()
                    return HttpResponse(http_status, content_type="application/json")
                elif graph_type == "http_referels":
                    http_referls = HttpInfo(filters).httprefer_details()
                    return HttpResponse(http_referls, content_type="application/json")
                elif graph_type == "transaction_details":
                    http_transaction = HttpInfo(filters, request=request).transaction_details()
                    return HttpResponse(http_transaction, content_type="application/json")
                elif graph_type == "http_world":
                    world_details = HttpInfo(filters).http_world()
                    return HttpResponse(world_details, content_type="application/json")
                elif graph_type == "http_usa":
                    usa_details = HttpInfo(filters).http_usa()
                    return HttpResponse(usa_details, content_type="application/json")
                elif graph_type == "http_url":
                    url_details = HttpInfo(filters).getHttpUrl()
                    return HttpResponse(url_details, content_type="application/json")
                elif graph_type == "http_host_inbound":
                    http_hostname = HttpInfo(filters).http_inbound_details()
                    return HttpResponse(http_hostname, content_type="application/json")


class AlertsDashboard(View):
    """
    Class for Alerts Dashboard view
    """

    def createTicket(self, request):
        try:
            ticket_details = ast.literal_eval(request.POST['alertdetails'])            
            headers = {'content-type': 'application/json'}
            url = ONECONSOLE_API_URL + 'casb_ticket_create/?format=json'            
            for detail in ticket_details.keys():
                event_details = ticket_details[detail]                                                                                
                result = requests.get(url=url, params=ticket_details[detail], headers=headers)            
                ticket_id = result.text            
            status = {"status": "success","ticketid":ticket_id}
            status = json.dumps(status, cls=DjangoJSONEncoder)
            return status
        except:
            traceback.print_exc()
            status = {"status": "error"}
            status = json.dumps(status, cls=DjangoJSONEncoder)
            return status

    def loadTicket(self, request):
        try:
            headers = {'content-type': 'application/json'}
            url = ONECONSOLE_API_URL+'casb_ticket_get/?format=json'
            result = requests.get(url=url, headers=headers)
            final_response = json.dumps(result.json(), cls=DjangoJSONEncoder)
            final_response = json.loads(final_response)
            for item in final_response['objects']:
                created_utc_time = datetime.strptime(item['creationdate'], '%Y-%m-%dT%H:%M:%S.%f')
                created_local_time = pytz.timezone("UTC").localize(created_utc_time).astimezone(
                    pytz.timezone(get_timezone(request)))
                item['creationdate'] = created_local_time.strftime("%Y-%m-%d %H:%M:%S")
            return json.dumps(final_response)
        except:
            traceback.print_exc()    

    def post(self, request, *args, **kwargs):
        try:
            if request.is_ajax():
                if request.POST:
                    graph_type = request.POST.get('graph_type')
                    duration = request.POST.get('duration')
                    host_id = request.POST.get('host')
                    custome_date = request.POST.get('custome_date')
                    date_minutes = CommonInfo().duration_details(duration, custome_date)
                    optional_filter = request.POST.get('optional_filter')
                    if optional_filter:
                        optional_filter = json.loads(optional_filter)                    

                    host_details = CommonInfo().hostdetails_from_id(request, host_id)
                    filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

                    if graph_type == "alert_events":
                        events_details = AlertInfo(filters, request=request).alerteventdetails()
                        return HttpResponse(events_details, content_type="application/json")
                    elif graph_type == "alert_signatures":
                        alert_sig = AlertInfo(filters).alertsigdetails()
                        return HttpResponse(alert_sig, content_type="application/json")
                    elif graph_type == "alert_siverity":
                        alert_siv = AlertInfo(filters).alertsevdetails()
                        return HttpResponse(alert_siv, content_type="application/json")
                    elif graph_type == "alert_categories":
                        categories = AlertInfo(filters).categorydetails()
                        return HttpResponse(categories, content_type="application/json")
                    elif graph_type == "alert_details":
                        alert_details = AlertInfo(filters, request).alert()
                        return HttpResponse(alert_details, content_type="application/json")
                    elif graph_type == "alert_trend":
                        alert_trend_details = AlertInfo(filters).alert_trend()
                        return HttpResponse(alert_trend_details, content_type="application/json")
                    elif graph_type == "alert_world":
                        alert_world_details = AlertInfo(filters).alert_world()
                        return HttpResponse(alert_world_details, content_type="application/json")
                    elif graph_type == "alert_usa":
                        alert_usa_details = AlertInfo(filters).alert_usa()
                        return HttpResponse(alert_usa_details, content_type="application/json")
                    elif graph_type == "create_ticket":
                        result = self.createTicket(request)
                        return HttpResponse(result, content_type="application/json")
                    elif graph_type == "load_ticket":
                        result = self.loadTicket(request)
                        return HttpResponse(result, content_type="application/json")
        except:
            traceback.print_exc()


class SshDashboard(View):
    """
    Class for SSH Dashboard view
    """

    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/ssh_dashboard.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        if request.is_ajax():
            if request.POST:
                graph_type = request.POST.get('graph_type')
                duration = request.POST.get('duration')
                host_id = request.POST.get('host')
                custome_date = request.POST.get('custome_date')
                optional_filter = request.POST.get('optional_filter')
                if optional_filter:
                    optional_filter = json.loads(optional_filter)

                date_minutes = CommonInfo().duration_details(duration, custome_date)
                host_details = CommonInfo().hostdetails_from_id(request, host_id)
                filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

                if graph_type == "ssh_events":
                    ssh_events = SSHInfo(filters, request=request).ssheventdetails()
                    return HttpResponse(ssh_events, content_type="application/json")
                elif graph_type == "ssh_clientversion":
                    ssh_version = SSHInfo(filters).sshclientdetails()
                    return HttpResponse(ssh_version, content_type="application/json")
                elif graph_type == "ssh_serverversion":
                    ssh_version = SSHInfo(filters).sshserverdetails()
                    return HttpResponse(ssh_version, content_type="application/json")
                elif graph_type == "ssh_ports":
                    ssh_ports = SSHInfo(filters).sshportsdetails()
                    return HttpResponse(ssh_ports, content_type="application/json")
                elif graph_type == "ssh_server_protocol":
                    ssh_ser_proto = SSHInfo(filters).sshserverproto()
                    return HttpResponse(ssh_ser_proto, content_type="application/json")
                elif graph_type == "ssh_client_protocol":
                    ssh_client_proto = SSHInfo(filters).sshclientproto()
                    return HttpResponse(ssh_client_proto, content_type="application/json")
                elif graph_type == "ssh_transaction":
                    ssh_trans = SSHInfo(filters, request=request).ssh_transaction()
                    return HttpResponse(ssh_trans, content_type="application/json")
                elif graph_type == "ssh_trend":
                    ssh_trend_details = SSHInfo(filters).ssh_trend()
                    return HttpResponse(ssh_trend_details, content_type="application/json")
                elif graph_type == "ssh_world":
                    ssh_world_details = SSHInfo(filters).ssh_world()
                    return HttpResponse(ssh_world_details, content_type="application/json")
                elif graph_type == "ssh_usa":
                    ssh_usa_details = SSHInfo(filters).ssh_usa()
                    return HttpResponse(ssh_usa_details, content_type="application/json")


class TlsDashboard(View):
    """
    Class for TLS Dashboard view
    """

    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/tls_dashboard.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        if request.is_ajax():
            if request.POST:
                graph_type = request.POST.get('graph_type')
                duration = request.POST.get('duration')
                host_id = request.POST.get('host')
                custome_date = request.POST.get('custome_date')
                optional_filter = request.POST.get('optional_filter')
                if optional_filter:
                    optional_filter = json.loads(optional_filter)

                date_minutes = CommonInfo().duration_details(duration, custome_date)
                host_details = CommonInfo().hostdetails_from_id(request, host_id)
                filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

                if graph_type == "tls_events":
                    tls_events = TLSInfo(filters, request=request).tls_event_details()
                    return HttpResponse(tls_events, content_type="application/json")
                elif graph_type == "tls_subject":
                    tls_subject = TLSInfo(filters).tls_subject()
                    return HttpResponse(tls_subject, content_type="application/json")
                elif graph_type == "tls_issuerdn":
                    tls_dn = TLSInfo(filters).tls_issuer_dn()
                    return HttpResponse(tls_dn, content_type="application/json")
                elif graph_type == "tls_version":
                    tls_version = TLSInfo(filters).tls_version_details()
                    return HttpResponse(tls_version, content_type="application/json")
                elif graph_type == "tls_finger":
                    tls_finger = TLSInfo(filters).tls_finger_details()
                    return HttpResponse(tls_finger, content_type="application/json")
                elif graph_type == "tls_ports":
                    tls_ports = TLSInfo(filters).tls_port_details()
                    return HttpResponse(tls_ports, content_type="application/json")
                elif graph_type == "tls_transaction":
                    tls_trans = TLSInfo(filters, request=request).tls_transaction_details()
                    return HttpResponse(tls_trans, content_type="application/json")
                elif graph_type == "tls_trend":
                    trend_details = TLSInfo(filters).tls_trend()
                    return HttpResponse(trend_details, content_type="application/json")
                elif graph_type == "tls_world":
                    world_details = TLSInfo(filters).tls_world()
                    return HttpResponse(world_details, content_type="application/json")
                elif graph_type == "tls_usa":
                    usa_details = TLSInfo(filters).tls_usa()
                    return HttpResponse(usa_details, content_type="application/json")


class PrivacyDashboard(View):
    """
    Class for Privacy Dashboard view
    """

    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/privacy_dashboard.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        if request.is_ajax():
            if request.POST:
                graph_type = request.POST.get('graph_type')
                duration = request.POST.get('duration')
                host_id = request.POST.get('host')
                custome_date = request.POST.get('custome_date')
                optional_filter = request.POST.get('optional_filter')
                if optional_filter:
                    optional_filter = json.loads(optional_filter)  

                date_minutes = CommonInfo().duration_details(duration, custome_date)
                host_details = CommonInfo().hostdetails_from_id(request, host_id)
                filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

                if graph_type == "privacy_events":
                    privacy_events = PrivacyInfo(filters, request=request).privacy_event_details()
                    return HttpResponse(privacy_events, content_type="application/json")
                elif graph_type == "facebook":
                    privacy_events = PrivacyInfo(filters).facebook_event_details()
                    return HttpResponse(privacy_events, content_type="application/json")
                elif graph_type == "twitter":
                    privacy_events = PrivacyInfo(filters).twitter_event_details()
                    return HttpResponse(privacy_events, content_type="application/json")
                elif graph_type == "analytics":
                    privacy_events = PrivacyInfo(filters).analytics_event_details()
                    return HttpResponse(privacy_events, content_type="application/json")
                elif graph_type == "hostname":
                    privacy_events = PrivacyInfo(filters).hostname_event_details()
                    return HttpResponse(privacy_events, content_type="application/json")
                elif graph_type == "documents":
                    privacy_events = PrivacyInfo(filters, request=request).document_event_details()
                    return HttpResponse(privacy_events, content_type="application/json")
                elif graph_type == "https_world":
                    result = PrivacyInfo(filters).getHttpsWorld()
                    return HttpResponse(result, content_type="application/json")
                elif graph_type == "http_world":
                    result = PrivacyInfo(filters).getHttpWorld()
                    return HttpResponse(result, content_type="application/json")
                elif graph_type == "http_usa":
                    result = PrivacyInfo(filters).getHttpUSA()
                    return HttpResponse(result, content_type="application/json")


class HttpExtendedDashboard(View):
    """
    Class handles all request from HTTP EXTENDED dashboard
    """

    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/http_extended_dashboard.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        graph_type = request.POST.get('type')
        if graph_type == "events_graph":
            result = HttpExtendedDashboardAjax().getTimeChart()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_url":
            result = HttpExtendedDashboardAjax().getHttpUrl()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_hostname":
            result = HttpExtendedDashboardAjax().getHttpHostname()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_content_type":
            result = HttpExtendedDashboardAjax().getHttpContentType()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_user_agent":
            result = HttpExtendedDashboardAjax().getUserAgent()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_accept_encoding":
            result = HttpExtendedDashboardAjax().getAcceptEncoding()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_xff":
            result = HttpExtendedDashboardAjax().getXff()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_method":
            result = HttpExtendedDashboardAjax().getHttpMethod()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_length":
            result = HttpExtendedDashboardAjax().getHttpLength()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_status_code":
            result = HttpExtendedDashboardAjax().getHttpStatusCode()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "http_documents":
            result = HttpExtendedDashboardAjax().getHttpDocuments()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "tcp_flags_client":
            result = FlowDashboardAjax().getTcpFlagsClient()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "tcp_flags_server":
            result = FlowDashboardAjax().getTcpFlagsServer()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "documents":
            result = FlowDashboardAjax().getDocuments()
            return HttpResponse(result, content_type="application/json")


class FlowDashboard(View):
    """
    Class handles all request from FLOW dashboard
    """

    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/flow_dashboard.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        graph_type = request.POST.get('type')
        duration = request.POST.get('duration')
        host_id = request.POST.get('host')
        custome_date = request.POST.get('custome_date')
        optional_filter = request.POST.get('optional_filter')
        if optional_filter:
            optional_filter = json.loads(optional_filter)

        date_minutes = CommonInfo().duration_details(duration, custome_date)
        host_details = CommonInfo().hostdetails_from_id(request, host_id)
        filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

        if graph_type == "events_graph":
            events_details = FlowDashboardAjax(filters, request=request).getHistogram()
            return HttpResponse(events_details, content_type="application/date_minutesjson")
        elif graph_type == "destination_port":
            destination_port_details = FlowDashboardAjax(filters).getDestinationPort()
            return HttpResponse(destination_port_details, content_type="application/json")
        elif graph_type == "source_port":
            source_port = FlowDashboardAjax(filters).getSourcePort()
            return HttpResponse(source_port, content_type="application/json")
        elif graph_type == "destination_ip":
            destination_ip = FlowDashboardAjax(filters).getDestinationIP()
            return HttpResponse(destination_ip, content_type="application/json")
        elif graph_type == "source_ip":
            source_ip = FlowDashboardAjax(filters).getSourceIP()
            return HttpResponse(source_ip, content_type="application/json")
        elif graph_type == "bytes_to_client":
            result = FlowDashboardAjax(filters).getBytestoClient()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "bytes_to_server":
            result = FlowDashboardAjax(filters).getBytestoServer()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "packets_to_client":
            result = FlowDashboardAjax(filters).getPacketstoClient()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "packets_to_server":
            result = FlowDashboardAjax(filters).getPacketstoServer()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "tcp_state":
            result = FlowDashboardAjax(filters).getTcpState()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "tcp_flags":
            result = FlowDashboardAjax(filters).getTcpFlags()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "tcp_flags_client":
            result = FlowDashboardAjax(filters).getTcpFlagsClient()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "tcp_flags_server":
            result = FlowDashboardAjax(filters).getTcpFlagsServer()
            return HttpResponse(result, content_type="application/json")
        elif graph_type == "documents":
            result = FlowDashboardAjax(filters, request=request).getDocuments()
            return HttpResponse(result, content_type="application/json")


class FileDashboard(View):
    """
    Class handles all request from file transaction dashboard
    """

    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/file_dashboard.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        try:
            graph_type = request.POST.get('type')
            duration = request.POST.get('duration')
            host_id = request.POST.get('host')
            custome_date = request.POST.get('custome_date')
            optional_filter = request.POST.get('optional_filter')
            if optional_filter:
                optional_filter = json.loads(optional_filter)

            date_minutes = CommonInfo().duration_details(duration, custome_date)
            host_details = CommonInfo().hostdetails_from_id(request, host_id)
            filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

            if graph_type == "events_graph":
                events_details = FileDashboardAjax(filters, request=request).getEvents()
                return HttpResponse(events_details, content_type="application/json")
            elif graph_type == "downloadedfiles":
                downloadedfiles_details = FileDashboardAjax(filters).getDownloadedFiles()
                return HttpResponse(downloadedfiles_details, content_type="application/json")
            elif graph_type == "typesoffiles":
                types_of_files = FileDashboardAjax(filters).getTypesofFiles()
                return HttpResponse(types_of_files, content_type="application/json")
            elif graph_type == "total_hits":
                total_hits = FileDashboardAjax(filters).getTotalHits()
                return HttpResponse(total_hits, content_type="application/json")
            elif graph_type == "top_destination_ip":
                top_destination_ips = FileDashboardAjax(filters).getTopDestinationIP()
                return HttpResponse(top_destination_ips, content_type="application/json")
            elif graph_type == "top_destination_port":
                top_destination_ports = FileDashboardAjax(filters).getTopDestinationPORT()
                return HttpResponse(top_destination_ports, content_type="application/json")
            elif graph_type == "top_src_ip":
                top_src_ip = FileDashboardAjax(filters).getTopSrcIP()
                return HttpResponse(top_src_ip, content_type="application/json")
            elif graph_type == "top_src_port":
                top_src_ports = FileDashboardAjax(filters).getTopSrcPort()
                return HttpResponse(top_src_ports, content_type="application/json")
            elif graph_type == "file_transactions":
                file_transactions = FileDashboardAjax(filters).getFileTransactions()
                return HttpResponse(file_transactions, content_type="application/json")
            elif graph_type == "trend":
                trends = FileDashboardAjax(filters).getTrends()
                return HttpResponse(trends, content_type="application/json")
            elif graph_type == "world":
                result = FileDashboardAjax(filters).getWorldData()
                return HttpResponse(result, content_type="application/json")
            elif graph_type == "usa":
                result = FileDashboardAjax(filters).getUSAData()
                return HttpResponse(result, content_type="application/json")
        except:
            traceback.print_exc()


class ProxyDashboard(View):
    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'dashboard/proxy_analyzer.html', context_instance=c)


class CustomerHost(View):
    """
    Class handles all customer host details
    """
    def post(self, request, *args, **kwargs):
        selected_hosts = request.POST.get('selected_host')
        hostdetails = CommonInfo().customer_hosts(request, selected_hosts)
        return HttpResponse(hostdetails, content_type="application/json")


class CasbSettings(View):
    """
    Class for handle all casb settings
    """
    def post(self, request, *args, **kwargs):
        settings_info = {"api_domain": ONECONSOLE_API_DOMAIN}
        settings_info = json.dumps(settings_info, cls=DjangoJSONEncoder)
        return HttpResponse(settings_info, content_type="application/json")


class InfraDashboard(View):
    """
    Class for handles infra dashboard details
    """

    def post(self, request, *args, **kwargs):
        duration = request.POST.get('duration')
        custome_date = request.POST.get('custome_date')
        date_minutes = CommonInfo().duration_details(duration, custome_date)

        userprofile = UserProfile.objects.get(user=request.user)
        cloud_obj = CloudProvider.objects.filter(customer=userprofile.customer)
        infra_details = []
        cloud_details = []
        infra_alert = []
        for cloud_item in cloud_obj:
            hostdetails = HostInfo.objects.filter(cloud=cloud_item, customer=userprofile.customer)
            host_details = []
            for hostinfo in hostdetails:
                filters = {"date_minutes": date_minutes, "host_details": hostinfo.host}
                alert_details = InfraInfo(filters).host_alerts()
                host_details.append({"name": hostinfo.hostname, "parent": cloud_item.cloud,
                                     "icon": "/static/images/server-icon.png",
                                     "children": [{"name": "Alerts", "parent": hostinfo.hostname,
                                                   "icon": "/static/images/alerts.png", "_children": alert_details}]})
            cloud_details.append({"name": cloud_item.cloud, "parent": userprofile.customer.customername,
                                  "icon": "/static/images/cloud-icon.png", "children": host_details})
        infra_details = [{"name": userprofile.customer.customername, "parent": "null", "children": cloud_details}]
        infra_details = json.dumps(infra_details, cls=DjangoJSONEncoder)
        return HttpResponse(infra_details, content_type="application/json")


class SaveDashboard(View):
    """
    Class for saving dashboard details
    """

    def post(self, request, *args, **kwargs):
        userprofile = UserProfile.objects.get(user=request.user)
        dash_type = request.POST.get('dash_type')
        widgets = request.POST.get('widgets')
        try:
            Dashsettings.objects.filter(user=userprofile, dashboard=dash_type).delete()
            Dashsettings.objects.create(user=userprofile, dashboard=dash_type, settings_info=widgets, active=True)
            status = "success"
        except:
            status = "failed"
        status_details = json.dumps({"status": status}, cls=DjangoJSONEncoder)
        return HttpResponse(status_details, content_type="application/json")


class WidgetInfo(View):
    """
    Class for getting widget details
    """
    def post(self, request, *args, **kwargs):
        userprofile = UserProfile.objects.get(user=request.user)
        dash_type = request.POST.get('dash_type')
        user_dashinfo = Dashsettings.objects.get(user=userprofile, dashboard=dash_type, active=True)
        widget_details = user_dashinfo.settings_info
        return HttpResponse(widget_details, content_type="application/json")


class RestoreDash(View):
    """
    Class for getting restore details
    """
    def post(self, request, *args, **kwargs):
        userprofile = UserProfile.objects.get(user=request.user)
        dash_type = request.POST.get('dash_type')
        default_dashboard = DefaultDashsettings.objects.get(dashboard=dash_type)
        default_settings = default_dashboard.settings_info
        try:
            Dashsettings.objects.filter(user=userprofile, dashboard=dash_type,
                                        active=True).update(settings_info=default_settings)
            status = {"status": "success"}
        except:
            status = {"status": "error"}
        status_details = json.dumps(status, cls=DjangoJSONEncoder)
        return HttpResponse(status_details, content_type="application/json")


class DashboardInfo(View):
    """
    Class for getting dashboard details
    """
    def post(self, request, *args, **kwargs):
        userprofile = UserProfile.objects.get(user=request.user)
        dashboard_details = DefaultDashsettings.objects.all()
        dash_details = []
        dash_graph = {}
        for dash_info in dashboard_details:
            dash_details.append({"dashboard": dash_info.dashboard,"display_name":dash_info.display_name})
            # dash_graph[dash_info.dashboard] = dash_info.settings_info
        dashboard_obj = {"dash_info": dash_details}
        dashboard_obj = json.dumps(dashboard_obj, cls=DjangoJSONEncoder)
        return HttpResponse(dashboard_obj, content_type="application/json")


class DashGraphInfo(View):
    """
    Class for getting dashboard graph details
    """
    def post(self, request, *args, **kwargs):
        userprofile = UserProfile.objects.get(user=request.user)
        dash_info = request.POST.get('dashboard_info')
        graph_details = DefaultDashsettings.objects.get(dashboard=dash_info)
        graph_info = graph_details.settings_info
        return HttpResponse(graph_info, content_type="application/json")


class IntrusionPrevention(View):
    """
    Class is for intrusion prevention
    """
    def post(self,request,*args,**kwargs):
        userprofile = UserProfile.objects.get(user=request.user)        
        try:
            final_response = {}
            if request.POST.get('action') == 'delete_prevention':
                PreventionSettings.objects.filter(id = request.POST.get('prevention_id')).delete()
            if request.POST.get('action') == 'delete_waiting_block':
                BlockedIPS.objects.filter(id = request.POST.get('ip_id')).delete()                             
            elif request.POST.get('action') == 'start_prevention':
                severities = request.POST.get('severities')
                host_info = request.POST.get('host')
                sev_obj = Severity.objects.get(id = severities)
                host_obj = HostInfo.objects.get(id = host_info)
                prev_count = PreventionSettings.objects.filter(host = host_obj,severity = sev_obj).count()

                #checking for duplication
                if prev_count == 0:
                    PreventionSettings.objects.create(host = host_obj,severity = sev_obj)
                else:
                    final_response['prev_status'] = "existing"
                #end duplication check

            elif request.POST.get('action') == 'disable':
                prevention_id = request.POST.get('prev_id')
                PreventionSettings.objects.filter(id = prevention_id).update(active=False)               

            elif request.POST.get('action') == 'enable':
                prevention_id = request.POST.get('prev_id')
                PreventionSettings.objects.filter(id = prevention_id).update(active=True)

            elif request.POST.get('action') == 'off':
                prevention_id = request.POST.get('prev_id')
                unblock_interval = request.POST.get('duration')
                time_in = request.POST.get('type')
                if time_in == 'hour':
                    unblock_interval = int(unblock_interval) * 60
                print 'xxx', unblock_interval
                PreventionSettings.objects.filter(id = prevention_id).update(auto_unblock=False, unblock_interval=unblock_interval)            

            elif request.POST.get('action') == 'on':
                prevention_id = request.POST.get('prev_id')
                unblock_interval = request.POST.get('duration')
                time_in = request.POST.get('type')
                if time_in == 'hour':
                    unblock_interval = int(unblock_interval) * 60
                print 'xxx', unblock_interval
                PreventionSettings.objects.filter(id = prevention_id).update(auto_unblock=True, unblock_interval=unblock_interval)

            elif request.POST.get('action') == 'unblock':
                try:
                    unblock_id = request.POST.get('unblock_id')
                    unblock_obj = BlockedIPS.objects.get(id=unblock_id)
                    unblock_obj.status = 4
                    unblock_obj.save()

                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    ssl_sock = ssl.wrap_socket(s, ca_certs=SITE_ROOT + "/server.crt",
                                                cert_reqs=ssl.CERT_REQUIRED)
                    ssl_sock.settimeout(3)
                    ssl_sock.connect(('192.168.61.118', 9856))
                    send_str = 'allow' + "," + unblock_obj.blocked_ip
                    ssl_sock.write(send_str)
                    unblock_obj.delete()
                    # ssl_sock.settimeout(3)
                    # response = ssl_sock.read(1024)
                    # unblock_obj.process_status = response
                    # unblock_obj.status = 2
                    # unblock_obj.last_updated = datetime.datetime.now()
                    # unblock_obj.save()
                except Exception as e:
                    print e
                    unblock_obj.process_status = "Didn't get response from Host"
                    unblock_obj.save()

            elif request.POST.get('action') == 'auto_unblock':
                unblock_interval = request.POST.get('duration')
                time_in = request.POST.get('type')
                prevention_id = request.POST.get('prev_id')
                PreventionSettings.objects.filter(id = prevention_id).update(auto_unblock=True)
            
            blocked_ips = BlockedIPS.objects.filter(host__customer=userprofile.customer,status=1).values_list('id','host__ip','status','blocked_ip','last_updated','process_status')
            waitingfor_block = BlockedIPS.objects.filter(host__customer=userprofile.customer,status=3).values_list('id','host__ip','status','blocked_ip','last_updated','process_status')
            waitingfor_unblock = BlockedIPS.objects.filter(host__customer=userprofile.customer,status=4).values_list('id','host__ip','status','blocked_ip','last_updated','process_status')                   
            severities = Severity.objects.filter(customer=userprofile.customer).values_list('id','severity_number','priority')
            remaining_hosts = HostInfo.objects.filter(customer=userprofile.customer).values_list('id','ip')
            existing_preventions = PreventionSettings.objects.filter(host__customer=userprofile.customer).order_by('-id').values_list('id','host__ip',\
                    'severity__severity_number', 'severity__priority', 'active', 'auto_unblock')                  
            
            final_response['waiting_block'] = list(waitingfor_block) if waitingfor_block else None
            final_response['waiting_unblock'] = list(waitingfor_unblock) if waitingfor_unblock else None
            final_response['existing_preventions'] = list(existing_preventions) if existing_preventions else None
            final_response['severities'] = list(severities) if severities else None
            final_response['remaining_hosts'] = list(remaining_hosts) if remaining_hosts else None
            final_response['blocked_ips'] = list(blocked_ips)  if blocked_ips else None          
            final_response['status'] = "success"
            final_response = json.dumps(final_response, cls = DjangoJSONEncoder)
        except Exception as ex:
            traceback.print_exc()
            final_response['status'] = "error"
        return HttpResponse(final_response, content_type="application/json")


class PopupDetails(View):
    """this class handles request for listing of events in chart click"""
    # def __init__(self, arg):
    #     super(ClassName, self).__init__()
    #     self.arg = arg

    def alert(self, item, chart_type,filters, category):

        try:
            a_object = AlertPopup(filters, request=self.request)
            if chart_type == 'alert_events':
                return a_object.alertEvents(item, category)
            elif chart_type == 'alert_signatures':
                return a_object.alertSignatures(item)
            elif chart_type == 'alert_severity':
                return a_object.alertSeverities(item)
            elif chart_type == 'alert_categories':
                return a_object.alertCategories(item)
        except Exception, e:
            raise e

    def alert_group(self,filters,event_details):        
        try:
            a_object = AlertPopup(filters)        
            return a_object.alert_group_details(event_details)
        except Exception, e:
            raise e

    def http(self, item, chart_type, filters):
        try:
            http_object = HttpPopup(filters, request=self.request)
            if chart_type == 'http_events':
                return http_object.httpEvents(item)
            if chart_type == 'http_useragent':
                return http_object.httpUserAgent(item)
            if chart_type == 'http_method':
                return http_object.httpMethod(item)
            if chart_type == 'http_status':
                return http_object.httpStatus(item)
        except Exception as ex:
            pass

    def tls(self, item, chart_type, filters):
        try:
            tls_object = TlsPopup(filters, request=self.request)
            if chart_type == 'tls_events':
                return tls_object.tlsEvents(item)
            if chart_type == 'tls_version':
                return tls_object.tlsVersion(item)
            if chart_type == 'tls_finger':
                return tls_object.tlsFinger(item)
            if chart_type == 'tls_ports':
                return tls_object.tlsPorts(item)
        except Exception as ex:
            pass

    def file(self, item, chart_type, filters, category):

        try:
            file_object = FilePopup(filters, request=self.request)
            if chart_type == 'event_rate':
                return file_object.eventRate(item, category)
            if chart_type == 'total_hits':
                return file_object.totalHits(item)
        except Exception:
            pass

    def privacy(self, item, chart_type, filters, category):
        try:
            privacy_object = PrivacyPopup(filters, request=self.request)
            if chart_type == 'event_rate':
                return privacy_object.eventRate(item, category)
        except Exception as ex:
            print "Error",ex

    def ssh(self, item, chart_type, filters):
        try:
            ssh_object = SshPopup(filters, request=self.request)
            if chart_type == 'ssh_events':
                return ssh_object.ssh_events(item)
            if chart_type == 'ssh_server':
                return ssh_object.ssh_server_protocol(item)
            if chart_type == 'ssh_client':
                return ssh_object.ssh_client_protocol(item)
        except Exception:
            pass

    def flow(self,item,chart_type,filters, category):
        try:
            flow_object = FlowPopup(filters, request=self.request)
            if chart_type == 'flow_events':
                return flow_object.flow_events(item, category)
            if chart_type == 'packet_to_server':
                return flow_object.packet_to_server(item)
            if chart_type == 'packets_to_client':
                return flow_object.packet_to_client(item)
            if chart_type == 'bytes_to_server':
                return flow_object.bytes_to_server(item)
            if chart_type == 'bytes_to_client':
                return flow_object.bytes_to_client(item)
        except Exception:
            pass

    def post(self, request, *args, **kwargs):
        try:
            t = request.POST['value']
            chart_type = request.POST.get('chart_item')
            request_from = request.POST.get('request_from')
            duration = request.POST.get('duration')
            host_id = request.POST.get('host')
            custome_date = request.POST.get('custome_date')
            date_minutes = CommonInfo().duration_details(duration, custome_date)
            optional_filter = request.POST.get('optional_filter')
            if optional_filter:
                optional_filter = json.loads(optional_filter) 

            host_details = CommonInfo().hostdetails_from_id(request,host_id)
            filters = {"date_minutes":date_minutes,"host_details":host_details,"optional_filter":optional_filter}
            category = request.POST.get('category')
            final_response = ''
            if request_from == 'alert_dashboard':
                final_response = self.alert(t, chart_type, filters, category)
            elif request_from == 'http_dashboard':
                final_response = self.http(t, chart_type, filters)
            elif request_from == 'tls_dashboard':
                final_response = self.tls(t, chart_type, filters)
            elif request_from == 'file_dashboard':
                final_response = self.file(t,chart_type, filters, category)
            elif request_from == 'privacy_dashboard':
                final_response = self.privacy(t, chart_type, filters, category)
            elif request_from == 'ssh_dashboard':
                final_response = self.ssh(t, chart_type, filters)
            elif request_from == 'flow_dashboard':
                final_response = self.flow(t, chart_type, filters, category)
            elif request_from == 'events_grouping':
                final_response = self.alert_group(filters, t)

            return HttpResponse(final_response,content_type="application/json")
        except Exception as ex:
            pass


class Profile(View):
    """
    Class for view profile details
    """
    def post(self, request, *args, **kwargs):
        action = request.POST.get('action')
        if action == "info":
            profile_basic = ProfileInfo().profile_details(request)
            return HttpResponse(profile_basic, content_type="application/json")
        elif action == "profile_pic":
            profile_pic_info = ProfileInfo().profile_upload(request)
            return HttpResponse(profile_pic_info, content_type="application/json")
        elif action == "remove_profile_pic":
            profile_pic_info = ProfileInfo().remove_profile_picture(request)
            return HttpResponse(profile_pic_info, content_type="application/json")
        elif action == "profile_data":
            profile_pic_info = ProfileInfo().profile_update(request)
            return HttpResponse(profile_pic_info, content_type="application/json")
        elif action == "password_change":
            profile_pic_info = ProfileInfo().change_password(request)
            return HttpResponse(profile_pic_info, content_type="application/json")
        elif action == "theme":
            theme_info = request.POST.get('theme')
            theme_status = ProfileInfo().update_theme(request, theme_info)
            return HttpResponse(theme_status, content_type="application/json")


class TimeZonesView(View):

    def get(self, request, *args, **kwargs):
        timezones = pytz.all_timezones
        return HttpResponse(json.dumps(timezones), content_type="application/json")


class DashboardMenuSettings(View):
    """
    Class for saving user dashboard menu priorities
    """

    def get(self, request, *args, **kwargs):
        setting_obj, created = DashboardSettings.objects.get_or_create(user=request.user)
        try:
            services = Services.objects.get(customer=UserProfile.objects.get(user=request.user).customer)
            nessus = services.nessus_scan
        except:
            nessus = False
        dashboards = {}
        dashboard_list = {}
        threat_intelligence = {}
        vulnerability = {}
        other_setting = {}
        for item in setting_obj.vulnerability:
            vulnerability[item] = True

        for item in setting_obj.threat_intelligence:
            threat_intelligence[item] = True

        for item in setting_obj.others:
            other_setting[item] = True

        for index, dashboard in enumerate(setting_obj.dashboards):
            if not dashboard == 'my':
                dashboards[dashboard] = index
                dashboard_list[dashboard] = True
        data = {"status": "success", "dashboards": dashboards, "dashboard_list": dashboard_list,
                "threat_intelligence": threat_intelligence, "vulnerability": vulnerability, 'nessus_status': nessus,
                "other_settings": other_setting, "refresh_interval": setting_obj.refresh_interval,
                "auto_refresh": setting_obj.auto_refresh}
        return HttpResponse(json.dumps(data), content_type="application/json")

    def post(self, request, *args, **kwargs):
        setting_obj, created = DashboardSettings.objects.get_or_create(user=request.user)
        setting_obj.dashboards = request.POST.getlist('dashboards[]')
        setting_obj.threat_intelligence = request.POST.getlist('threat_intelligence[]')
        setting_obj.vulnerability = request.POST.getlist('vulnerability[]')
        setting_obj.others = request.POST.getlist('other_settings[]')
        if request.POST.get('auto_refresh') == "true":
            setting_obj.auto_refresh = True
            setting_obj.refresh_interval = request.POST.get('refresh_interval')
        else:
            setting_obj.auto_refresh = False
            setting_obj.refresh_interval = 0
        setting_obj.save()
        return HttpResponse(json.dumps({"status": "success"}), content_type="application/json")


class HelpView(View):
    """
    Class for managing help content
    """

    def get(self, request, *args, **kwargs):
        helps = Help.objects.all()
        if request.GET.get('id'):
            help = serializers.serialize("json", helps.filter(id=request.GET.get('id')))
        elif request.GET.get('admin'):
            if UserProfile.objects.get(user=request.user).is_admin:
                help = serializers.serialize("json", helps)
        else:
            help = serializers.serialize("json", helps.filter(publish=True))
        return HttpResponse(help, content_type="application/json")

    def post(self, request, *args, **kwargs):
        if not UserProfile.objects.get(user=request.user).is_admin or not request.POST.get('title') or \
                not request.POST.get('content'):
            return HttpResponse(json.dumps({"status": "error"}), content_type="application/json")
        try:
            help = Help.objects.get(id=request.POST.get('id'))
        except:
            help = Help.objects.create()
        help.title = request.POST.get('title')
        help.content = request.POST.get('content')
        if request.POST.get('publish') == 'false':
            help.publish = False
        else:
            help.publish = True
        if request.POST.get('sort_order'):
            help.sort_order = request.POST.get('sort_order')
        help.save()
        return HttpResponse(json.dumps({"status": "success"}), content_type="application/json")


class HelpDeleteView(View):
    """
    Class for deleting Help object
    """

    def post(self, request, *args, **kwargs):
        try:
            help = Help.objects.get(id=request.POST.get('id'))
            help.delete()
            status = "success"
        except:
            status = "failed"
        return HttpResponse(json.dumps({"status": status}), content_type="application/json")


class SettingsConfig(View):
    """
    Class for managing configurations of IBM x-force, Virus Total, Opswat etc.
    """

    def get(self, request, *args, **kwargs):
        data = {}
        if request.GET.get('type') == 'ibm':
            if request.GET.get('id'):
                ibm = serializers.serialize("json", IpIntelligenceConfiguration.objects.
                                            filter(id=request.GET.get('id')))
            else:
                ibm = serializers.serialize("json", IpIntelligenceConfiguration.objects.all(),
                                            use_natural_foreign_keys=True)
            data = {"ibm": json.loads(ibm)}
        if request.GET.get('type') == 'virus_total':
            if request.GET.get('id'):
                virus_total = serializers.serialize("json", VirusScanConfiguration.objects.
                                                    filter(id=request.GET.get('id')))
            else:
                virus_total = serializers.serialize("json", VirusScanConfiguration.objects.all(),
                                                    use_natural_foreign_keys=True)
            data = {"virus_total": json.loads(virus_total)}
        if request.GET.get('type') == 'opswat':
            if request.GET.get('id'):
                opswat = serializers.serialize("json", OpswatVirusScanConfiguration.objects.
                                               filter(id=request.GET.get('id')))
            else:
                opswat = serializers.serialize("json", OpswatVirusScanConfiguration.objects.all(),
                                               use_natural_foreign_keys=True)
            data = {"opswat": json.loads(opswat)}
        return HttpResponse(json.dumps(data), content_type="application/json")

    def post(self, request, *args, **kwargs):
        if request.POST.get('type') == 'ibm':
            if not request.POST.get('user_token') or not request.POST.get('user_api_key') or \
                    not request.POST.get('user_password') or not request.POST.get('ip_report_api_url') or \
                    not request.POST.get('dns_status_api_url') or not request.POST.get('malware_status_api_url') or \
                    not request.POST.get('whois_report_api_url'):
                return HttpResponse(json.dumps({"status": "error"}), content_type="application/json")
            try:
                ibm = IpIntelligenceConfiguration.objects.get(id=request.POST.get('id'))
            except:
                try:
                    IpIntelligenceConfiguration.objects.get(customer__id=request.POST.get('customer'))
                    message = 'IBM x-force configuration with this Customer already exists.'
                    return HttpResponse(json.dumps({"status": "error", 'message': message}),
                                        content_type="application/json")
                except:
                    pass
                ibm = IpIntelligenceConfiguration()
            ibm.customer = Customer.objects.get(id=request.POST.get('customer'))
            ibm.user_token = request.POST.get('user_token')
            ibm.user_api_key = request.POST.get('user_api_key')
            ibm.user_password = request.POST.get('user_password')
            ibm.ip_report_api_url = request.POST.get('ip_report_api_url')
            ibm.dns_status_api_url = request.POST.get('dns_status_api_url')
            ibm.malware_status_api_url = request.POST.get('malware_status_api_url')
            ibm.whois_report_api_url = request.POST.get('whois_report_api_url')
            ibm.save()
        elif request.POST.get('type') == 'virus_total':
            if not request.POST.get('user_api_key') or not request.POST.get('host') or \
                    not request.POST.get('file_scan_url') or not request.POST.get('file_report_url') or \
                    not request.POST.get('url_scan_url') or not request.POST.get('url_report_url') or \
                    not request.POST.get('ip_report_url') or not request.POST.get('domain_report_url'):
                return HttpResponse(json.dumps({"status": "error"}), content_type="application/json")
            try:
                virus_scan = VirusScanConfiguration.objects.get(id=request.POST.get('id'))
            except:
                try:
                    VirusScanConfiguration.objects.get(customer__id=request.POST.get('customer'))
                    message = 'Virus Total configuration with this Customer already exists.'
                    return HttpResponse(json.dumps({"status": "error", 'message': message}),
                                        content_type="application/json")
                except:
                    pass
                virus_scan = VirusScanConfiguration()
            virus_scan.customer = Customer.objects.get(id=request.POST.get('customer'))
            virus_scan.user_api_key = request.POST.get('user_api_key')
            virus_scan.host = request.POST.get('host')
            virus_scan.file_scan_url = request.POST.get('file_scan_url')
            virus_scan.file_report_url = request.POST.get('file_report_url')
            virus_scan.url_scan_url = request.POST.get('url_scan_url')
            virus_scan.url_report_url = request.POST.get('url_report_url')
            virus_scan.ip_report_url = request.POST.get('ip_report_url')
            virus_scan.domain_report_url = request.POST.get('domain_report_url')
            virus_scan.save()
        elif request.POST.get('type') == 'opswat':
            if not request.POST.get('user_api_key') or not request.POST.get('hash_scan_url'):
                return HttpResponse(json.dumps({"status": "error"}), content_type="application/json")
            try:
                opswat = OpswatVirusScanConfiguration.objects.get(id=request.POST.get('id'))
            except:
                try:
                    OpswatVirusScanConfiguration.objects.get(customer__id=request.POST.get('customer'))
                    message = 'Opswat virus scan configuration with this Customer already exists.'
                    return HttpResponse(json.dumps({"status": "error", 'message': message}),
                                        content_type="application/json")
                except:
                    pass
                opswat = OpswatVirusScanConfiguration()
            opswat.customer = Customer.objects.get(id=request.POST.get('customer'))
            opswat.user_api_key = request.POST.get('user_api_key')
            opswat.hash_scan_url = request.POST.get('hash_scan_url')
            opswat.save()
        return HttpResponse(json.dumps({"status": "success"}), content_type="application/json")


class IbmConfigDeleteView(View):
    """
    Class for deleting IBM config
    """

    def post(self, request, *args, **kwargs):
        try:
            severity = IpIntelligenceConfiguration.objects.get(id=request.POST.get('id'))
            severity.delete()
            status = "success"
        except:
            status = "failed"
        return HttpResponse(json.dumps({"status": status}), content_type="application/json")


class VirusTotalConfigDeleteView(View):
    """
    Class for deleting VirusScanConfiguration
    """

    def post(self, request, *args, **kwargs):
        try:
            severity = VirusScanConfiguration.objects.get(id=request.POST.get('id'))
            severity.delete()
            status = "success"
        except:
            status = "failed"
        return HttpResponse(json.dumps({"status": status}), content_type="application/json")


class OpswatConfigDeleteView(View):
    """
    Class for deleting OpswatVirusScanConfiguration
    """

    def post(self, request, *args, **kwargs):
        try:
            severity = OpswatVirusScanConfiguration.objects.get(id=request.POST.get('id'))
            severity.delete()
            status = "success"
        except:
            status = "failed"
        return HttpResponse(json.dumps({"status": status}), content_type="application/json")


class SeverityView(View):
    """
    Class for managing Severity
    """

    def get(self, request, *args, **kwargs):
        if request.GET.get('id'):
            severity = serializers.serialize("json", Severity.objects.filter(id=request.GET.get('id')))
        else:
            severity = serializers.serialize("json", Severity.objects.all())
        return HttpResponse(severity, content_type="application/json")

    def post(self, request, *args, **kwargs):
        try:
            severity = Severity.objects.get(id=request.POST.get('id'))
        except:
            severity = Severity.objects.create()
        try:
            severity.customer = Customer.objects.get(id=request.POST.get('customer'))
        except:
            pass
        severity.priority = request.POST.get('priority')
        severity.severity_number = request.POST.get('severity_number')
        severity.save()
        return HttpResponse(json.dumps({"status": "success"}), content_type="application/json")


class SeverityDeleteView(View):
    """
    Class for deleting Severity
    """

    def post(self, request, *args, **kwargs):
        try:
            severity = Severity.objects.get(id=request.POST.get('id'))
            severity.delete()
            status = "success"
        except:
            status = "failed"
        return HttpResponse(json.dumps({"status": status}), content_type="application/json")


class CustomerView(View):
    """
    Class for listing Customers.
    """

    def get(self, request, *args, **kwargs):
        customers = serializers.serialize("json", Customer.objects.all())
        return HttpResponse(customers, content_type="application/json")


class HostInfoView(View):
    """
    Class for listing host info.
    """

    def get(self, request, *args, **kwargs):
        host_info = serializers.serialize("json", HostInfo.objects.all())
        return HttpResponse(host_info, content_type="application/json")


class HttpTrafficView(View):
    """
    Class for managing Http Traffic
    """
    def get(self, request, *args, **kwargs):
        if request.GET.get('id'):
            http_traffic = serializers.serialize("json", HttpTraffic.objects.filter(id=request.GET.get('id')))
        else:
            http_traffic = serializers.serialize("json", HttpTraffic.objects.all(), use_natural_foreign_keys=True)
        return HttpResponse(http_traffic, content_type="application/json")

    def post(self, request, *args, **kwargs):
        try:
            http_traffic = HttpTraffic.objects.get(id=request.POST.get('id'))
        except:
            http_traffic = HttpTraffic.objects.create(host=HostInfo.objects.get(id=request.POST.get('host')))
        try:
            http_traffic.customer = Customer.objects.get(id=request.POST.get('customer'))
        except:
            pass
        try:
            http_traffic.host = HostInfo.objects.get(id=request.POST.get('host'))
        except:
            pass
        http_traffic.ip_range = request.POST.get('ip_range')
        http_traffic.save()
        return HttpResponse(json.dumps({"status": "success"}), content_type="application/json")


class HttpTrafficDeleteView(View):
    """
    Class for deleting HttpTraffic object
    """

    def post(self, request, *args, **kwargs):
        try:
            http_traffic = HttpTraffic.objects.get(id=request.POST.get('id'))
            http_traffic.delete()
            status = "success"
        except:
            status = "failed"
        return HttpResponse(json.dumps({"status": status}), content_type="application/json")


class HostSettingsView(View):
    """
    Class for managing Host settings
    """
    def get(self, request, *args, **kwargs):
        if request.GET.get('id'):
            host_info = serializers.serialize("json", HostInfo.objects.filter(id=request.GET.get('id')))
        else:
            host_info = serializers.serialize("json", HostInfo.objects.all(), use_natural_foreign_keys=True)
        return HttpResponse(host_info, content_type="application/json")

    def post(self, request, *args, **kwargs):
        try:
            host_info = HostInfo.objects.get(id=request.POST.get('id'))
        except:
            host_info = HostInfo.objects.create(customer=Customer.objects.get(id=request.POST.get('customer')))
        try:
            host_info.customer = Customer.objects.get(id=request.POST.get('customer'))
        except:
            pass
        try:
            host_info.cloud = CloudProvider.objects.get(id=request.POST.get('cloud'))
        except:
            pass
        host_info.host = request.POST.get('host')
        host_info.hostname = request.POST.get('hostname')
        host_info.ip = request.POST.get('ip')
        host_info.save()
        return HttpResponse(json.dumps({"status": "success"}), content_type="application/json")


class HostSettingsDeleteView(View):
    """
    Class for deleting HostInfo object
    """

    def post(self, request, *args, **kwargs):
        try:
            host_info = HostInfo.objects.get(id=request.POST.get('id'))
            host_info.delete()
            status = "success"
        except:
            status = "failed"
        return HttpResponse(json.dumps({"status": status}), content_type="application/json")


class CloudView(View):

    def get(self, request, *args, **kwargs):
        cloud = serializers.serialize("json", CloudProvider.objects.all())
        return HttpResponse(cloud, content_type="application/json")


class RealTimeAlertAnalyticsView(View):
    """
    Class for rendering real time alert report
    """

    def post(self, request, *args, **kwargs):
        date_minutes = CommonInfo().duration_details("5m")
        host_details = CommonInfo().hostdetails_from_id(request, "")
        filters = {"date_minutes": date_minutes, "host_details": host_details}
        alert_details = json.loads(AlertInfo(filters, request).alert())
        alert_signature = json.loads(AlertInfo(filters).alertsigdetails())
        alert_severity = json.loads(AlertInfo(filters).alertsevdetails())
        return HttpResponse(json.dumps({"alert_details": alert_details,"alert_signature": alert_signature,
                                        "alert_severity": alert_severity}), content_type="application/json")


class NearByAlertsView(View):

    def post(self, request, *args, **kwargs):
        time_stamp = request.POST.get('time_stamp')
        time_interval = request.POST.get('time_interval')
        time_interval = int(time_interval)
        dt = parser.parse(time_stamp)
        time_stamp = dt.replace(tzinfo=pytz.utc)
        date1 = time_stamp + timedelta(0, time_interval)
        date2 = time_stamp + timedelta(0, -time_interval)
        base_date = time_stamp
        delta = date1 - date2
        date_duration = delta.seconds * 60
        date_minutes_before = {"date_duration": date_duration, "elastic_interval": "1s",
                              "base": date2.strftime('%Y.%m.%d %H:%M:%S'), "base1": base_date.strftime('%Y.%m.%d %H:%M:%S')}
        date_minutes_after = {"date_duration": date_duration, "elastic_interval": "1s",
                              "base": base_date.strftime('%Y.%m.%d %H:%M:%S'), "base1": date1.strftime('%Y.%m.%d %H:%M:%S')}
        host_details = CommonInfo().hostdetails_from_id(request, "")
        filters_after = {"date_minutes": date_minutes_after, "host_details": host_details}
        filters_before = {"date_minutes": date_minutes_before, "host_details": host_details}
        alert_details_after = json.loads(AlertInfo(filters_after, request).alert_between_two_time())
        alert_details_before = json.loads(AlertInfo(filters_before, request).alert_between_two_time())
        return HttpResponse(json.dumps({"alert_details_after": alert_details_after,
                                        "alert_details_before": alert_details_before}), content_type="application/json")


class WatchListView(View):
    """
    Class for watch list
    """

    def post(self, request, *args, **kwargs):
        action = request.POST.get('action')        
        userprofile = UserProfile.objects.get(user=request.user)
        host_details = CommonInfo().hostdetails_from_id(request, "")
        filters = {"host_details": host_details}        

        if action == "add_watch":
            watch_item = request.POST.get('watch_item')            
            if watch_item:
                watchlist_item = json.loads(watch_item)
                check_watch_exist = Watchlist.objects.filter(entry=watchlist_item["entry"], \
                                    entry_type=watchlist_item["type"], user=userprofile).count()
                if check_watch_exist == 0:
                    watch_status = WatchListInfo(filters).add_watchlist(watchlist_item,userprofile)                    
                else:
                    watch_status = json.dumps({"status":"exists"},cls=DjangoJSONEncoder)
                return HttpResponse(watch_status, content_type="application/json")

        elif action == "get_watch":
            watch_details = WatchListInfo(filters).get_watchlist(userprofile)
            return HttpResponse(watch_details, content_type="application/json")

        elif action == "noti_hide":
            hide_status = WatchListInfo(filters).hide_watchlist(userprofile)
            return HttpResponse(hide_status, content_type="application/json")

        elif action == "delete_entry":
            entry_id = request.POST.get('entry_id')                                            
            delete_status = WatchListInfo(filters).delete_watchlist(entry_id)
            return HttpResponse(delete_status, content_type="application/json")


class AutoReloadTimeView(View):
    def get(self, request, *args, **kwargs):
        dashboard = DashboardSettings.objects.get(user=request.user)
        return HttpResponse(json.dumps({"auto_refresh": dashboard.auto_refresh,
                                        "refresh_interval": dashboard.refresh_interval*1000}),
                            content_type="application/json")


class AzureDashboardView(View):

    def get(self, request, *args, **kwargs):
        # credentials = UserPassCredentials('test-user@marlabscloudcoeoutlook.onmicrosoft.com', 'HelloWorld#2')
        subscription_id = '1511d125-cb5a-42ba-af27-7cfbeb3c61fd'

        url = '/subscriptions/{subscriptionId}/providers/{resourceGroupName}/providers/microsoft.Security/alerts?api-version={api-version}'

        import adal

        authentication_endpoint = 'https://login.windows.net/marlabscloudcoeoutlook.onmicrosoft.com'
        resource = 'https://management.core.windows.net/'

        # get an Azure access token using the adal library
        context = adal.AuthenticationContext(authentication_endpoint)
        token_response = context.acquire_token_with_client_credentials(resource, "9872ca0b-302c-44b9-83e3-ac30864a8f3d", "V6eC5KRxvDtFRRFVbpQDBSSa1/RHrlOLY0uh3oyKyzc=")

        # token_response = context.acquire_token_with_username_password(
        #     resource,
        #     'test-user@marlabscloudcoeoutlook.onmicrosoft.com',
        #     'HelloWorld#2',
        #     '9872ca0b-302c-44b9-83e3-ac30864a8f3d')
        access_token = token_response.get('accessToken')
        # print token_response, "access_token"

        # endpoint = 'https://management.azure.com/subscriptions/1511d125-cb5a-42ba-af27-7cfbeb3c61fd/providers/microsoft.Security/alerts?api-version=2015-06-01-preview'
        endpoint = 'https://management.azure.com/subscriptions/1511d125-cb5a-42ba-af27-7cfbeb3c61fd/providers/microsoft.Security/securityStatuses?api-version=2015-06-01-preview'
        # endpoint = 'https://management.azure.com/subscriptions/?api-version==2015-03-01'
        # endpoint = 'https://management.azure.com/subscriptions/1511d125-cb5a-42ba-af27-7cfbeb3c61fd/providers/microsoft.insights/alertRules?api-version=2015-03-01'

        headers = {"Authorization": 'Bearer ' + access_token, "Content-Type": 'application/json',}
        # import pdb; pdb.set_trace()
        json_output = requests.get(endpoint, headers=headers).json()

        print json_output, "json_output"

        return HttpResponse(json.dumps({"response": json_output}), content_type="application/json")

class EventsGrouping(View):
    """
    Class for event grouping
    """

    def post(self, request, *args, **kwargs):
        if request.is_ajax():
            if request.POST:
                action = request.POST.get('action')
                group_item = request.POST.get('group_item')                
                duration = request.POST.get('duration')
                host_id = request.POST.get('host')
                custome_date = request.POST.get('custome_date')
                date_minutes = CommonInfo().duration_details(duration, custome_date)
                optional_filter = request.POST.get('optional_filter')
                if optional_filter:
                    optional_filter = json.loads(optional_filter)                    

                host_details = CommonInfo().hostdetails_from_id(request, host_id)
                filters = {"date_minutes": date_minutes, "host_details": host_details, "optional_filter":optional_filter}

                if action == "alert":
                    group_result = EventGroupInfo(filters).alert_group(request,action,group_item)
                    return HttpResponse(group_result, content_type="application/json")

class EventFilters(View):
    """
    Class for event filtering
    """

    def post(self,request, *args, **kwargs):
        if request.is_ajax():
            if request.POST:
                action = request.POST.get('action')
                user_profile = UserProfile.objects.get(user=request.user)
                if action == "add_filter":
                    filter_item = request.POST.get('filter_item')
                    filter_id = request.POST.get('filter_id')
                    filter_obj = []
                    try:
                        try:                        
                            filter_id = int(filter_id)
                        except:
                            filter_id = 0

                        if filter_id == 0:
                            obj_filter = Filters.objects.create(user=user_profile,entry=filter_item,pin_status=True)
                            filter_id = obj_filter.id
                        else:
                            Filters.objects.filter(id=filter_id).update(entry=filter_item)

                        filter_details = Filters.objects.filter(user=user_profile)

                        for filter_info in filter_details:
                            filter_obj.append({"id":filter_info.id,"entry":json.loads(filter_info.entry),"pin_status":filter_info.pin_status})

                        # filter_applied = Filters.objects.get(id=filter_id)
                        # current_filter_obj = {"id":filter_applied.id,"entry":json.loads(filter_applied.entry),"pin_status":filter_applied.pin_status}

                        output = {"status":"success","filter_info":filter_obj,"filter_id":filter_id}
                        output = json.dumps(output, cls=DjangoJSONEncoder)                       
                        return HttpResponse(output, content_type="application/json")
                    except:
                        status = {"status":"failed"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")
                elif action == "filter_initialize":                    
                    try:
                        all_filters = Filters.objects.filter(user=user_profile)
                        all_filter_obj = []
                        for filter_info in all_filters:
                            all_filter_obj.append({"id":filter_info.id,"entry":json.loads(filter_info.entry),"pin_status":filter_info.pin_status})
                        try:
                            current_filter = Filters.objects.get(user=user_profile,pin_status=True)
                            current_filter_obj = {"id":current_filter.id,"entry":json.loads(current_filter.entry),"pin_status":current_filter.pin_status}
                        except:
                            current_filter_obj = {"id":"","entry":[],"pin_status":False}
                        
                        output = {"status":"success","all_filter":all_filter_obj,"applied_filter":current_filter_obj}
                        output = json.dumps(output, cls=DjangoJSONEncoder)
                        return HttpResponse(output, content_type="application/json")
                    except:
                        status = {"status":"failed"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")

                elif action == "pin_filter":
                    filter_id = request.POST.get('filter_id')
                    pin_status = request.POST.get('pin_status')
                    try:
                        try:
                            filter_id = int(filter_id)
                        except:
                            filter_id = 0
                        if pin_status == "of" and filter_id > 0:
                            Filters.objects.filter(id=filter_id).update(pin_status=False)                        
                        status = {"status":"success"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")
                    except:
                        status = {"status":"failed"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")

                elif action == "apply_filter":
                    filter_id = request.POST.get('filter_id')
                    try:
                        Filters.objects.filter(user=user_profile,pin_status=True).update(pin_status=False)
                        Filters.objects.filter(id=filter_id).update(pin_status=True)
                        status = {"status":"success"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")
                    except:
                        status = {"status":"failed"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")

                elif action == "delete":
                    filter_id = request.POST.get('filter_id')
                    try:
                        Filters.objects.filter(id=filter_id).delete()
                        status = {"status":"success"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")
                    except:
                        status = {"status":"failed"}
                        status = json.dumps(status, cls=DjangoJSONEncoder)
                        return HttpResponse(status, content_type="application/json")














                    



