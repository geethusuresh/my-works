import json
from datetime import datetime, timedelta

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.views.decorators.csrf import csrf_exempt
from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch

from casb.settings import ELASTIC_SEARCH_URL
from dashboard.models import UserProfile, Customer, HostInfo


class CommonInfo(object):
    def duration_details(self, duration, custome_date=None):
        """
        Function for date duration calculation
        """
        duration_info = {}
        base = None
        if duration == "5m":
            date_duration = 5
            elastic_interval = "1s"
        elif duration == "15m":
            date_duration = 15
            elastic_interval = "10s"
        elif duration == "1h":
            date_duration = 60
            elastic_interval = "30s"
        elif duration == "6h":
            date_duration = 60 * 6
            elastic_interval = "5m"
        elif duration == "12h":
            date_duration = 12 * 60
            elastic_interval = "5m"
        elif duration == "24h":
            date_duration = 24 * 60
            elastic_interval = "10m"
        elif duration == "2d":
            date_duration = 2 * 24 * 60
            elastic_interval = "30m"
        elif duration == "7d":
            date_duration = 7 * 24 * 60
            elastic_interval = "1h"
        elif duration == "30d":
            date_duration = 30 * 24 * 60
            elastic_interval = "12h"
        elif duration == "date_range":
            base, date1 = custome_date.split(" - ")
            delta = (datetime.strptime(date1, "%m/%d/%Y") - datetime.strptime(base, "%m/%d/%Y")).days
            date_duration = delta * 24 * 60
            elastic_interval = "16h"
        else:
            date_duration = 24 * 60
            elastic_interval = "10m"
        if base:
            duration_info = {"date_duration": date_duration, "elastic_interval": elastic_interval, "base": datetime.strptime(date1, "%m/%d/%Y").strftime('%Y.%m.%d'),  "base1": datetime.strptime(base, "%m/%d/%Y").strftime('%Y.%m.%d')}
        else:
            duration_info = {"date_duration": date_duration, "elastic_interval": elastic_interval, "base": None, "base1": None}

        return duration_info

    def elastic_index_range(self, dateinfo):
        """
        Function for calculating elastic index range
        """
        index_range = dateinfo/1440
        index_range = index_range + 1
        index_range = int(index_range)

        return index_range

    def customer_hosts(self, request, selected_host=""):
        """
        Function for calculating Host details
        """

        profile = UserProfile.objects.get(user=request.user)
        hostdetails = HostInfo.objects.filter(customer=profile.customer)
        host_item = []
        for item in hostdetails:
            host_item.append({"hostid": item.id, "hostname": item.hostname, "host_uuid":item.host})

        if selected_host != "":
            selected_host = int(selected_host)
            hostip_obj = HostInfo.objects.get(id=selected_host)
            hostip = hostip_obj.hostname
        else:
            hostip = "All"

        hostdetails = {"host_item": host_item, "hostip": hostip}
        hostdetails = json.dumps(hostdetails, cls=DjangoJSONEncoder)
        return hostdetails

    def hostdetails_from_id(self, request, hostid):
        """
        Function for fetching host details from id
        """
        profile = UserProfile.objects.get(user=request.user)
        hostips = []
        try:
            if hostid != "":
                hostid = int(hostid)
                hostdetails = HostInfo.objects.get(id=hostid)
                hostip = hostdetails.host
                hostips.append({"ip": hostip})
            else:
                hostdetails = HostInfo.objects.filter(customer=profile.customer)
                for hostitem in hostdetails:
                    hostip = hostitem.host
                    hostips.append({"ip": hostip})
        except:
            hostdetails = HostInfo.objects.filter(customer=profile.customer)
            for hostitem in hostdetails:
                hostip = hostitem.host
                hostips.append({"ip": hostip})
        return hostips

    def make_filter(self,filters):
        """
        Function for making additional filters
        """
        filter_query = []
        filter_query_out = []
        filter_details = filters['optional_filter']                        
        for filter_item in filter_details:                
            if filter_item["type"] == "src_ip" and filter_item["op"] == "in":
                filter_query.append({"query" : {
                    "wildcard" : { "src_ip.raw" : filter_item["ip"] }
                }})
            elif filter_item["type"] == "dest_ip" and filter_item["op"] == "in":                
                filter_query.append({"query" : {
                    "wildcard" : { "dest_ip.raw" : filter_item["ip"] }
                }})

            elif filter_item["type"] == "sig" and filter_item["op"] == "in":                
                filter_query.append({"query" : {
                    "wildcard" : { "alert.signature.raw" : filter_item["ip"] }
                }})

            elif filter_item["type"] == "src_ip" and filter_item["op"] == "out":                
                filter_query_out.append({"query" : {
                    "wildcard" : { "src_ip.raw" : filter_item["ip"] }
                }})

            elif filter_item["type"] == "dest_ip" and filter_item["op"] == "out":                
                filter_query_out.append({"query" : {
                    "wildcard" : { "dest_ip.raw" : filter_item["ip"] }
                }})

            elif filter_item["type"] == "sig" and filter_item["op"] == "out":                
                filter_query_out.append({"query" : {
                    "wildcard" : { "alert.signature.raw" : filter_item["ip"] }
                }})

        query_info = {"bool" : {
                        "must": filter_query,
                        "should":{
                            "bool":{
                                    "must_not": filter_query_out
                                }
                            }
                        }
                    }
        return query_info

    def make_watchlist_condition(self,watchlist_item):        
        """
        Function for making watchlist condition
        """
        watchlist_query = ""        
        if watchlist_item["type"] == "src_ip":
            watchlist_query = {"term": {"src_ip.raw": watchlist_item["entry"]}}            
        elif watchlist_item["type"] == "dest_ip":
            watchlist_query = {"term": {"dest_ip.raw": watchlist_item["entry"]}}
        elif watchlist_item["type"] == "sig":
            watchlist_query = {"term": {"alert.signature.raw": watchlist_item["entry"]}}
        return watchlist_query

    def events_group_condition(self,action,group_item):
        """
        Function for event grouping condition
        """

        group_query = ""
        if group_item == "sig" and action == "alert":
            group_query =  {
                                "terms": {
                                    "field": "alert.signature.raw",
                                    "size" : 0
                                },
                                "aggs":{
                                    "alert_severity" : {
                                        "terms": {
                                            "field": "alert.severity"
                                        } 
                                    }
                                } 
                            }                            
                         
        elif group_item == "src_ip" and action == "alert":
            group_query =  {
                                "terms": {
                                    "field": "src_ip.raw",
                                    "size" : 0
                                },
                                "aggs":{
                                    "alert_severity" : {
                                        "terms": {
                                            "field": "alert.severity"
                                        } 
                                    }
                                } 
                            }

        elif group_item == "dest_ip" and action == "alert":
            group_query =  {
                                "terms": {
                                    "field": "dest_ip.raw",
                                    "size" : 0
                                },
                                "aggs":{
                                    "alert_severity" : {
                                        "terms": {
                                            "field": "alert.severity"
                                        } 
                                    }
                                } 
                            }

        return group_query


def get_timezone(request):
    if request:
        user = UserProfile.objects.get(user=request.user)
        if user.timezone:
            return user.timezone
    return "UTC"






