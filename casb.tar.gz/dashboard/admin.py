from django.contrib import admin

from solo.admin import SingletonModelAdmin

from dashboard.models import *


class CustomerAdmin(admin.ModelAdmin):
    search_fields = ('customername', 'customerid')
    list_display = ['customername', 'customerid']

admin.site.register(Customer, CustomerAdmin)


class UserProfileAdmin(admin.ModelAdmin):
    search_fields = ('user__username', 'user__first_name')

admin.site.register(UserProfile, UserProfileAdmin)


class CategoriesAdmin(admin.ModelAdmin):
    search_fields = ['category_name']
    list_display = ['category_name', 'active']

admin.site.register(Categories, CategoriesAdmin)


class SiteCategoriesAdmin(admin.ModelAdmin):
    search_fields = ('category__category_name', 'sitename')

admin.site.register(SiteCategories, SiteCategoriesAdmin)


class DashSettingsAdmin(admin.ModelAdmin):
    search_fields = ['user__user__email', 'user__user__username']
    list_display = ['user','dashboard']

class HostAdmin(admin.ModelAdmin):
    search_fields = ['host']
    list_display = ['customer', 'host', 'ip', 'hostname']

admin.site.register(Dashsettings, DashSettingsAdmin)
admin.site.register(HostInfo, HostAdmin)
admin.site.register(CloudProvider)
admin.site.register(DefaultDashsettings)
admin.site.register(HttpTraffic)

class PreventionAdmin(admin.ModelAdmin):
    search_fields = ['host__ip']

admin.site.register(PreventionSettings, PreventionAdmin)
admin.site.register(Severity)


class BlockedIPAdmin(admin.ModelAdmin):
    search_fields = ['host__ip']


class HelpAdmin(admin.ModelAdmin):
    list_display = ['title', 'publish', 'sort_order']
    search_fields = ['title', 'content']


admin.site.register(BlockedIPS, BlockedIPAdmin)
admin.site.register(DashboardSettings)
admin.site.register(Help, HelpAdmin)
admin.site.register(Services)
admin.site.register(Watchlist)
admin.site.register(Filters)



