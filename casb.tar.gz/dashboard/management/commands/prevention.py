from django.core.management.base import BaseCommand

from dashboard.prevention import *


class Command(BaseCommand):
    help = 'Block attacking ips'

    def handle(self, *args, **options):
        try:
            blockip()
            print "run"
        except Exception as ex:
            print str(ex)
