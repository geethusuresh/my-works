from __future__ import print_function
import base64
import datetime
import os
import sys, re
import subprocess
import time
import random
from openvas_lib import VulnscanManager, VulnscanException, report_parser
from threading import Semaphore
from functools import partial
from xml.etree import ElementTree

import json
import xmltodict
from datetime import datetime
from elasticsearch import Elasticsearch
from django.core.management.base import BaseCommand


HOST = "192.168.61.205"
USER = "admin"
PASSWORD = "admin"
PORT = 9390
TIMEOUT = 10
es = Elasticsearch()

class Command(BaseCommand):
    help = 'Block attacking ips'

    def handle(self, *args, **options):
        try:
            openvas_ip = HOST
            admin_name = USER
            admin_password = PASSWORD
            ip =  "192.168.61.202"
            manager = VulnscanManager(openvas_ip, admin_name, admin_password)
            self.run(manager, ip)
            self.xmltojson(ip+".xml")
        except Exception as e:
            print(e)

    def xmltojson(self, xml_file, xml_attribs=True):
        with open(xml_file, "rb") as f:    # notice the "rb" mode
            d = xmltodict.parse(f, xml_attribs=xml_attribs)
            json_data = json.dumps(d, indent=4)
            json_data = json.loads(json_data)
            try:
                result = json_data['get_reports_response']['report']['report']['results']['result']
            except Exception as e:
                print(e)
            import ipdb; ipdb.set_trace()
            ack = es.indices.create(index='openvaslogstash-'+ str(datetime.now().date()), ignore=400)
            print(ack)
            # datetimes will be serialized
            for i, item in enumerate(result):
                try:
                    summary = (item["nvt"]["tags"].split("|summary=")[1])
                    item.update({'summary': (summary.split("|")[0] if "|" in summary else summary ) })
                except Exception as e:
                    item.update({'summary': None})
                try:
                    solution = (item["nvt"]["tags"].split("|solution=")[1])
                    item.update({'solution':(solution.split("|")[0] if "|" in solution else solution )})
                except Exception as e:
                    item.update({'solution': None})
                try:
                    insight = (item["nvt"]["tags"].split("|insight=")[1])
                    item.update({'insight':(insight.split("|")[0] if "|" in insight else insight )})
                except Exception as e:
                    item.update({'insight': None})
                rs = es.index(index="openvaslogstash-"+ str(datetime.now().date()), doc_type="json", id=item['@id'], body=item)
                print(rs)
            return True


    def my_print_status(self, i):
        print(str(i)),
        sys.stdout.flush()


    def write_report(self, manager, report_id, ip):
        # result_dir = os.path.dirname(os.path.abspath(__file__)) + "/results"
        try:
            report = manager.get_report_xml(report_id)
        except Exception as e:
            print(e)
            return
        else:
            fout = open(ip + ".xml", "wb")
            fout.write(ElementTree.tostring(report, encoding='utf-8', method='xml'))
            fout.close()


    def run(self, manager, ip):
        Sem = Semaphore(0)
        scan_id, target_id = manager.launch_scan(
            target=ip,
            profile="Full and fast",
            callback_end=partial(lambda x: x.release(), Sem),
            callback_progress=self.my_print_status
        )
        Sem.acquire()
        print(scan_id)
        print(target_id)
        report_id = manager.get_report_id(scan_id)
        self.write_report(manager, report_id, ip)
        # manager.delete_scan(scan_id)
        # manager.delete_target(target_id)