import json
import pytz
import datetime
from datetime import date, timedelta

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core.serializers.json import DjangoJSONEncoder
from django.views.decorators.csrf import csrf_exempt

from elasticsearch import Elasticsearch
from dateutil import parser

from dashboard.common import get_timezone
from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from common import CommonInfo


es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class AlertInfo:
    """
    Function for Alerts Graph
    """
    def __init__(self, filters, request=None):
        date_duration = filters['date_minutes']
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.base = date_duration['base']
        self.date_start = date_duration['base1']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)

        self.request = request
        self.timezone = get_timezone(self.request)

        hostid = filters['host_details']
        self.hostquery = []
        for hostitem in hostid:
            self.hostquery.append({"term": {"casbuid.raw": hostitem["ip"]}})

        try:
            self.additional_filters = []            
            self.additional_filters = CommonInfo().make_filter(filters)
        except:            
            pass
        try:
            self.date1 = parser.parse(date_duration.get('base'))
            self.date2 = parser.parse(date_duration.get('base1'))
        except:
            pass


    def alerteventdetails(self):
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        if index_list:

            query = {
                "facets": {
                    "0": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "alert.severity:1"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                        ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],                                                                                               
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                },

                            }
                        }
                    },
                    "1": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "alert.severity:2"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                        ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],                                                
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "2": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "alert.severity:3"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                        ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],                                                
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                }
            }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        timestamp_list = []
        category = []
        dataset_info = []

        series_dict = {
            '0': 'High',
            '1': 'Medium',
            '2': 'Low'
        }

        category = []
        temp_cat = []
        dataset = []
        for i in res['facets']:
            for x in res['facets'][i]['entries']:
                if x['time'] not in temp_cat:
                    temp_cat.append(x['time'])

        category = []
        temp_cat = sorted(temp_cat)
        for time_info in temp_cat:
            ts = time_info / 1000
            time = datetime.datetime.fromtimestamp(ts)
            local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(self.timezone))
            time = local_time.strftime("%Y %b %d %H:%M")
            category.append({"label": time})

        for i in res['facets']:
            d = {}
            data = []
            total_count = 0
            t = 0
            for x in res['facets'][i]['entries']:
                while(x['time'] != temp_cat[t]):
                    data.append({"value": 0})
                    t += 1
                ts = x['time'] / 1000
                t += 1
                data.append({"value": x['count']})
                total_count += x['count']
            d['seriesname'] = series_dict[i]
            d["data"] = data
            if series_dict[i] == "High":
                d["color"] = "#CC1800"
            elif series_dict[i] == "Medium":
                d["color"] = "#FF6400"
            elif series_dict[i] == "Low":
                d["color"] = "#FFBD00"
            dataset.append(d)
        final_response = {'category': category, 'dataset': dataset}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def alertsigdetails(self):
        """
        Function for Alert Signatures
        """

        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "alert.signature.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"alert\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                        ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters                                           
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            signature_details = res['facets']['terms']['terms']
            sig_list = []
            for siginfo in signature_details:
                sig_count = siginfo['count']
                sig_name = siginfo['term']
                sig_list.append({"label": sig_name, "value": sig_count})
            sig_list = json.dumps(sig_list, cls=DjangoJSONEncoder)
            return sig_list

    def alertsevdetails(self):
        """
        Function for Alert Severity
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "alert.severity",
                            "size": 10,
                            "order": "term",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"alert\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                        ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters                                             
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            severity_details = res['facets']['terms']['terms']
            severity_list = []
            category = []
            severity_obj = {}
            for sevinfo in severity_details:
                sev_count = sevinfo['count']
                sev_name = sevinfo['term']
                tooltip = "Severity "+ str(sev_name) + ": " + str(sev_count)
                if sev_name == 1:
                    color = "#CC1800"
                    sev_label = "High"
                elif sev_name == 2:
                    color = "#FF6400"
                    sev_label = "Medium"
                elif sev_name == 3:
                    color = "#FFBD00"
                    sev_label = "Low"
                #category.append({"label":str(sev_label),"x":sev_name})
                #severity_list.append({"x":sev_name,"y":sev_count,"z":sev_count,"name":sev_label,"color":color})
                severity_list.append({"label": sev_label, "value": sev_count, "color": color})
            #severity_obj = {"category":category,"severity":severity_list}
            severity_list = json.dumps(severity_list, cls=DjangoJSONEncoder)
            return severity_list

    def categorydetails(self):
        """
        Function for Alert Category
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "alert.category.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"alert\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters                                           
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        # res = es.search(index=index_list,body=query,ignore_unavailable=index_list)
        # category_details = res['facets']['terms']['terms']
        # category_list = []
        # for categoryfo in category_details:
        # 	category_count = categoryfo['count']
        # 	category_name = categoryfo['term']
        # 	category_list.append({"label":category_name,"value":category_count})
        # category_list = json.dumps(category_list, cls=DjangoJSONEncoder)
        # return category_list

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        category_details = res['facets']['terms']['terms']
        category_list = []
        category = []
        severity_obj = {}
        for categoryinfo in category_details:
            if categoryinfo['term'] != "":
                category_count = categoryinfo['count']
                category_name = categoryinfo['term']
                category_list.append({"label": category_name, "value": category_count})
        category_list = json.dumps(category_list, cls=DjangoJSONEncoder)
        return category_list

    def alert(self):
        """
        Function for Alert Details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        query = {
            "query": {
                "filtered": {
                    "query": {
                        "bool": {
                            "should": [
                                {
                                    "query_string": {
                                        "query": "event_type:\"alert\""
                                    }
                                }
                            ]
                        }
                    },
                    "filter": {
                        "bool": {
                            "must": [
                                    ranges,
                                { "bool" : {
                                        "should": self.hostquery
                                    }
                                }
                            ],
                            "should": self.additional_filters                            
                        }
                    }
                }
            },            
            "size": 500,
            "sort": [
                {
                    "@timestamp": {
                        "order": "desc"
                    }
                }
            ]
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        alert_details = res['hits']['hits']
        for item in alert_details:
            try:
                utc_time = datetime.datetime.strptime(item['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                item['_source']['timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
            except:
                pass
        alert_details = json.dumps(alert_details, cls=DjangoJSONEncoder)
        return alert_details

    def alert_between_two_time(self):
        """
        Function for NearByAlert Details
        """
        base = datetime.datetime.strptime(self.base, '%Y.%m.%d %H:%M:%S')
        time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d %H:%M:%S')
        time = time.isoformat()
        time1 = base.isoformat()
        ranges = {
                "range": {
                    "@timestamp": {
                        "from": time1,
                        "to": time
                    }
                }
            }
        delta = self.date2 - self.date1
        date2 = self.date2
        date_list = [(date2 + timedelta(days=i)).strftime("%Y.%m.%d") for i in range(delta.days + 1)]
        index_list = [('logstash-'+date)for date in date_list]

        query = {
            "query": {
                "filtered": {
                    "query": {
                        "bool": {
                            "should": [
                                {
                                    "query_string": {
                                        "query": "event_type:\"alert\""
                                    }
                                }
                            ]
                        }
                    },
                    "filter": {
                        "bool": {
                            "must": [
                                    ranges,
                                { "bool" : {
                                        "should": self.hostquery
                                    }
                                }
                            ],
                            "should": self.additional_filters
                        }
                    }
                }
            },
            "highlight": {
                "fields": {},
                "fragment_size": 2147483647,
                "pre_tags": [
                    "@start-highlight@"
                ],
                "post_tags": [
                    "@end-highlight@"
                ]
            },
            "size": 500,
            "sort": [
                {
                    "@timestamp": {
                        "order": "desc"
                    }
                }
            ]
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        alert_details = res['hits']['hits']
        for item in alert_details:
            try:
                utc_time = datetime.datetime.strptime(item['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                item['_source']['timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
            except:
                pass
        alert_details = json.dumps(alert_details, cls=DjangoJSONEncoder)
        return alert_details

    def alert_trend(self):
        """
        Function for Alert Trend Details
        """  
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            index_range = self.index_range
        else:
            base = datetime.datetime.today()
            index_range = self.index_range + self.index_range

      # time calculation for 1 day trend
        time = base - datetime.timedelta(minutes=self.duration_info)
        time_1day_new_from = time.isoformat()

        time_1day = time - datetime.timedelta(days=1)
        time_1day_old_from = time_1day.isoformat()

        time_1day_old = time_1day + datetime.timedelta(minutes=self.duration_info)
        time_1day_old_to = time_1day_old.isoformat()

        # time calculation for 4 hour trend
        time = base - datetime.timedelta(minutes=self.duration_info)
        time_4hour_new_from = time.isoformat()

        time_4hours = time - datetime.timedelta(hours=4)
        time_4hours_old_from = time_4hours.isoformat()

        time_4hour_old = time_4hours + datetime.timedelta(minutes=self.duration_info)
        time_4hour_old_to = time_4hour_old.isoformat()

        # time calculation for 1 hour trend
        time = base - datetime.timedelta(minutes=self.duration_info)
        time_1hour_new_from = time.isoformat()

        time_1hours = time - datetime.timedelta(hours=1)
        time_1hours_old_from = time_1hours.isoformat()

        time_1hour_old = time_1hours + datetime.timedelta(minutes=self.duration_info)
        time_1hour_old_to = time_1hour_old.isoformat()
        
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        query = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"alert\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1day_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"alert\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1day_old_from,
                                                    "to": time_1day_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters                                   
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        # print query

        query1 = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"alert\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_4hour_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters                                   
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"alert\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_4hours_old_from,
                                                    "to": time_4hour_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters                                   
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        query2 = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"alert\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1hour_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters                                   
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"alert\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1hours_old_from,
                                                    "to": time_1hour_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters                                   
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        alert_trend_details = {}
        #calculation for 1 day trend
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        count_1day_new = res['facets']['0']['count']
        count_1day_old = res['facets']['old_0']['count']

        print "count old end details"
        print count_1day_old
        print count_1day_new
        print "count new end details"

        if count_1day_old > 0:
            perc_1day = (float(count_1day_new)/float(count_1day_old)) * float(100)
            percent_diff_1day = perc_1day - 100
            percent_diff_1day = round(percent_diff_1day, 2)
        else:
            #percent_diff_1day = float(count_1day_new) * float(100)
            percent_diff_1day = "?"
        #print percent_diff_1day

        #calculation for 4 hour trend
        res = es.search(index=index_list, body=query1, ignore_unavailable=index_list)
        count_4hour_new = res['facets']['0']['count']
        count_4hour_old = res['facets']['old_0']['count']

        if count_4hour_old > 0:
            perc_4hour = (float(count_4hour_new)/float(count_4hour_old)) * float(100)
            percent_diff_4hour = perc_4hour - 100
            percent_diff_4hour = round(percent_diff_4hour, 2)
        else:
            #percent_diff_4hour = float(count_4hour_new) * float(100)
            percent_diff_4hour = "?"
        #print percent_diff_4hour

        #calculation for 1 hour trend
        res = es.search(index=index_list, body=query2, ignore_unavailable=index_list)
        count_1hour_new = res['facets']['0']['count']
        count_1hour_old = res['facets']['old_0']['count']

        if count_1hour_old > 0:
            perc_1hour = (float(count_1hour_new)/float(count_1hour_old)) * float(100)
            percent_diff_1hour = perc_1hour - 100
            percent_diff_1hour = round(percent_diff_1hour, 2)
        else:
            #percent_diff_1hour = float(count_1hour_new) * float(100)
            percent_diff_1hour = "?"

        print percent_diff_1hour, "check 1 hour"
        alert_trend_details = {"count_1day_new": count_1day_new, "count_1day_old": count_1day_old,
                               "perc_1day": percent_diff_1day, "count_4hour_new": count_4hour_new,
                               "count_4hour_old": count_4hour_old, "perc_4hour": percent_diff_4hour,
                               "count_1hour_new": count_1hour_new, "count_1hour_old": count_1hour_old,
                               "perc_1hour": percent_diff_1hour}

        alert_trend_details = json.dumps(alert_trend_details, cls=DjangoJSONEncoder)
        return alert_trend_details

    def alert_world(self):
        """
        Function for Alert world map Details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.continent_code",
                        "size": 100,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"alert\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters                                            
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})

        #map_info.append({"id":"23","value":"2340"})
        #map_info.append({"id":"104","value":"123"})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info

    def alert_usa(self):
        """
        Function for Alert usa map Details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.region_name.raw",
                        "size": 100,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"alert\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters                                          
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})

        #map_info.append({"id":"23","value":"2340"})
        #map_info.append({"id":"104","value":"123"})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info
