import os
import json
import pytz
import datetime

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core.files import File
from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch
from PIL import Image

from dashboard.models import UserProfile, Customer
from two_factor_auth.models import TwofactorSetup
from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from dashboard.common import get_timezone


class ProfileInfo:
    """
    Function for getting profile details
    """
    def profile_details(self, request):
        userprofile = UserProfile.objects.get(user=request.user)
        obj_twofactor = TwofactorSetup.objects.filter(user=userprofile, active=True).count()
        if obj_twofactor > 0:
            twofactor_status = "enabled"
        else:
            twofactor_status = "not-enabled"

        last_login = userprofile.lastlogin.astimezone(pytz.timezone(get_timezone(request)))
        last_login = last_login.strftime("%Y-%m-%d %H:%M:%S")

        enduer_details = {"customername": userprofile.customer.customername, "department": userprofile.department,
                          "title": userprofile.title, "location": userprofile.location, "city": userprofile.city,
                          "country": userprofile.country, "email": request.user.email,
                          "firstname": request.user.first_name, "lastname": request.user.last_name,
                          "username": request.user.username, "lastlogin": last_login,
                          "image": userprofile.image.name, "twofactor_status": twofactor_status,
                          "timezone": userprofile.timezone}
        enduser_info = json.dumps(enduer_details, cls=DjangoJSONEncoder)
        return enduser_info

    def profile_upload(self, request):
        """
        Upload Image
        """
        userprofile = UserProfile.objects.get(user=request.user)
        profile_image = request.FILES.get('file', None)
        if profile_image:
            THUMB_SIZE = 200, 200
            img = Image.open(profile_image)
            width, height = img.size

            if width > height:
                delta = width - height
                left = int(delta/2)
                upper = 0
                right = height + left
                lower = height
            else:
                delta = height - width
                left = 0
                upper = int(delta/2)
                right = width
                lower = width + upper

            img = img.crop((left, upper, right, lower))
            img.thumbnail(THUMB_SIZE, Image.ANTIALIAS)
            img.save("profile_thumb.jpg", img.format)
            profile_image = File((open('profile_thumb.jpg', 'r')))
            userprofile.image = profile_image
            userprofile.save()
            try:
                os.remove("profile_thumb.jpg")
            except:
                pass
            status = {"status": "success", "image": userprofile.image.name}
        else:
            status = {"status": "failed"}
        upload_output = json.dumps(status, cls=DjangoJSONEncoder)
        return upload_output

    def remove_profile_picture(self, request):
        """
        Remove profile picture
        """
        userprofile = UserProfile.objects.get(user=request.user)
        userprofile.image = None
        userprofile.save()
        status = {"status": "success"}
        return json.dumps(status, cls=DjangoJSONEncoder)

    def profile_update(self, request):
        """
        Update profile data
        """
        userprofile = UserProfile.objects.get(user=request.user)
        userprofile.location = request.POST.get('location', None)
        userprofile.city = request.POST.get('city', None)
        userprofile.title = request.POST.get('title', None)
        userprofile.country = request.POST.get('country', None)
        userprofile.timezone = request.POST.get('timezone')
        userprofile.save()
        if userprofile:
            status = {"status": "success"}
        else:
            status = {"status": "failed"}
        return json.dumps(status, cls=DjangoJSONEncoder)

    def change_password(self, request):
        """
        Change current user password.
        """
        userprofile = UserProfile.objects.get(user=request.user)
        user = userprofile.user
        old_password = request.POST.get('old_password', None)
        password1 = request.POST.get('password1', None)
        password2 = request.POST.get('password2', None)
        if (user.check_password(old_password) and password1 == password2):
            user.set_password(password1)
            user.save()
            status = {"status": "success"}
        else:
            status = {"status": "failed"}
        return json.dumps(status, cls=DjangoJSONEncoder)

    def update_theme(self, request, theme_info):
        """
        Update your current theme.
        """
        userprofile = UserProfile.objects.get(user=request.user)
        try:
            userprofile.theme = theme_info
            userprofile.save()
            status = {"status": "success"}
        except:
            status = {"status": "failed"}
        return json.dumps(status, cls=DjangoJSONEncoder)
