import json
import pytz
import datetime

from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch

from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from common import CommonInfo, get_timezone

es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class PrivacyInfo:

    def __init__(self, filters, request=None):
        date_duration = filters['date_minutes']
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)
        self.base = date_duration['base']
        self.date_start = date_duration['base1']

        self.request = request
        self.timezone = get_timezone(self.request)

        hostid = filters['host_details']
        self.hostquery = []
        for hostitem in hostid:
            self.hostquery.append({"term": {"casbuid.raw": hostitem["ip"]}})

        try:
            self.additional_filters = []            
            self.additional_filters = CommonInfo().make_filter(filters)
        except:            
            pass

    def privacy_event_details(self):
        """
        Function for Privacy events
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "0": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "event_type:\"http\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                },

                            }
                        }
                    },
                    "1": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "http.hostname:*.facebook.net"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "2": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "http.hostname:www.google-analytics.com"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "3": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "http.hostname:xiti.com"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "4": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "http.hostname:platform.twitter.com"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "5": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "event_type:\"tls\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "6": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "tls.subject.raw:*.google\\-analytics.com*"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "7": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "tls.subject.raw:*facebook*"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "8": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "tls.subject.raw:*twitter.com*"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "9": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "tls.subject.raw:*doubleclick*"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "10": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "http.hostname:*doubleclick.net*"
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            },
                        }
                    }
                },
                "size": 0,
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            #print res['facets']

            timestamp_list = []
            category = []
            dataset_info = []

            series_dict = {
                '10': 'Doubleclick TLS',
                '9': 'Doubleclick',
                '8': 'Twitter',
                '7': 'Facebook',
                '6': 'Google Analytics',
                '5': 'TLS',
                '4': 'Twitter TLS',
                '3': 'XiTi',
                '2': 'Google Analytics TLS',
                '1': 'Facebook TLS',
                '0': 'Http'
            }

            category = []
            temp_cat = []
            dataset = []
            for i in res['facets']:
                for x in res['facets'][i]['entries']:
                    if x['time'] not in temp_cat:
                        temp_cat.append(x['time'])

            category = []
            temp_cat = sorted(temp_cat)
            for time_info in temp_cat:
                ts = time_info / 1000
                time = datetime.datetime.fromtimestamp(ts)
                local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(self.timezone))
                time = local_time.strftime("%Y %b %d %H:%M")
                category.append({"label": time})

            for i in res['facets']:
                d = {}
                data = []
                total_count = 0
                t = 0
                for x in res['facets'][i]['entries']:
                    while(x['time'] != temp_cat[t]):
                        data.append({"value": 0})
                        t += 1
                    ts = x['time'] / 1000
                    t += 1
                    data.append({"value": x['count']})
                    total_count += x['count']
                d['seriesname'] = series_dict[i]
                d["data"] = data
                dataset.append(d)
            final_response = {'category': category, 'dataset': dataset}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

    def facebook_event_details(self):
        """
        Function for facebook events
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.http_refer.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": [
                                "facebook.net"
                            ]
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:*.facebook.net"
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            event_details = res['facets']['terms']['terms']
            event_list = []
            for eventinfo in event_details:
                event_count = eventinfo['count']
                event_name = eventinfo['term']
                event_list.append({"label": event_name, "value": event_count})
            event_list = json.dumps(event_list, cls=DjangoJSONEncoder)
            return event_list

    def twitter_event_details(self):
        """
        Function for twitter events
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.http_refer.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:platform.twitter.com"
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            event_details = res['facets']['terms']['terms']
            event_list = []
            for eventinfo in event_details:
                event_count = eventinfo['count']
                event_name = eventinfo['term']
                event_list.append({"label": event_name, "value": event_count})
            event_list = json.dumps(event_list, cls=DjangoJSONEncoder)
            return event_list

    def analytics_event_details(self):
        """
        Function for analytics events
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.http_refer.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:www.google-analytics.com"
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            event_details = res['facets']['terms']['terms']
            event_list = []
            for eventinfo in event_details:
                event_count = eventinfo['count']
                event_name = eventinfo['term']
                event_list.append({"label": event_name, "value": event_count})
            event_list = json.dumps(event_list, cls=DjangoJSONEncoder)
            return event_list

    def hostname_event_details(self):
        """
        Function for hostname events
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.hostname.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"http\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:*.facebook.net"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:www.google-analytics.com"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:xiti.com"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:platform.twitter.com"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"tls\""
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "tls.subject.raw:*.google\\-analytics.com*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "tls.subject.raw:*facebook*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "tls.subject.raw:*twitter.com*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "tls.subject.raw:*doubleclick*"
                                                        }
                                                    },
                                                    {
                                                        "query_string": {
                                                            "query": "http.hostname:*doubleclick.net*"
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            event_details = res['facets']['terms']['terms']
            event_list = []
            for eventinfo in event_details:
                event_count = eventinfo['count']
                event_name = eventinfo['term']
                event_list.append({"label": event_name, "value": event_count})
            event_list = json.dumps(event_list, cls=DjangoJSONEncoder)
            return event_list

    def document_event_details(self):
        """
        Function for document events
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "query": {
                    "filtered": {
                        "query": {
                            "bool": {
                                "should": [
                                    {
                                        "query_string": {
                                            "query": "event_type:\"http\""
                                        }
                                    },
                                    {
                                        "query_string": {
                                            "query": "event_type:\"tls\""
                                        }
                                    }
                                ]
                            }
                        },
                        "filter": {
                            "bool": {
                                "must": [
                                    ranges,
                                    { "bool" : {
                                        "should": self.hostquery
                                        }
                                    }
                                ],
                                "should": self.additional_filters
                            }
                        }
                    }
                },
                "highlight": {
                    "fields": {},
                    "fragment_size": 2147483647,
                    "pre_tags": [
                        "@start-highlight@"
                    ],
                    "post_tags": [
                        "@end-highlight@"
                    ]
                },
                "size": 500,
                "sort": [
                    {
                        "@timestamp": {
                            "order": "desc"
                        }
                    }
                ]
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            transaction_details = res['hits']['hits']
            for item in transaction_details:
                try:
                    utc_time = datetime.datetime.strptime(item['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                    local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                    item['_source']['timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    pass
            transaction_details = json.dumps(transaction_details, cls=DjangoJSONEncoder)
            return transaction_details

    def getHttpsWorld(self):
        """
        Function returns data for world map.
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]
        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.continent_code",
                        "size": 167,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"tls\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info

    def getHttpWorld(self):
        """
        Function returns data for world map.
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]
        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.continent_code",
                        "size": 167,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        #print map_details
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info

    def getHttpUSA(self):
        """
        Function returns data for world map.
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]
        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.region_name.raw",
                        "size": 167,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list,  body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info
