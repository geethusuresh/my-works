import json
import pytz
import datetime

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.views.decorators.csrf import csrf_exempt
from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch

from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from dashboard.common import CommonInfo
from dashboard.models import UserProfile, Customer, HttpTraffic
from dashboard.common import get_timezone

es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class HttpInfo:
    def __init__(self, filters, request=None):
        date_duration = filters['date_minutes']
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)
        self.base = date_duration['base']
        self.date_start = date_duration['base1']

        self.request = request
        self.timezone = get_timezone(self.request)

        hostid = filters['host_details']
        self.hostquery = []
        bound_host = []
        for hostitem in hostid:
            self.hostquery.append({"term": {"casbuid.raw": hostitem["ip"]}})
            # Getting bounded ip details for incoming and outgoing traffic
            try:
                bounded_ipobj = HttpTraffic.objects.get(host__host=hostitem["ip"])
                bounded_info = bounded_ipobj.ip_range
                bounded_info = bounded_info.split(",")
                for bounded_item in bounded_info:
                    bound_host.append(bounded_item)
            except:
                pass
        self.inbound_ip = []
        self.outbound_ip = []
        for outbound_item in bound_host:
            self.outbound_ip.append({
                "query": {
                    "wildcard": {
                        "src_ip": outbound_item
                    }
                }
            })
        for inbound_item in bound_host:
            self.inbound_ip.append({
                "query": {
                    "wildcard": {
                        "dest_ip": inbound_item
                    }
                }
            })

        try:
            self.additional_filters = []            
            self.additional_filters = CommonInfo().make_filter(filters)
        except:            
            pass

    def httpeventdetails(self):
        """
        Function for getting Http event details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "0": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "event_type:\"http\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    {"bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    },
                                                    {"bool" : {
                                                        "should": self.outbound_ip
                                                        }
                                                    }                                                    
                                                ],
                                                "should": self.additional_filters
                                            },
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "1": {
                        "date_histogram": {
                            "field": "@timestamp",
                            "interval": self.elsatic_interval
                        },
                        "global": True,
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "query_string": {
                                                "query": "event_type:\"http\""
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    },
                                                    {"bool" : {
                                                        "should": self.inbound_ip
                                                        }
                                                    }                                                    
                                                ],
                                                "should": self.additional_filters
                                            },
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            # res = es.search(index=index_list,body=query,ignore_unavailable=index_list)
            # events_details = res['facets']['0']['entries']
            # event_list = []
            # for event_info in events_details:
            # 	event_time = event_info['time']/1000
            # 	event_time_obj = datetime.datetime.fromtimestamp(event_time)
            # 	event_time_format = event_time_obj.strftime('%H:%M %m-%d')
            # 	event_count = int(event_info['count'])
            # 	tooltip = "HTTP Transactions{br} "+ str(event_count) + " @ " + event_time_obj.strftime("%Y-%m-%d %H:%M:%S")
            # 	event_list.append({"label":event_time_format,"value":event_count,"tooltext":tooltip})
            # event_list = json.dumps(event_list, cls=DjangoJSONEncoder)
            # return event_list

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)

            timestamp_list = []
            category = []
            dataset_info = []

            series_dict = {
                '1': 'Inbound Traffic',
                '0': 'Outbound Traffic'
            }

            category = []
            temp_cat = []
            dataset = []
            for i in res['facets']:
                for x in res['facets'][i]['entries']:
                    if x['time'] not in temp_cat:
                        temp_cat.append(x['time'])

            category = []
            temp_cat = sorted(temp_cat)
            for time_info in temp_cat:
                ts = time_info / 1000
                time = datetime.datetime.fromtimestamp(ts)
                local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(self.timezone))
                time = local_time.strftime("%Y %b %d %H:%M")
                category.append({"label": time})

            for i in res['facets']:
                d = {}
                data = []
                total_count = 0
                t = 0
                for x in res['facets'][i]['entries']:
                    while (x['time'] != temp_cat[t]):
                        data.append({"value": 0})
                        t += 1
                    ts = x['time'] / 1000
                    t += 1
                    data.append({"value": x['count']})
                    total_count += x['count']
                d['seriesname'] = series_dict[i]
                d["data"] = data
                dataset.append(d)
            final_response = {'category': category, 'dataset': dataset}
            final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
            return final_response

    def httpuseragent(self):
        """
        Function for getting Http user agent details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.http_user_agent.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"http\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            agent_details = res['facets']['terms']['terms']
            agent_list = []
            for agentinfo in agent_details:
                agent_count = agentinfo['count']
                agent_name = agentinfo['term']
                agent_list.append({"label": agent_name, "value": agent_count})
            agent_list = json.dumps(agent_list, cls=DjangoJSONEncoder)
            return agent_list

    def httpmethod_details(self):
        """
        Class for getting Http method details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.http_method.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"http\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            method_details = res['facets']['terms']['terms']
            method_list = []
            for methodinfo in method_details:
                method_count = methodinfo['count']
                method_name = methodinfo['term']
                method_list.append({"label": method_name, "value": method_count})
            method_list = json.dumps(method_list, cls=DjangoJSONEncoder)
            return method_list

    def httphostname_details(self):
        """
        Class for getting Http outbound hostname details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.hostname.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"http\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    },
                                                    { "bool" : {
                                                        "should": self.outbound_ip
                                                        }
                                                    }                                                    
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            hostname_details = res['facets']['terms']['terms']
            hostname_details = json.dumps(hostname_details, cls=DjangoJSONEncoder)
            return hostname_details

    def http_inbound_details(self):
        """
        Class for getting Http inbound hostname details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.hostname.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"http\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    },
                                                    { "bool" : {
                                                        "should": self.inbound_ip
                                                        }
                                                    }                                                    
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            hostname_details = res['facets']['terms']['terms']
            hostname_details = json.dumps(hostname_details, cls=DjangoJSONEncoder)
            return hostname_details

    def httpstatus_details(self):
        """
            Class for getting Http status details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.status",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"http\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            status_details = res['facets']['terms']['terms']
            status_list = []
            for statusinfo in status_details:
                status_count = statusinfo['count']
                status_name = statusinfo['term']
                status_list.append({"label": status_name, "value": status_count})
            status_list = json.dumps(status_list, cls=DjangoJSONEncoder)
            return status_list

    def httprefer_details(self):
        """
            Class for getting Http Referer details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "facets": {
                    "terms": {
                        "terms": {
                            "field": "http.http_refer.raw",
                            "size": 10,
                            "order": "count",
                            "exclude": []
                        },
                        "facet_filter": {
                            "fquery": {
                                "query": {
                                    "filtered": {
                                        "query": {
                                            "bool": {
                                                "should": [
                                                    {
                                                        "query_string": {
                                                            "query": "event_type:\"http\""
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        "filter": {
                                            "bool": {
                                                "must": [
                                                    ranges,
                                                    { "bool" : {
                                                        "should": self.hostquery
                                                        }
                                                    }
                                                ],
                                                "should": self.additional_filters
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "size": 0
            }

            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            referer_details = res['facets']['terms']['terms']
            referer_details = json.dumps(referer_details, cls=DjangoJSONEncoder)
            return referer_details

    def transaction_details(self):
        """
        Class for getting Http Transaction details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        if index_list:
            query = {
                "query": {
                    "filtered": {
                        "query": {
                            "bool": {
                                "should": [
                                    {
                                        "query_string": {
                                            "query": "event_type:\"http\""
                                        }
                                    }
                                ]
                            }
                        },
                        "filter": {
                            "bool": {
                                "must": [
                                    ranges,
                                    { "bool" : {
                                        "should": self.hostquery
                                        }
                                    }
                                ],
                                "should": self.additional_filters
                            }
                        }
                    }
                },
                "highlight": {
                    "fields": {},
                    "fragment_size": 2147483647,
                    "pre_tags": [
                        "@start-highlight@"
                    ],
                    "post_tags": [
                        "@end-highlight@"
                    ]
                },
                "size": 500,
                "sort": [
                    {
                        "@timestamp": {
                            "order": "desc"
                        }
                    }
                ]
            }
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            transaction_details = res['hits']['hits']
            for item in transaction_details:
                try:
                    utc_time = datetime.datetime.strptime(item['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                    local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                    item['_source']['timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    pass
            transaction_details = json.dumps(transaction_details, cls=DjangoJSONEncoder)
            return transaction_details

    def http_trend(self):
        """
        Function for Http Trend Details
        """

        index_range = self.index_range + self.index_range
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
        else:
            base = datetime.datetime.today()
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        # time calculation for 1 day trend
        time = datetime.datetime.now() - datetime.timedelta(minutes=self.duration_info)
        time_1day_new_from = time.isoformat()

        time_1day = time - datetime.timedelta(days=1)
        time_1day_old_from = time_1day.isoformat()

        time_1day_old = time_1day + datetime.timedelta(minutes=self.duration_info)
        time_1day_old_to = time_1day_old.isoformat()

        # time calculation for 4 hour trend
        time = datetime.datetime.now() - datetime.timedelta(minutes=self.duration_info)
        time_4hour_new_from = time.isoformat()

        time_4hours = time - datetime.timedelta(hours=4)
        time_4hours_old_from = time_4hours.isoformat()

        time_4hour_old = time_4hours + datetime.timedelta(minutes=self.duration_info)
        time_4hour_old_to = time_4hour_old.isoformat()

        # time calculation for 1 hour trend
        time = datetime.datetime.now() - datetime.timedelta(minutes=self.duration_info)
        time_1hour_new_from = time.isoformat()

        time_1hours = time - datetime.timedelta(hours=1)
        time_1hours_old_from = time_1hours.isoformat()

        time_1hour_old = time_1hours + datetime.timedelta(minutes=self.duration_info)
        time_1hour_old_to = time_1hour_old.isoformat()

        query = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"http\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1day_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"http\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1day_old_from,
                                                    "to": time_1day_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        # print query

        query1 = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"http\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_4hour_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"http\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_4hours_old_from,
                                                    "to": time_4hour_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        # print query1

        query2 = {
            "facets": {
                "0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"http\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1hour_new_from,
                                                    "to": "now"
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                },
                "old_0": {
                    "query": {
                        "filtered": {
                            "query": {
                                "query_string": {
                                    "query": "event_type:\"http\""
                                }
                            },
                            "filter": {
                                "bool": {
                                    "must": [
                                        {
                                            "match_all": {}
                                        },
                                        {
                                            "range": {
                                                "@timestamp": {
                                                    "from": time_1hours_old_from,
                                                    "to": time_1hour_old_to
                                                }
                                            }
                                        },
                                        { "bool" : {
                                            "should": self.hostquery
                                            }
                                        }
                                    ],
                                    "should": self.additional_filters
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        # print query2

        http_trend_details = {}
        # calculation for 1 day trend
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        count_1day_new = res['facets']['0']['count']
        count_1day_old = res['facets']['old_0']['count']

        if count_1day_old > 0:
            perc_1day = (float(count_1day_new) / float(count_1day_old)) * float(100)
            percent_diff_1day = perc_1day - 100
            percent_diff_1day = round(percent_diff_1day, 2)
        else:
            # percent_diff_1day = float(count_1day_new) * float(100)
            percent_diff_1day = "?"

        # calculation for 4 hour trend
        res = es.search(index=index_list, body=query1, ignore_unavailable=index_list)
        count_4hour_new = res['facets']['0']['count']
        count_4hour_old = res['facets']['old_0']['count']

        if count_4hour_old > 0:
            perc_4hour = (float(count_4hour_new) / float(count_4hour_old)) * float(100)
            percent_diff_4hour = perc_4hour - 100
            percent_diff_4hour = round(percent_diff_4hour, 2)
        else:
            # percent_diff_4hour = float(count_4hour_new) * float(100)
            percent_diff_4hour = "?"

        # calculation for 1 hour trend
        res = es.search(index=index_list, body=query2, ignore_unavailable=index_list)
        count_1hour_new = res['facets']['0']['count']
        count_1hour_old = res['facets']['old_0']['count']

        if count_1hour_old > 0:
            perc_1hour = (float(count_1hour_new) / float(count_1hour_old)) * float(100)
            percent_diff_1hour = perc_1hour - 100
            percent_diff_1hour = round(percent_diff_1hour, 2)
        else:
            # percent_diff_1hour = float(count_1hour_new) * float(100)
            percent_diff_1hour = "?"

        http_trend_details = {"count_1day_new": count_1day_new, "count_1day_old": count_1day_old,
                              "perc_1day": percent_diff_1day, "count_4hour_new": count_4hour_new,
                              "count_4hour_old": count_4hour_old, "perc_4hour": percent_diff_4hour,
                              "count_1hour_new": count_1hour_new, "count_1hour_old": count_1hour_old,
                              "perc_1hour": percent_diff_1hour}

        http_trend_details = json.dumps(http_trend_details, cls=DjangoJSONEncoder)
        return http_trend_details

    def http_world(self):
        """
        Function for world map Details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.continent_code",
                        "size": 100,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})

        # map_info.append({"id":"23","value":"2340"})
        # map_info.append({"id":"104","value":"123"})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info

    def http_usa(self):
        """
        Function for http usa map Details
        """
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        query = {
            "facets": {
                "map": {
                    "terms": {
                        "field": "geoip.region_name.raw",
                        "size": 100,
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        map_details = res['facets']['map']['terms']
        map_info = []
        for map_item in map_details:
            map_count = map_item['count']
            map_term = map_item['term']
            map_info.append({"id": map_term, "value": map_count})
        map_info = json.dumps(map_info, cls=DjangoJSONEncoder)
        return map_info

    def getHttpUrl(self):
        """
        Function for http URL Details
        """      

        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]

        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "http.url.raw",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"http\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                },
                                                { "bool" : {
                                                    "should": self.outbound_ip
                                                    }
                                                }                                                
                                            ],                                            
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = res['facets']['terms']['terms']
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response
