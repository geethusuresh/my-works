from django.conf.urls import include, url
from django.contrib.auth.decorators import login_required

from dashboard.decorators import admin_user_required
from dashboard.views import HttpDashboard, AlertsDashboard, SshDashboard, TlsDashboard, PrivacyDashboard, \
    HttpExtendedDashboard, FlowDashboard, FileDashboard, ProxyDashboard, CustomerHost, \
    InfraDashboard, SaveDashboard, IntrusionPrevention, WidgetInfo, RestoreDash, \
    DashboardInfo, DashGraphInfo, PopupDetails, Profile, CasbSettings, DashboardMenuSettings,\
    HelpView, SettingsConfig, SeverityView, CustomerView, SeverityDeleteView, HttpTrafficView, HostInfoView,\
    HttpTrafficDeleteView, HostSettingsView, HostSettingsDeleteView, CloudView, HelpDeleteView, \
    RealTimeAlertAnalyticsView, IbmConfigDeleteView, VirusTotalConfigDeleteView, OpswatConfigDeleteView, \
    WatchListView, AutoReloadTimeView, NearByAlertsView, EventsGrouping, TimeZonesView, EventFilters




urlpatterns = [
               url(r'^http_dash$', HttpDashboard.as_view(), name='HttpDashboard'),
               url(r'^alert_dash$', AlertsDashboard.as_view(), name='AlertDashboard'),
               url(r'^ssh_dash$', SshDashboard.as_view(), name='SSHDashboard'),
               url(r'^flow_dash$', FlowDashboard.as_view(), name='FlowDashboard'),
               url(r'^tls_dash$', TlsDashboard.as_view(), name='TLSDashboard'),
               url(r'^http_extended_dash$', HttpExtendedDashboard.as_view(), name='HttpExtendedDashboard'),
               url(r'^privacy_dash$', PrivacyDashboard.as_view(), name='PrivacyDashboard'),
               url(r'^file_dash$', FileDashboard.as_view(), name='FileDashboard'),
               url(r'^proxy_analyzer/$', ProxyDashboard.as_view(), name='ProxyDashboard'),
               url(r'^customer_host$', CustomerHost.as_view(), name='CustomerHost'),
               url(r'^infra_details$', InfraDashboard.as_view(), name='InfraDashboard'),
               url(r'^save_dashboard$', SaveDashboard.as_view(), name='SaveDashboard'),
               url(r'^intrusion_prevention$', IntrusionPrevention.as_view(), name='IntrusionPrevention'),
               url(r'^widget_details$', WidgetInfo.as_view(), name='WidgetInfo'),
               url(r'^restore_dashboard$', RestoreDash.as_view(), name='RestoreDash'),
               url(r'^popup/list$', PopupDetails.as_view(), name='PopupDash'),
               url(r'^dash_details$', DashboardInfo.as_view(), name='DashboardInfo'),
               url(r'^dash_graph_info$', DashGraphInfo.as_view(), name='DashGraphInfo'),
               url(r'^profile_details$', Profile.as_view(), name='Profile'),
               url(r'^casb_settingsinfo$', CasbSettings.as_view(), name='casb_settingsinfo'),
               url(r'^menu_settings', DashboardMenuSettings.as_view(), name='menu_settings'),
               url(r'^help', HelpView.as_view(), name='help'),
               url(r'^delete_help', admin_user_required(HelpDeleteView.as_view()), name='delete_help'),
               url(r'^config', admin_user_required(SettingsConfig.as_view()), name='config'),
               url(r'^delete_ibm_config', admin_user_required(IbmConfigDeleteView.as_view()), name='delete_ibm_config'),
               url(r'^delete_virus_total_config', admin_user_required(VirusTotalConfigDeleteView.as_view()), name='delete_virus_total_config'),
               url(r'^delete_opswat_config', admin_user_required(OpswatConfigDeleteView.as_view()), name='delete_opswat_config'),
               url(r'^severity', admin_user_required(SeverityView.as_view()), name='severity'),
               url(r'^delete_severity', admin_user_required(SeverityDeleteView.as_view()), name='delete_severity'),
               url(r'^customer', admin_user_required(CustomerView.as_view()), name='customer'),
               url(r'^host_info', admin_user_required(HostInfoView.as_view()), name='host_info'),
               url(r'^http_traffic', admin_user_required(HttpTrafficView.as_view()), name='http_traffic'),
               url(r'^delete_http_traffic', admin_user_required(HttpTrafficDeleteView.as_view()), name='delete_http_traffic'),
               url(r'^host_settings', admin_user_required(HostSettingsView.as_view()), name='host_settings'),
               url(r'^delete_host_settings', admin_user_required(HostSettingsDeleteView.as_view()), name='delete_host_settings'),
               url(r'^cloud', admin_user_required(CloudView.as_view()), name='cloud'),
               url(r'^real_time_alert$', RealTimeAlertAnalyticsView.as_view(), name='real_time'),
               url(r'^watchlist$', WatchListView.as_view(), name='watchlist'),
               url(r'^state_reload_time', AutoReloadTimeView.as_view(), name='state_reload_time'),
               url(r'^near_by_alerts/$', NearByAlertsView.as_view(), name='near_by_alerts'),
               url(r'^time_zone/$', TimeZonesView.as_view(), name='time_zone'),
               url(r'^event_group', EventsGrouping.as_view(), name='event_group'),
               url(r'^filters', EventFilters.as_view(), name='filters'),
               # url(r'^azure', SqlView.as_view(), name='azure')
               ]
