import datetime
import dateutil.parser

from django import template

register = template.Library()


@register.filter()
def format_date(date):
    return datetime.datetime.strptime(date, "%Y%m%d").date()


@register.filter()
def tz_format_date(date):
    try:
        date = dateutil.parser.parse(date)
    except:
        date = ""
    return date
