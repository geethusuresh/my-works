from django import template

from dashboard.models import DashboardSettings, UserProfile, Services

register = template.Library()


class MenuPriority(object):
    def __init__(self, menu_settings, userprofile):
        self.menu = menu_settings.dashboards
        self.threat_intelligence = menu_settings.threat_intelligence
        self.vulnerability = menu_settings.vulnerability
        self.other_settings = menu_settings.others
        self.user_profile = userprofile
        try:
            service = Services.objects.get(customer=userprofile.customer)
            self.nessus = service.nessus_scan
        except:
            self.nessus = False


@register.assignment_tag()
def get_menus(user):
    """
    Check dashboard menu items
    :return: MenuPriority object
    """
    menu_settings, created = DashboardSettings.objects.get_or_create(user=user)
    userprofile = UserProfile.objects.get(user=user)
    return MenuPriority(menu_settings, userprofile)
