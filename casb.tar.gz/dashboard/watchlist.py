import json
import datetime

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core.serializers.json import DjangoJSONEncoder
from django.views.decorators.csrf import csrf_exempt

from elasticsearch import Elasticsearch

from dashboard.models import UserProfile, Customer, Watchlist
from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from common import CommonInfo


es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class WatchListInfo:

    def __init__(self, filters):
        hostid = filters['host_details']
        self.hostquery = []
        for hostitem in hostid:
            self.hostquery.append({"term": {"casbuid.raw": hostitem["ip"]}})

    def add_watchlist(self,watch_item,userprofile):

        """
        Function for adding watch list details
        """
        try:
            Watchlist.objects.create(user=userprofile,entry=watch_item['entry'],entry_type=watch_item['type'], \
                                count=0,watch_read=True,last_observed=datetime.datetime.now())
            status = json.dumps({"status":"success"},cls=DjangoJSONEncoder)
            return status
        except:
            status = json.dumps({"status":"failed"},cls=DjangoJSONEncoder)
            return status


    def get_watchlist(self,userprofile):

        """
        Function for getting watchlist details
        """ 
        user_watchlist = Watchlist.objects.filter(user=userprofile)

        global_new_count = 0
        watch_list = []
        watch_list_global = {}
        global_watch_flag = False 

        for item in user_watchlist:            
            from_time = item.last_observed                                                      
            current_time = datetime.datetime.now()
            from_time_format = datetime.datetime.strptime(from_time.strftime('%Y-%m-%d %H:%M:%S'),'%Y-%m-%d %H:%M:%S')
            current_time_format = datetime.datetime.strptime(current_time.strftime('%Y-%m-%d %H:%M:%S'),'%Y-%m-%d %H:%M:%S')

            diff_minutes = (current_time_format - from_time_format).days*24*60        

            index_range = CommonInfo().elastic_index_range(diff_minutes)
            base = datetime.datetime.today()
            date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, index_range)]            

            index_list = [('logstash-'+date)for date in date_list]           

            watchlist_item = {"type":item.entry_type,"entry":item.entry}
            watchlist_condition = CommonInfo().make_watchlist_condition(watchlist_item)

            query = {
                    "facets": {
                        "0": {
                           "query": {
                                "filtered": {
                                    "query": {
                                        "query_string": {
                                            "query": "event_type:\"alert\""
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [                                                
                                                {
                                                    "range": {
                                                        "@timestamp": {
                                                            "from": from_time,
                                                            "to": "now"
                                                        }
                                                    }
                                                },
                                                watchlist_condition,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],                                            
                                        }
                                    }
                                }
                            }
                        }
                    }
                }            
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)            
            total_alerts_count = res['facets']['0']['count']
            #print  "total alerts count=", total_alerts_count           
            old_alerts_count = item.count
            #print "old alerts count=", old_alerts_count
           
            if item.watch_read == True and total_alerts_count > 0:
                item.last_observed = datetime.datetime.now()
                item.count = total_alerts_count
                item.watch_read = False                              
                item.save()
                global_new_count = global_new_count + total_alerts_count
                global_watch_flag = True
            elif item.watch_read == False:
                new_count = total_alerts_count + old_alerts_count
                if total_alerts_count > 0:
                    item.last_observed = datetime.datetime.now()
                item.count = new_count
                item.watch_read = False
                item.save()
                global_new_count = global_new_count + new_count
                global_watch_flag = True            

            watch_list.append({"entry":item.entry,"entry_type":item.entry_type,"count":item.count, \
                            "last_observed":item.last_observed,"entry_id":item.id})
        watch_list_global = {"new_count":global_new_count,"watch_items":watch_list,"global_watch_flag":global_watch_flag}
        watch_list_global = json.dumps(watch_list_global,cls=DjangoJSONEncoder)
        return watch_list_global

    def hide_watchlist(self,userprofile):

        """
        Function for hide watch list details
        """
        
        try:
            watch_info = Watchlist.objects.filter(user=userprofile)
            for item in watch_info:
                item.watch_read = True
                item.save()
            status = json.dumps({"status":"success"},cls=DjangoJSONEncoder)
            return status
        except:
            status = json.dumps({"status":"failed"},cls=DjangoJSONEncoder)
            return status

    def delete_watchlist(self,entry_id):

        """
        Function for delete the entry details
        """

        try:
            Watchlist.objects.filter(id=entry_id).delete()
            status = json.dumps({"status":"success"},cls=DjangoJSONEncoder)
            return status
        except:
            status = json.dumps({"status":"failed"},cls=DjangoJSONEncoder)
            return status

















            
            

        