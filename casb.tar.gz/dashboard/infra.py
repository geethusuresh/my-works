import json
import datetime

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core.serializers.json import DjangoJSONEncoder
from django.views.decorators.csrf import csrf_exempt

from elasticsearch import Elasticsearch

from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from dashboard.models import UserProfile, Customer
from common import CommonInfo

es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class InfraInfo:
    def __init__(self, filters):
        date_duration = filters['date_minutes']
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)
        self.base = date_duration['base']
        self.date_start = date_duration['base1']
        hostid = filters['host_details']        
        self.hostquery = []
        self.hostquery.append({"term": {"casbuid.raw": hostid}})

    def host_alerts(self):
        if self.base:
            base = datetime.datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.datetime.today()
            time = datetime.datetime.now()-datetime.timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-'+date)for date in date_list]

        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "alert.severity",
                        "size": 10,
                        "order": "term",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"alert\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                            ],
                                            "should": self.hostquery
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        severity_list = []
        try:
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            severity_details = res['facets']['terms']['terms']
            print severity_details
            for sevinfo in severity_details:
                sev_count = sevinfo['count']
                sev_name = sevinfo['term']
                if sev_name == 1:
                    sev_label = "High Severity - " + str(sev_count)
                    icon = "/static/images/high-severity-icon.png"
                elif sev_name == 2:
                    sev_label = "Medium Severity - " + str(sev_count)
                    icon = "/static/images/medium-severity-icon.png"
                elif sev_name == 3:
                    sev_label = "Low Severity - " + str(sev_count)
                    icon = "/static/images/low-severity-icon.png"
                severity_list.append({"name": sev_label, "url": "null", "icon": icon})
        except:
            if not severity_list:
                severity_list.append({"name": "High Severity - 0", "url": "null",
                                      "icon": "/static/images/high-severity-icon.png"})
                severity_list.append({"name": "Medium Severity - 0", "url": "null",
                                      "icon": "/static/images/medium-severity-icon.png"})
                severity_list.append({"name": "Low Severity - 0", "url": "null",
                                      "icon": "/static/images/low-severity-icon.png"})
        return severity_list
