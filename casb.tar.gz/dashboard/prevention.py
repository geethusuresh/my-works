import re
import ssl
import pprint
import socket
import datetime
from multiprocessing import Pool

from elasticsearch import Elasticsearch

from dashboard.models import PreventionSettings, HostInfo, BlockedIPS
from casb.settings import SITE_ROOT
from casb.settings import ELASTIC_SEARCH_URL

es = Elasticsearch(ELASTIC_SEARCH_URL)


def securityAction(host, sourceip, action, blocked_ip):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Require a certificate from the server. We used a self-signed certificate
    # so here ca_certs must be the server certificate itself.
    ssl_sock = ssl.wrap_socket(s,
                               ca_certs=SITE_ROOT + "/server.crt",
                               cert_reqs=ssl.CERT_REQUIRED)
    temp_flag = False
    try:
        ssl_sock.settimeout(3)
        # ssl_sock.connect((host.ip, 9856))
        ssl_sock.connect((host, 9856))
        send_str = action + "," + sourceip
        ssl_sock.write(send_str)
        temp_flag = True
    except:
        blocked_ip.process_status = "Couldn't connect.Connection timed out"
        blocked_ip.save()
        print "Couldn't connect.Connection timed out"
    if temp_flag:
        try:
            ssl_sock.settimeout(3)
            response = ssl_sock.read(1024)
            blocked_ip.process_status = response
            if action == "block":
                blocked_ip.status = 1
                blocked_ip.process_status = "IP blocked"
            elif action == "allow":
                blocked_ip.status = 2
                blocked_ip.process_status = "IP unblocked"
            blocked_ip.last_updated = datetime.datetime.now()
            blocked_ip.save()
        except:
            blocked_ip.process_status = "Didn't get response from Host"
            blocked_ip.save()
            print "Didn't get response from Host"
    return 1


def blockip(host_list=[], b_time=None):
    base = datetime.datetime.today()
    date_list = [(base - datetime.timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, 30)]
    index_list = [('logstash-' + date) for date in date_list]

    time = datetime.datetime.now() - datetime.timedelta(days=30)
    time = time.isoformat()
    prevention_details = PreventionSettings.objects.filter(active=True).values_list('host__ip','severity__severity_number')  
    filter_prev = []
    for item in prevention_details:        
        es = Elasticsearch(ELASTIC_SEARCH_URL)
        query = {
            "query": {
                "filtered": {
                    "query": {
                        "bool": {
                            "should": [
                                {
                                    "query_string": {
                                        "query": "event_type:\"alert\""
                                    }
                                }
                            ]
                        }
                    },
                    "filter": {
                        "bool": {
                            "must": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "from": time,
                                            "to": "now"
                                        }
                                    }
                                },
                                { "bool" : {
                                        "should": [
                                        {
                                            "term": {
                                                "alert.severity": item[1]
                                            }
                                        },
                                        {
                                            "term": {
                                                "host": item[0]
                                            }
                                        }
                                ],
                                                        }
                                                    }                                
                            ],                            
                        }
                    }
                }
            },
            "highlight": {
                "fields": {},
                "fragment_size": 2147483647,
                "pre_tags": [
                    "@start-highlight@"
                ],
                "post_tags": [
                    "@end-highlight@"
                ]
            },
            "size": 500,
            "sort": [
                {
                    "@timestamp": {
                        "order": "desc"
                    }
                }
            ]
        }
        try:
            res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
            host_obj = HostInfo.objects.get(ip=item[0])
            for x in res['hits']['hits']:
                blocked_ips = BlockedIPS.objects.filter(host=host_obj, blocked_ip=x['_source']['src_ip'], status__in=[1,2,3,4]).exists()
                if not blocked_ips:
                    blocked_ip = BlockedIPS.objects.create(host=host_obj, blocked_ip=x['_source']['src_ip'],
                                                                      status=3)
                    print "Ready to block IP...", x['_source']['src_ip']

            queued_objects = BlockedIPS.objects.filter(host=host_obj, status=3).distinct('blocked_ip')
            for queued_object in queued_objects:
                print "Blocking Ip...", queued_object.blocked_ip
                securityAction('192.168.61.118', queued_object.blocked_ip, "block", queued_object)
            # unblockip(host_obj)
        except Exception as e:
            print "Error: ", e



def unblockip():
    prevention_details = PreventionSettings.objects.filter(active=True, auto_unblock=True).values_list('host', 'unblock_interval')
    for item in prevention_details:
        blocked_ips = BlockedIPS.objects.filter(host=item[0], status=4).distinct('blocked_ip')
        for unblock_obj in blocked_ips:
            next_unblock = unblock_obj.blocked + datetime.timedelta(minutes=item[1])
            # print next_unblock, datetime.datetime.now()
            if next_unblock.replace(tzinfo=None) <= datetime.datetime.now():
                try:
                    print "Unblocking Ip...", unblock_obj.blocked_ip
                    host_obj = unblock_obj.host
                    # securityAction('192.168.61.118', obj_blocked_ip.blocked_ip, "allow", obj_blocked_ip)
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    ssl_sock = ssl.wrap_socket(s, ca_certs=SITE_ROOT + "/server.crt",
                                        cert_reqs=ssl.CERT_REQUIRED)
                    ssl_sock.settimeout(3)
                    ssl_sock.connect(('192.168.61.118', 9856))
                    send_str = 'allow' + "," + unblock_obj.blocked_ip
                    ssl_sock.write(send_str)
                    ssl_sock.settimeout(3)
                    response = ssl_sock.read(1024)
                    unblock_obj.delete()
                    # unblock_obj.process_status = response
                    # unblock_obj.status = 2
                    # unblock_obj.last_updated = datetime.datetime.now()
                    # unblock_obj.save()
                except Exception as e:
                    print e
                    unblock_obj.process_status = "Didn't get response from Host"
                    unblock_obj.save()