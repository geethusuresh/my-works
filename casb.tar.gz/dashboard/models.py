import pytz

from hashlib import md5
from datetime import datetime

from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q

from multiselectfield import MultiSelectField
from ckeditor.fields import RichTextField

DASH_LIST = (
    ("Alert", "Alert"),
    ("Web", "Web"),
    ("SSH", "SSH"),
    ("TLS", "TLS"),
    ("Reputation", "Reputation"),
    ("File", "File"),
    ("Flow", "Flow"),
    ("Mydash", "Mydash")   
)

BLOCKED_STATUS = (
    ('1', "Blocked"),
    ('2', "Unblocked"),
    ('3', "Waiting for Block"),
    ('4', "Waiting for Unblock")
)

TIME_ZONE = tuple([(timezone, timezone) for timezone in pytz.all_timezones])

# Create your models here.
class Customer(models.Model):
    customerid = models.CharField(max_length=5, null=True, blank=True, unique=True)
    customername = models.TextField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    currency = models.TextField(null=True, blank=True)
    enterby = models.ForeignKey(User, null=True, blank=True)
    enterdate = models.DateTimeField(null=True, blank=True)
    active = models.BooleanField(default=True)
    logo = models.FileField(upload_to='customer/logo/', null=True, blank=True)
    rowstamp = models.TextField(null=True, blank=True)

    def __unicode__(self):
        return self.customername

    class Meta:
        verbose_name_plural = "Customers"

    def natural_key(self):
        return self.customername


class UserProfile(models.Model):
    user = models.ForeignKey(User)
    customer = models.ForeignKey(Customer, null=True, blank=True)
    gender = models.CharField(max_length=5, null=True, blank=True)
    status = models.CharField(max_length=5, null=True, blank=True)
    department = models.CharField(max_length=50, null=True, blank=True)
    title = models.CharField(max_length=50, null=True, blank=True)
    employeetype = models.CharField(max_length=30, null=True, blank=True)
    jobcode = models.CharField(max_length=30, null=True, blank=True)
    supervisor = models.ForeignKey(User, null=True, related_name='supervisor', blank=True)
    location = models.CharField(max_length=30, null=True, blank=True)
    locationsite = models.CharField(max_length=30, null=True, blank=True)
    signature = models.TextField(null=True, blank=True)
    addressline1 = models.TextField(null=True, blank=True)
    addressline2 = models.TextField(null=True, blank=True)
    city = models.CharField(max_length=30, null=True, blank=True)
    regiondistrict = models.CharField(max_length=30, null=True, blank=True)
    country = models.CharField(max_length=30, null=True, blank=True)
    postalcode = models.CharField(max_length=15, null=True, blank=True)
    languagecode = models.CharField(max_length=5, null=True, blank=True)
    locale = models.CharField(max_length=5, null=True, blank=True)
    timezone = models.CharField(max_length=5, null=True, blank=True)
    lastlogin = models.DateTimeField(null=True, blank=True)
    rowstamp = models.IntegerField(null=True, blank=True)
    active = models.BooleanField(default=True)
    notify = models.BooleanField(default=True)
    is_admin = models.NullBooleanField(default=False, null=True, blank=True)
    first_login = models.NullBooleanField(default=True, null=True, blank=True)
    image = models.ImageField(upload_to="profile_pic", null=True, blank=True)
    ip = models.TextField(null=True, blank=True)
    theme = models.CharField(max_length=8, null=True, blank=True)
    timezone = models.CharField(default='UTC', max_length=127, choices=TIME_ZONE)

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural = "UserProfiles"

    def natural_key(self):
        return u'%s %s' % (self.user.first_name, self.user.last_name)

class Categories(models.Model):
    category_name = models.TextField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.category_name

    class Meta:
        verbose_name_plural = "Categories"


class SiteCategories(models.Model):
    category = models.ForeignKey(Categories, null=True, blank=True)
    sitename = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.category.category_name

    class Meta:
        verbose_name_plural = "Site Categorization"


class DefaultDashsettings(models.Model):
    dashboard = models.CharField(null=True, blank=True, max_length=10, choices=DASH_LIST)
    settings_info = models.TextField(null=True, blank=True)
    display_name = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return self.dashboard

    class Meta:
        verbose_name_plural = "Dashboard Default Settings"


class Dashsettings(models.Model):
    user = models.ForeignKey(UserProfile, null=True, blank=True)
    dashboard = models.CharField(null=True, blank=True, max_length=10, choices=DASH_LIST)
    settings_info = models.TextField(null=True, blank=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.user.user.username

    class Meta:
        verbose_name_plural = "Dashboard User Settings"


class CloudProvider(models.Model):
    customer = models.ForeignKey(Customer, null=True, blank=True)
    cloud = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return self.cloud

    def natural_key(self):
        return self.cloud

    class Meta:
        verbose_name_plural = "Cloud Provider"


class HostInfo(models.Model):
    customer = models.ForeignKey(Customer, null=True, blank=True)
    host = models.CharField(max_length=250, null=True, blank=True)
    ip = models.CharField(max_length=50, null=True, blank=True)
    hostname = models.CharField(max_length=200, null=True, blank=True)
    cloud = models.ForeignKey(CloudProvider, null=True, blank=True)

    def natural_key(self):
        return self.host

    def __str__(self):
        return self.host

    class Meta:
        verbose_name_plural = "Host Settings"


class Severity(models.Model):
    customer = models.ForeignKey(Customer, null=True, blank=True)
    severity_number = models.IntegerField(null=True, blank=True)
    priority = models.CharField(max_length=50, null=True, blank=True)
    color = models.CharField(max_length=30, null=True, blank=True)

    def __str__(self):
        return self.priority    

    class Meta:
        verbose_name_plural = "Severity"


class BlockedIPS(models.Model):
    host = models.ForeignKey(HostInfo)
    status = models.CharField(max_length=1, null=True, blank=True, choices=BLOCKED_STATUS)
    blocked_ip = models.CharField(max_length=50,null=True, blank=True)
    process_status = models.TextField(null=True, blank=True)
    last_updated = models.DateTimeField(null=True, blank=True)
    blocked = models.DateTimeField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if self.status == 1:
            self.blocked = datetime.now()
        super(BlockedIPS, self).save(*args, **kwargs)

    def __str__(self):
        return self.blocked_ip

    class Meta:
        verbose_name_plural = "Blocked IPS"


class PreventionSettings(models.Model):
    severity = models.ForeignKey(Severity,null = True,blank = True)
    host = models.ForeignKey(HostInfo,null = True,blank = True)
    active = models.BooleanField(default=True)
    auto_unblock = models.BooleanField(default=False)
    unblock_interval = models.IntegerField(default=0)


    def __str__(self):
        return self.host.host

    class Meta:
        verbose_name_plural = "Prevention Settings"

class HttpTraffic(models.Model):
    customer = models.ForeignKey(Customer, null=True, blank=True)
    host = models.ForeignKey(HostInfo)
    ip_range = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.host.hostname

    class Meta:
        verbose_name_plural = "Http Traffic"


DASHBOARDS = (('my', 'My Dashboard'),
              ('alert', 'Alert Dashboard'),
              ('web', 'Web Dashboard'),
              ('ssh', 'SSH Dashboard'),
              ('flow', 'Flow Dashboard'),
              ('file', 'File-Transaction Dashboard'),
              ('tls', 'TLS Dashboard'),
              ('reputation', 'Reputation Dashboard'),
              ('infra', 'Infra Dashboard'),             
              )
THREAT_INTELLIGENCE = (('ibm', 'IBM x-Force'),
                       ('scan', 'Virus Scan'))

VULNERABILITY_SCANS = (('nessus', 'Nessus'),
                       ('openvas', 'Open VAS'),
                       ('azure', 'Azure'))

OTHERS = (('noc', 'Noc Dashboard'),
          ('intrusion', 'Intrusion Prevention'))


class DashboardSettings(models.Model):
    user = models.OneToOneField(User)
    dashboards = MultiSelectField(choices=DASHBOARDS, max_choices=9, max_length=255,
                                  default=['my', 'alert', 'web', 'ssh', 'flow', 'file', 'tls', 'reputation', 'infra'])

    threat_intelligence = MultiSelectField(choices=THREAT_INTELLIGENCE, max_choices=2, max_length=255,
                                           default=['ibm', 'scan'])

    vulnerability = MultiSelectField(choices=VULNERABILITY_SCANS, max_choices=2, max_length=255, default=[])

    others = MultiSelectField(choices=OTHERS, max_choices=2, max_length=255,
                                           default=['noc','intrusion'])
    auto_refresh = models.BooleanField(default=False)
    refresh_interval = models.PositiveIntegerField(default=0)

    def __unicode__(self):
        return u"Dashboard Menu Settings"

    class Meta:
        verbose_name = "Dashboard Menu Settings"


class Help(models.Model):
    title = models.CharField(max_length=255)
    content = RichTextField()
    publish = models.BooleanField(default=True)
    sort_order = models.IntegerField(default=0)
    created = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return self.title

    class Meta:
        verbose_name = "Help"
        ordering = ('sort_order', )

class Services(models.Model):
    customer = models.OneToOneField(Customer)
    nessus_scan = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Services"

class Watchlist(models.Model):
    user = models.ForeignKey(UserProfile, null=True, blank=True)
    entry = models.CharField(max_length=250,null=True, blank=True)
    entry_type = models.CharField(max_length=50,null=True, blank=True)
    count = models.IntegerField(null=True, blank=True)    
    last_observed = models.DateTimeField(null=True, blank=True)
    watch_read = models.BooleanField(default=False)

    def __str__(self):
        return self.entry

    class Meta:
        verbose_name_plural = "Watchlist"

class Filters(models.Model):
    user = models.ForeignKey(UserProfile, null=True, blank=True)
    entry = models.TextField(null=True, blank=True)    
    pin_status = models.BooleanField(default=False)

    def __str__(self):
        return self.entry

    class Meta:
        verbose_name_plural = "Filters"



