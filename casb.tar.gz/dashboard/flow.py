import json
import time
import pytz
from datetime import datetime, timedelta, date

from django.db import connection
from django.shortcuts import render_to_response, render
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext, Template, Context
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View
from django.core.serializers.json import DjangoJSONEncoder

from elasticsearch import Elasticsearch
from dateutil import parser

from casb.settings import ELASTIC_SEARCH_URL, ELASTIC_TIMEOUT
from dashboard.common import CommonInfo, get_timezone
from dashboard.models import UserProfile, Customer

es = Elasticsearch(ELASTIC_SEARCH_URL, timeout=ELASTIC_TIMEOUT)


class FlowDashboardAjax:
    def __init__(self, filters, request=None):
        date_duration = filters['date_minutes']
        self.elsatic_interval = date_duration['elastic_interval']
        self.duration_info = date_duration['date_duration']
        self.index_range = CommonInfo().elastic_index_range(self.duration_info)
        self.base = date_duration['base']
        self.date_start = date_duration['base1']

        self.request = request
        self.timezone = get_timezone(self.request)

        hostid = filters['host_details']
        self.hostquery = []
        for hostitem in hostid:
            self.hostquery.append({"term": {"casbuid.raw": hostitem["ip"]}})

        try:
            self.additional_filters = []            
            self.additional_filters = CommonInfo().make_filter(filters)
        except:            
            pass

    def perdelta(self, start, end, delta):
        while start < end:
            yield start
            start += delta

    def getHistogram(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            gen_obj = self.perdelta(time, base, timedelta(minutes=10))
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            from_date = datetime.now() - timedelta(minutes=self.duration_info)
            time = from_date.isoformat()
            to_date = datetime.now()
            gen_obj = self.perdelta(from_date, to_date, timedelta(minutes=10))
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }

        query = {
            "facets": {
                "0": {
                    "date_histogram": {
                        "field": "@timestamp",
                        "interval": self.elsatic_interval
                    },
                    "global": 'true',
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "query_string": {
                                            "query": "event_type:\"flow\" AND flow.state:\"new\""
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "1": {
                    "date_histogram": {
                        "field": "@timestamp",
                        "interval": self.elsatic_interval
                    },
                    "global": 'true',
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "query_string": {
                                            "query": "event_type:\"flow\" AND flow.state:\"established\""
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "2": {
                    "date_histogram": {
                        "field": "@timestamp",
                        "interval": self.elsatic_interval
                    },
                    "global": 'true',
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "query_string": {
                                            "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        date_list = [(base - timedelta(days=x)).strftime('%Y.%m.%d') for x in range(0, self.index_range)]
        index_list = [('logstash-' + date) for date in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)        
        
        series_dict = {
                '2':'Closed flows',
                '1':'Established flows',
                '0':'New flows'
        }
        cat_time = list(gen_obj)
        category = []
        temp_cat = []
        dataset = []
        for i in res['facets']:
            for x in res['facets'][i]['entries']:
                if x['time'] not in temp_cat:
                    ts = x['time'] / 1000
                    time = datetime.fromtimestamp(ts)
                    local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(self.timezone))
                    time = local_time.strftime("%Y %b %d %H:%M")
                    category.append({"label": time})
                    temp_cat.append(x['time'])

        temp_cat = sorted(temp_cat)
        cat_length = len(temp_cat)
        for i in res['facets']:
            d = {}
            data = []
            total_count = 0
            t = 0
            for x in res['facets'][i]['entries']:
                while (x['time'] != temp_cat[t]):
                    data.append({"value": 0})
                    t += 1
                ts = x['time'] / 1000
                data.append({"value": x['count']})
                t += 1
                total_count += x['count']

            data.extend([{"value": 0} for j in xrange(t, cat_length)])
            d['seriesname'] = series_dict[i]
            d["data"] = data
            dataset.append(d)
        final_response = {'category': category, 'dataset': dataset}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getDestinationPort(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "dest_port",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getSourcePort(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "src_port",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getDestinationIP(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "dest_ip",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getSourceIP(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "src_ip",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getBytestoClient(self):
        """
            Function returns total hits of files.
        """
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms_stats": {
                        "value_field": "flow.bytes_toclient",
                        "key_field": "flow.bytes_toclient",
                        "size": 10,
                        "order": "count"
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {}
        data_list = []
        for item in res['facets']['terms']['terms']:
            data_list.append({'label': item['term'], 'value': item['total_count']})
            # final_response[series_dict[i]] = res['facets'][i]['count']
        final_response['data_list'] = data_list
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getBytestoServer(self):
        """
            Function returns total hits of files.
        """
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms_stats": {
                        "value_field": "flow.bytes_toserver",
                        "key_field": "flow.bytes_toserver",
                        "size": 10,
                        "order": "count"
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {}
        data_list = []
        for item in res['facets']['terms']['terms']:
            data_list.append({'label': item['term'], 'value': item['total_count']})
            # final_response[series_dict[i]] = res['facets'][i]['count']
        final_response['data_list'] = data_list
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getPacketstoClient(self):
        """
            Function returns total hits of files.
        """
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms_stats": {
                        "value_field": "flow.pkts_toclient",
                        "key_field": "flow.pkts_toclient",
                        "size": 10,
                        "order": "count"
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {}
        data_list = []
        for item in res['facets']['terms']['terms']:
            data_list.append({'label': item['term'], 'value': item['total_count']})
            # final_response[series_dict[i]] = res['facets'][i]['count']
        final_response['data_list'] = data_list
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getPacketstoServer(self):
        """
            Function returns total hits of files.
        """
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms_stats": {
                        "value_field": "flow.pkts_toserver",
                        "key_field": "flow.pkts_toserver",
                        "size": 10,
                        "order": "count"
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {}
        data_list = []
        for item in res['facets']['terms']['terms']:            
            data_list.append({'label': item['term'], 'value': item['total_count']})
            # final_response[series_dict[i]] = res['facets'][i]['count']
        final_response['data_list'] = data_list
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getTcpState(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "tcp.state",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getTcpFlags(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "tcp.tcp_flags",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getTcpFlagsClient(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "tcp.tcp_flags_tc",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }
        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getTcpFlagsServer(self):
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "facets": {
                "terms": {
                    "terms": {
                        "field": "tcp.tcp_flags_ts",
                        "size": 10,
                        "order": "count",
                        "exclude": []
                    },
                    "facet_filter": {
                        "fquery": {
                            "query": {
                                "filtered": {
                                    "query": {
                                        "bool": {
                                            "should": [
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                                    }
                                                },
                                                {
                                                    "query_string": {
                                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                                    }
                                                }
                                            ]
                                        }
                                    },
                                    "filter": {
                                        "bool": {
                                            "must": [
                                                    ranges,
                                                { "bool" : {
                                                    "should": self.hostquery
                                                    }
                                                }
                                            ],
                                            "should": self.additional_filters
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            "size": 0
        }

        date_list = [base - timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-' + x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        final_response = {'data': res['facets']['terms']['terms']}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response

    def getDocuments(self):
        """
            Function returns all file transactions.
        """
        if self.base:
            base = datetime.strptime(self.base, '%Y.%m.%d')
            time = datetime.strptime(self.date_start, '%Y.%m.%d')
            time = time.isoformat()
            time1 = base.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": time1
                        }
                    }
                }
        else:
            base = datetime.today()
            time = datetime.now()-timedelta(minutes=self.duration_info)
            time = time.isoformat()
            ranges = {
                    "range": {
                        "@timestamp": {
                            "from": time,
                            "to": "now"
                        }
                    }
                }
        query = {
            "query": {
                "filtered": {
                    "query": {
                        "bool": {
                            "should": [
                                {
                                    "query_string": {
                                        "query": "event_type:\"flow\" AND flow.state:\"new\""
                                    }
                                },
                                {
                                    "query_string": {
                                        "query": "event_type:\"flow\" AND flow.state:\"established\""
                                    }
                                },
                                {
                                    "query_string": {
                                        "query": "event_type:\"flow\" AND flow.state:\"closed\""
                                    }
                                }
                            ]
                        }
                    },
                    "filter": {
                        "bool": {
                            "must": [
                                    ranges,
                                { "bool" : {
                                    "should": self.hostquery
                                    }
                                }
                            ],
                            "should": self.additional_filters
                        }
                    }
                }
            },
            "highlight": {
                "fields": {},
                "fragment_size": 2147483647,
                "pre_tags": [
                    "@start-highlight@"
                ],
                "post_tags": [
                    "@end-highlight@"
                ]
            },
            "size": 500,
            "sort": [
                {
                    "_score": {
                        "order": "desc"
                    }
                }
            ]
        }

        date_list = [base-timedelta(days=x) for x in range(self.index_range)]
        index_list = ['logstash-'+x.strftime('%Y.%m.%d') for x in date_list]
        res = es.search(index=index_list, body=query, ignore_unavailable=index_list)
        temp_response = []
        for i in res['hits']['hits']:
            item = i['_source']
            try:
                src_port = item['src_port']
            except:
                src_port = ""

            try:
                dest_port = item['dest_port']
            except:
                dest_port = ""

            try:
                utc_time = datetime.strptime(i['_source']['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(self.timezone))
                local_time = local_time.strftime("%Y-%m-%d %H:%M:%S")
            except:
                local_time = i['_source']['@timestamp']

            try:
                flow_start_time = parser.parse(item['flow']['start'])
                flow_start_local_time = flow_start_time.astimezone(pytz.timezone(self.timezone))
                flow_start_local_time = flow_start_local_time.strftime("%Y-%m-%d %H:%M:%S")
            except:
                flow_start_local_time = ""

            try:
                flow_end_time = parser.parse(item['flow']['end'])
                flow_end_local_time = flow_end_time.astimezone(pytz.timezone(self.timezone))
                flow_end_local_time = flow_end_local_time.strftime("%Y-%m-%d %H:%M:%S")
            except:
                flow_end_local_time = ""

            temp_response.append({'timestamp': local_time,
                                  'src_ip': item['src_ip'],
                                  'src_port': src_port,
                                  'dest_ip': item['dest_ip'],
                                  'dest_port': dest_port,
                                  'flow_start': flow_start_local_time,
                                  'flow_end': flow_end_local_time})
        final_response = {'data': temp_response}
        final_response = json.dumps(final_response, cls=DjangoJSONEncoder)
        return final_response
