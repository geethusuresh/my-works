from django.db import models

from dashboard.models import Customer


class IpIntelligenceConfiguration(models.Model):
    customer = models.OneToOneField(Customer)
    user_token = models.CharField(max_length=255, null=True, blank=True)
    user_api_key = models.CharField(max_length=255, null=True, blank=True)
    user_password = models.CharField(max_length=255, null=True, blank=True)
    ip_report_api_url = models.URLField(default="https://api.xforce.ibmcloud.com/ipr/")
    dns_status_api_url = models.URLField(default="https://api.xforce.ibmcloud.com/resolve/")
    malware_status_api_url = models.URLField(default="https://api.xforce.ibmcloud.com/ipr/malware/")
    whois_report_api_url = models.URLField(default="https://api.xforce.ibmcloud.com/whois/")

    def __unicode__(self):
        return u"IBM x-force IP intelligence configuration"

    class Meta:
        verbose_name = "IBM x-force IP intelligence configuration"


class VirusScanConfiguration(models.Model):
    customer = models.OneToOneField(Customer)
    user_api_key = models.CharField(max_length=255, null=True, blank=True)
    host = models.URLField(default="http://www.virustotal.com")
    file_scan_url = models.URLField(default="https://www.virustotal.com/vtapi/v2/file/scan")
    file_report_url = models.URLField(default="https://www.virustotal.com/vtapi/v2/file/report")
    url_scan_url = models.URLField(default="https://www.virustotal.com/vtapi/v2/url/scan")
    url_report_url = models.URLField(default="https://www.virustotal.com/vtapi/v2/url/report")
    ip_report_url = models.URLField(default="http://www.virustotal.com/vtapi/v2/ip-address/report")
    domain_report_url = models.URLField(default="http://www.virustotal.com/vtapi/v2/domain/report")

    def __unicode__(self):
        return u"Virus-Total virus scan configuration"

    class Meta:
        verbose_name = "Virus-Total virus scan configuration"


class OpswatVirusScanConfiguration(models.Model):
    customer = models.OneToOneField(Customer)
    user_api_key = models.CharField(max_length=255, null=True, blank=True)
    hash_scan_url = models.URLField(default="http://api.metadefender.com/v2/hash/")

    def __unicode__(self):
        return u"Opswat virus scan configuration"

    class Meta:
        verbose_name = "Opswat virus scan configuration"