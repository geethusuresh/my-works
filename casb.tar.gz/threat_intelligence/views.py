import re
import json
import pytz
import string
import socket
import urllib
import urllib2
import hashlib
import requests
from urlparse import urlparse
from datetime import datetime

from django.views.generic import View
from django.http import HttpResponse
from django.template.loader import get_template
from django.template import RequestContext
from django.http import StreamingHttpResponse
from django.conf import settings

import validators
from IPy import IP
from xhtml2pdf import pisa

from threat_intelligence.models import IpIntelligenceConfiguration, VirusScanConfiguration, OpswatVirusScanConfiguration
from dashboard.models import UserProfile
from dashboard.common import get_timezone


class IpIntelligence(View):
    """
    Class for analyzing IP using IBM x-force API
    @inputparams;
    {
        "IP: 202.88.246.19"
    }
    @outputparams;
    {
        "status": "success",
        "whois_report":"object",
        "dns_status": "object",
        "ip_report": "object",
        "malware_status": "object",
    }
    """

    def post(self, request, *args, **kwargs):
        ip = request.POST.get("ip")
        try:
            IP(ip)
        except ValueError as e:
            return HttpResponse(json.dumps({"status": "error", "message": "Please enter valid IP address"}),
                                content_type="application/json")
        try:
            config = IpIntelligenceConfiguration.objects.get(customer__id=UserProfile.objects.
                                                             get(user=request.user).customer.id)
        except:
            message = "IBM x-force configuration invalid."
            return HttpResponse(json.dumps({"status": "error", "message": message}), content_type="application/json")
        headers = {'Accept': 'application/json', 'Authorization': config.user_token}
        ip_report = requests.get(config.ip_report_api_url + ip, headers=headers)
        dns_status = requests.get(config.dns_status_api_url + ip, headers=headers)
        malware_status = requests.get(config.malware_status_api_url + ip, headers=headers)
        whois_report = requests.get(config.whois_report_api_url + ip, headers=headers)
        ip_report_content = json.loads(ip_report.content)
        dns_status_content = json.loads(dns_status.content)
        whois_report_content = json.loads(whois_report.content)
        malware_status_content = json.loads(malware_status.content)
        for item in ip_report_content['history']:
            if item.get('created'):
                item['created'] = self.get_local_time(item.get('created'))
        for item in dns_status_content['Passive']['records']:
            if item.get('last'):
                try:
                    utc_time = datetime.strptime(item['last'], '%Y-%m-%dT%H:%M:%SZ')
                    local_time = pytz.timezone("UTC").localize(utc_time).astimezone(
                        pytz.timezone(get_timezone(self.request)))
                    item['last'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    pass
        for item in malware_status_content['malware']:
            if item.get('lastseen'):
                item['lastseen'] = self.get_local_time(item['lastseen'])
        try:
            whois_report_content['updatedDate'] = self.get_local_time(whois_report_content['updatedDate'])
        except:
            pass
        if ip_report.status_code == dns_status.status_code == malware_status.status_code == whois_report.status_code == 200:
            ip_intelligence = {"status": "success", "ip_report": ip_report_content,
                               "whois_report": whois_report_content,
                               "dns_status": dns_status_content,
                               "malware_status": malware_status_content}
        else:
            ip_intelligence = {"status": "error", "message": "IBM x-force server down"}
        return HttpResponse(json.dumps(ip_intelligence), content_type="application/json")

    def get_local_time(self, time):
        try:
            utc_time = datetime.strptime(time, '%Y-%m-%dT%H:%M:%S.%fZ')
            local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(get_timezone(self.request)))
            return local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return time


class IbmPdfReport(View):
    """
    Class for generating IP scan report in pdf format
    """

    def get(self, request, *args, **kwargs):
        config = IpIntelligenceConfiguration.objects.get(customer__id=UserProfile.objects.
                                                         get(user=request.user).customer.id)
        ip = request.GET.get('ip')
        headers = {'Accept': 'application/json', 'Authorization': config.user_token}
        ip_report = requests.get(config.ip_report_api_url + ip, headers=headers)
        dns_status = requests.get(config.dns_status_api_url + ip, headers=headers)
        malware_status = requests.get(config.malware_status_api_url + ip, headers=headers)
        whois_report = requests.get(config.whois_report_api_url + ip, headers=headers)
        ip_report_content = json.loads(ip_report.content)
        dns_status_content = json.loads(dns_status.content)
        whois_report_content = json.loads(whois_report.content)
        malware_status_content = json.loads(malware_status.content)
        for item in ip_report_content['history']:
            if item.get('created'):
                item['created'] = self.get_local_time(item.get('created'))
        for item in dns_status_content['Passive']['records']:
            if item.get('last'):
                try:
                    utc_time = datetime.strptime(item['last'], '%Y-%m-%dT%H:%M:%SZ')
                    local_time = pytz.timezone("UTC").localize(utc_time).astimezone(
                        pytz.timezone(get_timezone(self.request)))
                    item['last'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
                except:
                    pass
        for item in malware_status_content['malware']:
            if item.get('lastseen'):
                item['lastseen'] = self.get_local_time(item['lastseen'])
        try:
            whois_report_content['updatedDate'] = self.get_local_time(whois_report_content['updatedDate'])
        except:
            pass
        base_dir = settings.BASE_DIR
        utc_now = datetime.now().replace(tzinfo=pytz.timezone('UTC'))
        now = utc_now.astimezone(pytz.timezone(get_timezone(request)))
        report = {"status": "success", "base_dir": base_dir, "ip_report": ip_report_content,
                  "whois_report": whois_report_content,
                  "dns_status": dns_status_content,
                  "malware_status": malware_status_content,
                  "generated_time": now.strftime("%Y-%m-%d %H:%M:%S")}
        output_filename = "media/scan_report.pdf"
        context = RequestContext(request, {"scan_report": report})
        template = get_template('threat_intelligence/ibm_report.html')
        html = template.render(context)
        result_file = open(output_filename, "w+b")
        pisa.CreatePDF(html, dest=result_file)
        result_file.close()
        result_file = open(output_filename, "rd")
        response = StreamingHttpResponse(result_file, content_type="html/pdf")
        response['Content-Disposition'] = 'attachment; filename="scan_report.pdf"'
        return response

    def get_local_time(self, time):
        try:
            utc_time = datetime.strptime(time, '%Y-%m-%dT%H:%M:%S.%fZ')
            local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(get_timezone(self.request)))
            return local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return time


class VirusScan(View):
    """
    Class for scanning files and urls using Virus-Total API's.
    """

    def post(self, request, *args, **kwargs):
        try:
            config = VirusScanConfiguration.objects.get(customer__id=UserProfile.objects.
                                                        get(user=request.user).customer.id)
        except:
            message = "Virus Total configuration invalid."
            return HttpResponse(json.dumps({"status": "error", "message": message}), content_type="application/json")
        file_obj = request.FILES.get("file", None)
        if file_obj:
            file_obj = file_obj.read()
            request.POST['value'] = hashlib.md5(file_obj).hexdigest()
        scan_type, report_url = self.get_report_url(request.POST.get("value"), config)
        if scan_type == "ip":
            return HttpResponse(json.dumps({"status": "error", "message": "Invalid input"}),
                                content_type="application/json")
        if not scan_type or not report_url:
            return HttpResponse(json.dumps({"status": "error", "message": "Invalid input"}),
                                content_type="application/json")
        if scan_type == "hash":
            scan_report = self.get_scan_report(request.POST.get("value"), report_url, config.user_api_key)
        elif scan_type == "url":
            url_scan_url = config.url_scan_url
            parameters = {"url": request.POST.get('value'), "apikey": config.user_api_key}
            data = urllib.urlencode(parameters)
            req = urllib2.Request(url_scan_url, data)
            response = urllib2.urlopen(req).read()
            if not response:
                return HttpResponse(json.dumps({"status": "error", "message": "Server busy. Try after some time"}),
                                    content_type="application/json")
            queued_status = json.loads(response)
            scan_report = self.get_scan_report(queued_status['resource'], report_url, config.user_api_key)
        elif scan_type == "ip":
            parameters = {'ip': request.POST.get('value'), 'apikey': config.user_api_key}
            scan_report = urllib.urlopen('%s?%s' % (report_url, urllib.urlencode(parameters))).read()
        scan_report = json.loads(scan_report)
        try:
            utc_scan_date = datetime.strptime(scan_report['scan_date'], '%Y-%m-%d %H:%M:%S')
            local_time = pytz.timezone("UTC").localize(utc_scan_date).astimezone(pytz.timezone(get_timezone(request)))
            scan_report['scan_date'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            pass
        total_count, detected_count = 0, 0
        try:
            for k, v in scan_report["scans"].iteritems():
                for key, value in v.iteritems():
                    if key == "detected":
                        total_count += 1
                        if value:
                            detected_count += 1
                    if key == "update":
                        scan_report["scans"][k][key] = self.get_local_time(value)

            detected = float(detected_count) / total_count * 100
        except:
            detected = None
        return HttpResponse(json.dumps({"scan_report": scan_report, "detected": detected, "status": "success",
                                        "total_count": total_count, "detected_count": detected_count}),
                            content_type="application/json")

    @staticmethod
    def get_scan_report(resource_id, report_url, user_api_key):
        parameters = {"resource": resource_id, "apikey": user_api_key}
        data = urllib.urlencode(parameters)
        report_request = urllib2.Request(report_url, data)
        report_response = urllib2.urlopen(report_request)
        return report_response.read()

    @staticmethod
    def get_report_url(value, config):
        try:
            socket.inet_aton(value)
            return "ip", config.ip_report_url
        except socket.error:
            pass
        if len(value) == 32:
            if re.findall(r"([a-fA-F\d]{32})", value):
                return "hash", config.file_report_url
        elif len(value) == 64:
            if re.findall(r"([a-fA-F\d]{64})", value):
                return "hash", config.file_report_url
        elif len(value) == 128:
            if re.findall(r"([a-fA-F\d]{128})", value):
                return "hash", config.file_report_url
        elif len(value) == 256:
            if re.findall(r"([a-fA-F\d]{256})", value):
                return "hash", config.file_report_url
        if validators.url(value):
            url = urlparse(value)
            return "url", config.url_report_url
        return None, False

    def get_local_time(self, time):
        try:
            time = datetime.fromtimestamp(float(time))
            local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(get_timezone(self.request)))
            return local_time.strftime("%Y %b %d %H:%M:%S")
        except:
            return time


class OpswatHashLookUp(View):
    """
    Class for analyzing hash using Opswat metadefender tool
    """

    def post(self, request, *args, **kwargs):
        file_obj = request.FILES.get("file", None)
        if file_obj:
            file_obj = file_obj.read()
            request.POST['value'] = hashlib.md5(file_obj).hexdigest()
        allowed = set(string.ascii_lowercase + string.digits + string.ascii_uppercase)
        if not set(request.POST['value']) <= allowed:
            return HttpResponse(json.dumps({"status": "error", "message": "Invalid Input"}),
                                content_type="application/json")
        try:
            config = OpswatVirusScanConfiguration.objects.get(customer__id=UserProfile.objects.
                                                              get(user=request.user).customer.id)
        except:
            message = "Invalid Opswat configuration"
            return HttpResponse(json.dumps({"status": "error", "message": message}), content_type="application/json")
        headers = {'Accept': 'application/json', 'apikey': config.user_api_key}
        scan_report = requests.get(config.hash_scan_url + request.POST.get("value"), headers=headers).content
        scan_report = json.loads(scan_report)
        try:
            utc_scan_date = datetime.strptime(scan_report['file_info']['upload_timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
            local_time = pytz.timezone("UTC").localize(utc_scan_date).astimezone(pytz.timezone(get_timezone(request)))
            scan_report['file_info']['upload_timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            pass
        total_count, detected_count = 0, 0
        try:
            for k, v in scan_report["scan_results"]["scan_details"].iteritems():
                for key, value in v.iteritems():
                    if key == "scan_result_i":
                        total_count += 1
                        if int(value) > 0:
                            detected_count += 1
                    if key == "def_time":
                        scan_report["scan_results"]["scan_details"][k][key] = self.get_local_time(value)
            detected = float(detected_count)/total_count*100
        except:
            detected = None
        return HttpResponse(json.dumps({"scan_report": scan_report, "detected": detected, "status": "success",
                                        "total_count": total_count, "detected_count": detected_count}),
                            content_type="application/json")

    def get_local_time(self, time):
        try:
            utc_time = datetime.strptime(time, '%Y-%m-%dT%H:%M:%S.%fZ')
            local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(get_timezone(self.request)))
            return local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return time


class VirusTotalPdfScanReport(View):
    """
    Class for generating scan report in pdf format
    """

    def get(self, request, *args, **kwargs):
        config = VirusScanConfiguration.objects.get(customer__id=UserProfile.objects.
                                                    get(user=request.user).customer.id)
        type, report_url = VirusScan.get_report_url(request.GET.get("id"), config)
        scan_report = VirusScan.get_scan_report(request.GET.get("id"), report_url, config.user_api_key)
        scan_report = json.loads(scan_report)
        try:
            utc_scan_date = datetime.strptime(scan_report['scan_date'], '%Y-%m-%d %H:%M:%S')
            local_time = pytz.timezone("UTC").localize(utc_scan_date).astimezone(pytz.timezone(get_timezone(request)))
            scan_report['scan_date'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            pass
        try:
            for k, v in scan_report["scans"].iteritems():
                for key, value in v.iteritems():
                    if key == "update":
                        scan_report["scans"][k][key] = self.get_local_time(value)
        except:
            pass
        output_filename = "media/scan_report.pdf"
        base_dir = settings.BASE_DIR
        utc_now = datetime.now().replace(tzinfo=pytz.timezone('UTC'))
        now = utc_now.astimezone(pytz.timezone(get_timezone(request)))
        context = RequestContext(request, {"scan_report": scan_report, "base_dir": base_dir,
                                           "generated_time": now.strftime("%Y-%m-%d %H:%M:%S")})
        template = get_template('threat_intelligence/scan_report.html')
        html = template.render(context)
        result_file = open(output_filename, "w+b")
        pisa.CreatePDF(html, dest=result_file)
        result_file.close()
        result_file = open(output_filename, "rd")
        response = StreamingHttpResponse(result_file, content_type="html/pdf")
        response['Content-Disposition'] = 'attachment; filename="scan_report.pdf"'
        return response

    def get_local_time(self, time):
        try:
            time = datetime.fromtimestamp(float(time))
            local_time = pytz.timezone("UTC").localize(time).astimezone(pytz.timezone(get_timezone(self.request)))
            return local_time.strftime("%Y %b %d %H:%M:%S")
        except:
            return time


class OpswatPdfScanReport(View):
    """
    Class for generating scan report in pdf format
    """

    def get(self, request, *args, **kwargs):
        config = OpswatVirusScanConfiguration.objects.get(customer__id=UserProfile.objects.
                                                          get(user=request.user).customer.id)
        headers = {'Accept': 'application/json', 'apikey': config.user_api_key}
        scan_report = requests.get(config.hash_scan_url + request.GET.get("id"), headers=headers).content
        scan_report = json.loads(scan_report)
        try:
            utc_scan_date = datetime.strptime(scan_report['file_info']['upload_timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
            local_time = pytz.timezone("UTC").localize(utc_scan_date).astimezone(pytz.timezone(get_timezone(request)))
            scan_report['file_info']['upload_timestamp'] = local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            pass
        try:
            for k, v in scan_report["scan_results"]["scan_details"].iteritems():
                for key, value in v.iteritems():
                    if key == "def_time":
                        scan_report["scan_results"]["scan_details"][k][key] = self.get_local_time(value)
        except:
            pass
        output_filename = "media/scan_report.pdf"
        base_dir = settings.BASE_DIR
        utc_now = datetime.now().replace(tzinfo=pytz.timezone('UTC'))
        now = utc_now.astimezone(pytz.timezone(get_timezone(request)))
        context = RequestContext(request, {"scan_report": scan_report, "base_dir": base_dir,
                                           "generated_time": now.strftime("%Y-%m-%d %H:%M:%S")})
        template = get_template('threat_intelligence/opswat_report.html')
        html = template.render(context)
        result_file = open(output_filename, "w+b")
        pisa.CreatePDF(html, dest=result_file)
        result_file.close()
        result_file = open(output_filename, "rd")
        response = StreamingHttpResponse(result_file, content_type="html/pdf")
        response['Content-Disposition'] = 'attachment; filename="scan_report.pdf"'
        return response

    def get_local_time(self, time):
        try:
            utc_time = datetime.strptime(time, '%Y-%m-%dT%H:%M:%S.%fZ')
            local_time = pytz.timezone("UTC").localize(utc_time).astimezone(pytz.timezone(get_timezone(self.request)))
            return local_time.strftime("%Y-%m-%d %H:%M:%S")
        except:
            return time
