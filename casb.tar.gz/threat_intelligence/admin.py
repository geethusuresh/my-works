from django.contrib import admin

from threat_intelligence.models import *

admin.site.register(IpIntelligenceConfiguration)
admin.site.register(VirusScanConfiguration)
admin.site.register(OpswatVirusScanConfiguration)
