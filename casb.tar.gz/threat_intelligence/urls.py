from django.conf.urls import url
from django.contrib.auth.decorators import login_required

from threat_intelligence.views import IpIntelligence, VirusScan, OpswatHashLookUp, IbmPdfReport, \
    VirusTotalPdfScanReport, OpswatPdfScanReport


urlpatterns = [
               url(r'^ip_intelligence/$', login_required(IpIntelligence.as_view()), name='ip_intelligence'),
               url(r'^virus_scan/$', login_required(VirusScan.as_view()), name='virus_scan'),
               url(r'^opswat_scan_report/$', login_required(OpswatHashLookUp.as_view()), name='opswat_scan_report'),
               url(r'^ibm_pdf_report/$', login_required(IbmPdfReport.as_view()), name='ibm_pdf_report'),
               url(r'^get_scan_report/$', login_required(VirusTotalPdfScanReport.as_view()), name='get_pdf_report'),
               url(r'^opswat_pdf_report/$', login_required(OpswatPdfScanReport.as_view()), name='opswat_pdf_report'),
              ]
