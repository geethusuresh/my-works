"""casb URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import include, url
from django.conf import settings
from dashboard.views import CasbDashboard
from casb.views import CasbLogin, CasbLogout, CasbHome

from django.contrib import admin

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', CasbDashboard.as_view(), name='CasbDashboard'),
    url(r'^login$', CasbLogin.as_view(), name="CasbLogin"),
    url(r'^logout/$', CasbLogout.as_view(), name='CasbLogout'),
    url(r'^home$', CasbHome.as_view(), name="CasbHome"),
    url(r'^dashboard/', include('dashboard.urls', namespace="dashboard")),
    url(r'^vulnerability/', include('vulnerability.urls', namespace="vulnerability")),
    url(r'^threat_intelligence/', include('threat_intelligence.urls', namespace="threat_intelligence")),
    url(r'^two_factor_auth/', include('two_factor_auth.urls', namespace="two_factor_auth")),
    url(r'^media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.MEDIA_ROOT}),
]

