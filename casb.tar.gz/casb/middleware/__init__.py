import re
import logging

from django import http
from django.core.cache import cache
from django.shortcuts import render, redirect
from django.contrib.auth.models import AnonymousUser


class HandleRequests(object):
    def process_view(self, request, view_func, view_args, view_kwargs):
        if (not request.user.is_authenticated() and ('home' not in request.path) and
                ('login' not in request.path) and ('admin' not in request.path)):
            logging.info('User not logged in. Going to redirect to Login page.')
            return http.HttpResponseRedirect('/home?next=%s' % request.path)
        return None
