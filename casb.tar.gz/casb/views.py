import pytz
from datetime import datetime

from django.shortcuts import render_to_response, render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import RequestContext
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.views.generic import View

from dashboard.models import Customer, UserProfile
from two_factor_auth.models import TwofactorSetup


class CasbLogin(View):

    def get(self, request, *args, **kwargs):
        next_url = request.GET.get('next', '')
        c = RequestContext(request, {"next_url": next_url})
        return render(request, 'home/index.html', context_instance=c)

    def post(self, request, *args, **kwargs):
        username = request.POST.get('username')
        password = request.POST.get("password")
        next_url = request.GET.get('next', '')

        try:
            Customer.objects.get(userprofile__user__username__iexact=username)
        except:
            messages.error(request, "No customer or invalid user")
            return render_to_response("home/index.html", context_instance=RequestContext(request))

        user = User.objects.get(username__iexact=username)
        user_profile = UserProfile.objects.get(user=user)

        if user is not None:
            if user.check_password(password):
                if user_profile.active:
                    ##################################
                    # Checking two factor
                    ###################################
                    twofactor_count = TwofactorSetup.objects.filter(user=user_profile, active=True).count()
                    if twofactor_count > 0:
                        obj_twofactor = TwofactorSetup.objects.get(user=user_profile, active=True)
                        request.session['user_twofactor'] = username
                        return HttpResponseRedirect('/two_factor_auth/login')

                    user.backend = 'django.contrib.auth.backends.ModelBackend'
                    auth.login(request, user)
                    user_profile.lastlogin = datetime.now(tz=pytz.timezone("UTC"))
                    user_profile.save()
                    if next_url:
                        return HttpResponseRedirect(next_url)
                    else:
                        return HttpResponseRedirect('/')
                else:
                    messages.error(request, "Not an active user")
            else:
                messages.error(request, "Invalid Username or Password")
        else:
            messages.error(request, "Check Your Username and password")
        return render_to_response("home/index.html", context_instance=RequestContext(request))


class CasbLogout(View):
    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated():
            logout(request)
        return HttpResponseRedirect('/home')


class CasbHome(View):
    def get(self, request, *args, **kwargs):
        c = RequestContext(request, {})
        return render(request, 'home/index.html', context_instance=c)
