/* $(document).ready(function() {	
var nav = $('.savedash');
if (nav.length) {	
	
var stickyNavTop = nav.offset().top;
 
var stickyNav = function(){
var scrollTop = $(window).scrollTop();
      
if (scrollTop > stickyNavTop) { 
    $('.savedash').addClass('sticky');
} else {
    $('.savedash').removeClass('sticky'); 
}
};
 
stickyNav();
 
$(window).scroll(function() {
  stickyNav();
});
}
});

*/

$(function(){
    $(window).scroll(function() {
        if ($(this).scrollTop() >= 120) {
            $('.savedash').addClass('sticky');
        }
        else {
            $('.savedash').removeClass('sticky');
        }
    });
});