function AlertsController($scope, $http, HttpRequestService, $stateParams, $filter, $state, $rootScope, $controller){
  angular.extend(this,$controller('MessageController', {$scope: $scope}));
	
  $scope.alertdetails = []
	$scope.alertdetails2 = []
	$scope.filteredalertdetails = []
	$scope.check_list = []
	$scope.create_ticket = false
	$scope.selection = []
	$scope.alert_list = {}
	$scope.Items = []
	$scope.tickets = []
  $scope.cutomize_btn_dash = true;
  $scope.restore_btn_dash = true;  

	//pagination variables
  $scope.currentPage = 1
  $scope.numPerPage = 15
  $scope.maxSize = 5;
  $scope.entryLimit = 15;
  $scope.json_id = 0;
  $scope.host_id = '';
  $scope.tab1 = true;
  $scope.tab2 = false;
  //sorting params
  // $scope.sortType     = 'name'; // set the default sort type
	$scope.timestamp  = true;

	$scope.dash_heading = "Alert Dashboard";

  $scope.filter = $stateParams.filter;
  $scope.host_id = $stateParams.host;
  $scope.current_state = $state.current.name;
  $scope.op_status = $stateParams.op_status;
  $scope.operation = $stateParams.op;

  $scope.filter_heading = "Alerts";
    
  if($scope.filter && $scope.filter != 'date_range'){
    $scope.duration_selected = " Last " + filter_names($scope.filter);      
  }
  else if($scope.filter == 'date_range'){        
    $scope.duration_selected = "( " + $rootScope.custome_date.replace(" - "," to ") + " )"       
  }
  else{
    $scope.duration_selected = "Last 24 hours";
  }

  $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

  if($scope.op_status == "success"){       
    $scope.SuccessMessage = "Ticket has been created successfully. Ticket Number is #"+$scope.operation;
    $scope.succss_box = true;        
  }
  else if($scope.op_status == "error"){        
    $scope.ErrorMessage = "Not able to create ticket in Oneconsole";
    $scope.error_box = true;        
  }

  $scope.init = function(){
    params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
    }
    HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
        if(d.status == 'success'){
            $scope.customer_host = d.response.host_item;
            $scope.hostip = d.response.hostip;                                
        }
    });

    HttpRequestService.postRequest("/dashboard/casb_settingsinfo",params).then(function(d) {
        if(d.status == 'success'){
            $scope.oneconsole_api_domain = d.response.api_domain;                                                        
        }
    });    
  }

	$scope.load_table = function(){
		params = {          
        'csrfmiddlewaretoken': $scope.csrf_token,
        'graph_type':"alert_details",
        'duration':$scope.filter,
        'host':$scope.host_id,
        'custome_date': $rootScope.custome_date,
        'optional_filter': angular.toJson($rootScope.filter_details)
        }

        HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
            if(d.status == 'success'){
              $scope.alertdetails = d.response
              //$scope.alertdetails = []
              $scope.alertdetails2 = $scope.alertdetails
            }
            $scope.loading_image1 = true            
        });
	}
	$scope.load_table();

	$scope.checkbox_clicked = function(alert_id,sig,src_ip,src_port,dest_ip,dest_port){
  		// $scope.create_ticket = true;
  		json = {
  			'summary':sig,
  			'desc':'source ip:'+src_ip+' <br />'+'source port:'+src_port+' <br />'+'destination ip:'+dest_ip+' <br />'+'destination port:'+dest_port,
  			'source':'casb',
        'src_ip': src_ip,
        'src_port': src_port,
        'dest_ip': dest_ip,
        'dest_port': dest_port
  		}
		  var idx = $scope.selection.indexOf(alert_id);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	      delete $scope.alert_list[alert_id];
	    }
	    // is newly selected
	    else {
	      $scope.selection.push(alert_id);
	      $scope.alert_list[alert_id] = json        
	    }
	    
	    if($scope.selection.length != 0){
			   $scope.create_ticket = true;
		  }
		  else{
			 $scope.create_ticket = false;	
		  }
	}

	$scope.createTicket = function(){		
		  params = {          
        'csrfmiddlewaretoken': $scope.csrf_token,
        'graph_type':"create_ticket",
        'alertdetails':angular.toJson($scope.alert_list)
      }
      bootbox.confirm("Are you sure. You want to create a ticket for selected alerts?", function(result) { 
          if(result == true){  
              HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                  if(d.status=='success'){
                    if(d.response.status == 'success'){
                        ticket_id = d.response.ticketid              
                        $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"success","op":ticket_id},{reload: true});              
                    }
                    else if(d.response.status == "error"){              
                        $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":""},{reload: true});
                    }
                  }
                  else if(d.status=='error'){
                      $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":""},{reload: true});
                  }          
              });
          }
      }); 
	}

	
	//custom directive datatable 
	$scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {      
      if (!$.fn.DataTable.isDataTable('#ticket_table')) {         
          $('#ticket_table').DataTable({
            "bLengthChange": false,
            "order": [[2, "desc" ]]                        
          }); 
      };
  });

  $scope.$on('nocAlertListFinished', function(nocAlertListFinishedEvent) {      
      if(!$.fn.DataTable.isDataTable('#tbl_alert')){        
          $('#tbl_alert').DataTable({
            "bLengthChange": false                      
          });
      };
  });

    $scope.loadTickets = function(){
    	params = {          
        'csrfmiddlewaretoken': $scope.csrf_token,
        'graph_type':"load_ticket",
        }
        
        HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
            if(d.status == 'success'){
            	  $scope.tickets = d.response.objects
            }            
        });
    }
    $scope.loadTickets();
}