app.directive('onFinishRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ngRepeatFinished');
                });
            }
            
        }
    }
});

app.directive('onFinishDetailsRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ngRepeatListFinished');
                });
            }
        }
    }
});

app.directive('onFinishDetailsRenderGroup', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ngRepeatListFinishedGroup');
                });
            }            
        }
    }
});

app.directive('onFinishSrcRenderGroup', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ngRepeatListFinishedSrc');
                });
            }            
        }
    }
});

app.directive('onFinishDestRenderGroup', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ngRepeatListFinishedDest');
                });
            }            
        }
    }
});

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.directive('passwordConfirm', ['$parse', function ($parse) {
 return {
    restrict: 'A',
    scope: {
      matchTarget: '=',
    },
    require: 'ngModel',
    link: function link(scope, elem, attrs, ctrl) {
      var validator = function (value) {
        ctrl.$setValidity('match', value === scope.matchTarget);
        return value;
      }
 
      ctrl.$parsers.unshift(validator);
      ctrl.$formatters.push(validator);
      
      // This is to force validator when the original password gets changed
      scope.$watch('matchTarget', function(newval, oldval) {
        validator(ctrl.$viewValue);
      });

    }
  };
}]);


//Directive for Noc dashboard alert listing section
app.directive('nocAlertRepeatDirective', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('nocAlertListFinished');
                });
            }
        }
    }
});

//Directive for Intrusion prevention settings page
app.directive('ipsSettingRepeatDirective', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ipsSettingListFinished');
                });
            }
        }
    }
});

//Directive for IP queue for block in prevention setting page
app.directive('ipsBlockWaitingDirective', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ipsBlockWaitingListFinished');
                });
            }
        }
    }
});

//Directive for IP queue for unblock in prevention setting page
app.directive('ipsUnBlockWaitingDirective', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ipsUnblockWaitingListFinished');
                });
            }
        }
    }
});

app.run(function($rootScope,$state) {
    $rootScope.twofactor_info = function(){
        $state.go('two_factor_auth');
    };    
});

app.run(function($rootScope,$state) {
    $rootScope.profile_info = function(){
        $state.go('profile_details');
    };    
});

app.run(function($rootScope) {
    $rootScope.widget_mydash = []; 
});

app.run(function($rootScope,$loading) {
    $rootScope.startLoading = function (name) {
        $loading.start(name);
        $rootScope.spinner_name = name;
    };

    $rootScope.finishLoading = function (name) {
        $loading.finish(name);
    };
});

app.run(function($rootScope,$state){
    $rootScope.cancel_dashboard_changes = function(){
        $state.go($state.current.name,{"op_status":"","op":"","temp_widget":""});
    };
});

app.run(function($rootScope,$state){
    $rootScope.refresh_dash = function(){        
        $state.go($state.current.name,{"op_status":"","op":""},{reload: true});  
    };
});


//    IBM x-force IP scan
app.run(function($rootScope, $state){
    $rootScope.ShowScanPopup = function($event){
        elmt = $event.target;
        var pos = $(elmt).position();
        $(elmt).find('div').css('top', (pos.top)+30 + 'px');
        $(elmt).next().attr("style", "display: block;");
    }
});

app.run(function($rootScope, $state){
    $rootScope.HideScanPopup = function(){
        $(".select-scan-type").attr("style", "display: none;");
    }
});

app.run(function($rootScope, $state, HttpRequestService){
    $rootScope.ipIntelligence = function(ip){
        $rootScope.ip = [];
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),
          'ip': ip,
        }
        HttpRequestService.postRequest("/threat_intelligence/ip_intelligence/", params).then(function(d) {
            if(d.response.status == 'success'){
                $rootScope.ip = d.response;
            }
        });
    }
});

app.run(function($rootScope, $state, HttpRequestService){
    $rootScope.VirusTotalIPScan = function(host, url){
        $rootScope.scan_result = [];
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),
          'value': "http://"+host+url,
        }
        HttpRequestService.postRequest("/threat_intelligence/virus_scan/", params).then(function(d) {
            if(d.response.status == 'success'){
                $rootScope.scan_result = d.response.scan_report;
                $rootScope.detected = d.response.detected;
                $rootScope.total_count = d.response.total_count;
                $rootScope.detected_count = d.response.detected_count;
            }
        });
    }
});

app.run(function($rootScope, $state){
    $rootScope.plot_click_counter = 0;
});


//var ckapp = angular.module("CKEditorExample", ["ngCkeditor"]);
  app.directive('ckEditor', function () {
  return {
    require: '?ngModel',
    link: function (scope, elm, attr, ngModel) {
      var ck = CKEDITOR.replace(elm[0]);
      if (!ngModel) return;
      ck.on('instanceReady', function () {
        ck.setData(ngModel.$viewValue);
      });
      function updateModel() {
        scope.$apply(function () {
          ngModel.$setViewValue(ck.getData());
        });
      }
      ck.on('change', updateModel);
//      ck.on('key', updateModel);
//      ck.on('dataReady', updateModel);

      ngModel.$render = function (value) {
        ck.setData(ngModel.$viewValue);
      };
      ck.on('instanceReady', function() {
        ck.setData(ngModel.$viewValue);
      });
    }
  };
});

app.run(function($rootScope,$state){
    $rootScope.customedateclick = function(){
        $rootScope.custome_date = $("#customdaterange").val();
        $rootScope.custome_date_flag = false
        $rootScope.custome_date_flag1 = false
        if ($rootScope.custome_date == '' || $rootScope.custome_date.split(' - ')[0] == undefined || $rootScope.custome_date.split(' - ')[1] == undefined){
            // bootbox.alert("Enter a valid date range ...");
            $rootScope.custome_date_flag1 = true
        }
        else{
            var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
            var firstDate = new Date($rootScope.custome_date.split(' - ')[0]);
            var secondDate = new Date($rootScope.custome_date.split(' - ')[1]);
            var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
            if ((diffDays + 1) > 30) {
                // bootbox.alert("The date range must be less than 30 days...");
                $rootScope.custome_date_flag = true
            }
            else {
                $state.go($state.current.name,{"filter": 'date_range',"op_status":''},{reload: true});
                $rootScope.custome_date_flag = false
            }
        }
    };
});

// Back button
app.directive('back', ['$window', function($window) {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {
            elem.bind('click', function () {
                $window.history.back();
            });
        }
    };
}]);

//function for tracking state transitions
app.run(function($rootScope,$state){
    $rootScope.$on('$stateChangeSuccess', 
        function(event, toState, toParams, fromState, fromParams){
            $rootScope.filter_init();           
        }
    )
});

//function for optional filter details
app.run(function($rootScope, $state, HttpRequestService){    
    $rootScope.filter_details = [];
    $rootScope.filter_obj = [];
    $rootScope.pin_filter_status = false;
    $rootScope.filter_pin_off = true;
    $rootScope.filter_pin_on = false; 
    $rootScope.filter_id = 0;
    $rootScope.filter_delete_flag = false;

    $rootScope.optional_filter = function(ip,type,op){        
        var existing_flag = false;
        $.each($rootScope.filter_details,function(){
            if(this.ip==ip){
                existing_flag = true;
                bootbox.alert({message:"Selected filter was already applied in this dashboard",
                               className:'bootbox_zindex'});
            }          
        });

        if(existing_flag == false){       
            $rootScope.filter_details.push({"ip":ip,"type":type,"op":op});
            $rootScope.filter_pin_on = true;
            $state.go($state.current.name,{"op_status":"","op":""},{reload: true}); 
        }                 
    };

    $rootScope.filter_remove = function(ipobj){           
        $rootScope.filter_details.splice($rootScope.filter_details.indexOf(ipobj), 1);
        $rootScope.filter_delete_flag = true;
        $state.go($state.current.name,{"op_status":"filter-delete","op":""},{reload: true});                         
    };

    $rootScope.filter_all_remove = function(filter_items){
        var filter_item_id = filter_items.id;
        var filter_data = angular.toJson(filter_items.entry[0]);
        console.log(filter_data);

        var filter_json = angular.toJson($rootScope.filter_details);
        console.log(filter_json);

        var index = filter_json.indexOf(filter_data);
        console.log(index);
        
        if(index!=-1){
            var message = "This filter has already applied to the dashboard. Do you want to remove this filter?";
        }
        else{
            var message = "Do you want to remove this filter?";
        }        

        bootbox.confirm(message, function(result) { 
            if(result == true){           
                params = {
                  'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),          
                  'filter_id':filter_item_id,
                  'action': 'delete'              
                }

                HttpRequestService.postRequest("/dashboard/filters", params).then(function(d) {            
                    if(d.response.status == 'success'){ 
                        if(index!=-1){
                            $rootScope.filter_details = [];
                            $rootScope.filter_delete_flag = false;
                        }                                  
                        $state.go($state.current.name,{"op_status":"filter-remove-success","op":""},{reload: true}); 
                    }
                    else if(d.response.status == 'failed'){
                        $state.go($state.current.name,{"op_status":"filter-remove-failed","op":""},{reload: true});
                    }                                 
                }); 
            }
        });        
    };

    $rootScope.update_filter = function(ip,type,op){
        var existing_flag = false;       
        $.each($rootScope.filter_details,function(){
            if(this.ip==ip && this.type == type && this.op == op){
                existing_flag = true;
                bootbox.alert({message:"Selected filter was already applied in this dashboard",
                               className:'bootbox_zindex'});
            }           
        });
       
        if(existing_flag == false){
            //deleting previous filter value
            var index = $rootScope.filter_details.indexOf($rootScope.load_filter_cont);
            $rootScope.filter_details.splice(index, 1);
            $rootScope.filter_details.push({"ip":ip,"type":type,"op":op});                
            $state.go($state.current.name,{"op_status":"","op":""},{reload: true});               
        }        
    };


    $rootScope.show_filter_modal = function(filter_info){        
        $('#updateFilter').modal('show');
        $rootScope.load_filter_cont = filter_info;
        $rootScope.filter_entry_edit = filter_info.ip;
        $rootScope.filter_type_edit = filter_info.type;
        $rootScope.filter_op_edit = filter_info.op;
    };

    $rootScope.pin_filter = function(op,filter_id){        
        if(op == "of"){           
            $rootScope.filter_pin_off = true;
            $rootScope.filter_pin_on = false;
            $rootScope.pin_filter_status = false;                         
        }        

        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),          
          'filter_id':filter_id,
          'action': 'pin_filter',
          'pin_status': op
        }

        HttpRequestService.postRequest("/dashboard/filters", params).then(function(d) {            
            if(d.response.status == 'success'){ 
                $rootScope.filter_details = [];
                $rootScope.filter_id = 0;               
                $state.go($state.current.name,{"op_status":"pin-off-success","op":""},{reload: true}); 
            }                                 
        });
    };

    $rootScope.filter_save = function(filter_id){ 
        $rootScope.filter_delete_flag = false; 
        $rootScope.filter_loader = true;      
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),
          'filter_item': angular.toJson($rootScope.filter_details),
          'filter_id':filter_id,
          'action': 'add_filter'
        }
        HttpRequestService.postRequest("/dashboard/filters", params).then(function(d) {            
            if(d.response.status == 'success'){
                $rootScope.filter_obj = d.response.filter_info;
                $rootScope.filter_id = d.response.filter_id;
                $rootScope.filter_loader = false;
                bootbox.alert({message:"Filter has been successfully saved",
                                   className:'bootbox_zindex'});                                
            }
            else if(d.response.status == 'failed'){
                $rootScope.filter_loader = false;
                bootbox.alert({message:"Not able to save filter details",
                                   className:'bootbox_zindex'});
            }                      
        });
    };

    $rootScope.filter_init = function(){
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),          
          'action': 'filter_initialize'
        }

        HttpRequestService.postRequest("/dashboard/filters", params).then(function(d) {            
            if(d.response.status == 'success'){
                $rootScope.filter_obj = d.response.all_filter; 
                //console.log($rootScope.filter_details);               
                if($rootScope.filter_details.length == 0 && $rootScope.filter_delete_flag == false){                                                            
                   $rootScope.filter_details = d.response.applied_filter.entry;                                     
                    console.log($rootScope.filter_details);
                    console.log("checked root");
                    $rootScope.filter_id = d.response.applied_filter.id;
                    $rootScope.filter_pin_on = true;
                }
            }                                 
        });
    };

    $rootScope.apply_filter = function(filter_item){
        $rootScope.filter_delete_flag = false;
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),          
          'action': 'apply_filter',
          'filter_id': filter_item.id
        }

        HttpRequestService.postRequest("/dashboard/filters", params).then(function(d) {            
            if(d.response.status == 'success'){
                $rootScope.filter_details = [];
                $state.go($state.current.name,{"op_status":"filter-apply-success","op":""},{reload: true});                
            }
            else if(d.response.status == 'failed'){
                $state.go($state.current.name,{"op_status":"filter-apply-failed","op":""},{reload: true});
            }                                 
        });
    };

});

//function for watchlist
app.run(function($rootScope, $state, HttpRequestService){
    $rootScope.show_watch_notification = false;
    $rootScope.add_watchlist = function(entry,type){
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),
          'watch_item': angular.toJson({"entry":entry,"type":type}),
          'action': 'add_watch'
        }
        HttpRequestService.postRequest("/dashboard/watchlist", params).then(function(d) {            
            if(d.response.status == 'success'){
                $state.go($state.current.name,{"op_status":"watch-success","op":""},{reload: true});                               
            }
            else if(d.response.status == 'failed'){
                $state.go($state.current.name,{"op_status":"watch-failed","op":""},{reload: true}); 
            }
            else if(d.response.status == 'exists'){
                $state.go($state.current.name,{"op_status":"watch-exists","op":""},{reload: true}); 
            }            
        });                  
    };

    $rootScope.get_watchlist = function(){
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),          
          'action': 'get_watch'
        }
        HttpRequestService.postRequest("/dashboard/watchlist", params).then(function(d) {
            if(d.status == 'success'){
                $rootScope.watch_info = d.response;
                if($rootScope.watch_info.global_watch_flag == true){
                   $rootScope.show_watch_notification = true; 
                }               
            }
        });
    };

    $rootScope.watch_noti_hide = function(){
        $rootScope.show_watch_notification = false;
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),          
          'action': 'noti_hide'
        }
        HttpRequestService.postRequest("/dashboard/watchlist", params).then(function(d) {
            if(d.response.status == 'success'){
                console.log("successfully cleared notification");
            }
            else if(d.response.status == 'failed'){
                console.log("Not able to clear notification");
            }
        });        
    };

    $rootScope.watch_entry_delete = function(entry_id){        
        params = {
          'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val(),
          'entry_id': entry_id,
          'action': 'delete_entry'
        }

        HttpRequestService.postRequest("/dashboard/watchlist", params).then(function(d) {
            if(d.response.status == 'success'){
                $state.go($state.current.name,{"op_status":"wat_del_success","op":""},{reload: true}); 
            }
            else if(d.response.status == 'failed'){
                $state.go($state.current.name,{"op_status":"wat_del_failed","op":""},{reload: true}); 
            }
        }); 
    }

    setInterval(function(){
        $rootScope.get_watchlist();
    },10000);

});

// Auto refresh dashboards
app.run(function($rootScope,$state, $http, $window){

    $rootScope.autoRefreshDashboard = function(){
        $http.get("/dashboard/state_reload_time/").then(function(response) {
            if (response.data.auto_refresh){
                setTimeout(function(){
                    $window.location.reload();
                },response.data.refresh_interval);
                }
        });
    };
});


//Tab click for events grouping
app.run(function($rootScope,$state, $http){
    $rootScope.tab_click = function(tab_content,tab_menu,tab_menu_parent,tab_content_parent){
        $('.'+tab_menu_parent+' '+'li').each(function(){
            $(this).removeClass('active');
        });
        $('#'+tab_menu).addClass('active');

        $('.'+tab_content_parent+' '+'.tab-pane').each(function(){
            $(this).removeClass('in active');
        });
        $('#'+tab_content).addClass('in active');
    };    
});
