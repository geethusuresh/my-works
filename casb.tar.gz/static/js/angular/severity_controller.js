function SeverityConfigController($scope, $http, $state, $stateParams, HttpRequestService){

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.severity = []

    $scope.Severity = function(){
        $http.get("/dashboard/severity").then(function(response) {
            if (response.data.error){$scope.severity = [];}
            else{ $scope.severity = response.data; }
            });
    }

    $scope.Customer = function(){
        $http.get("/dashboard/customer").then(function(response) {
                $scope.customer = response.data;
                if (!$stateParams.id){ $scope.severity.customer = response.data[0].pk;}
            });
    }

    $scope.SeverityDetails = function(){
        if ($stateParams.id){
            $http.get("/dashboard/severity?id="+$stateParams.id).then(function(response) {
                    $scope.severity = response.data[0].fields;
                    $scope.severity_id = response.data[0].pk;
                });
        }
        else { $scope.add = true }
    }


    $scope.SeverityUpdate = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.severity.severity_number){
            $('#severity_number').attr('style', 'display: inline-block');
        }
        if (!$scope.severity.priority){
            $('#severity_priority').attr('style', 'display: inline-block');
        }
        if (!$scope.severity.severity_number || !$scope.severity.priority){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': $stateParams.id,
          'customer': $scope.severity.customer,
          'severity_number': $scope.severity.severity_number,
          'priority': $scope.severity.priority,
        }
        HttpRequestService.postRequest("/dashboard/severity", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Severity successfully updated", type: "success"},
                function(){ $('#severity-cancel').click() });
            }
        });
    }

    $scope.SeverityDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/dashboard/delete_severity/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Severity successfully deleted", type: "success"},
                function(){ $state.go('severity', {}, {reload: true}); });
            }
        });
    }

}


