function HttpExtendedController($scope, $http) {
  //$scope.heading = 'HTTP EXTENDED CUSTOM';
  $('#title_header').html("HTTP Extended Custom Dashboard");
  $scope.myDataSource = {};
  $scope.http_urls = {};
  $scope.http_hostnames = {};
  $scope.http_content_types = {};
  $scope.http_user_agent = {};
  $scope.http_accept_encoding = {};
  $scope.piechart_http_xff = {};
  $scope.piechart_http_length = {};
  $scope.piechart_http_method = {};
  $scope.http_status_code = {};
  $scope.flow_tcp_state = {};
  $scope.flow_tcp_flags = {};
  $scope.flow_tcp_flags_client = {};
  $scope.flow_tcp_flags_server = {};
  $scope.documents = {};
  
  $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();


  //function for graph
  $scope.initGraph = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"events_graph"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      // console.log("dataset",response.data.category);
        // this callback will be called asynchronously
        // when the response is available
     $scope.myDataSource = {
          "chart": {
              "caption": "TIME CHART",
              "subCaption": "",
              "numberPrefix": "",
              "theme": "zune",
              "yAxisName": "Events Count",
              // "labelStep":"10",
              "showValues": "0",
              "labelDisplay": "rotate",
              "slantLabels":"1"
          },
          "data": response.data.dataset
      }
    
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpURL = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_url"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      $scope.http_urls = response.data.data
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpHostname = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_hostname"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      $scope.http_hostnames = response.data.data
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpContentType = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_content_type"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      $scope.http_content_types = response.data.data
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpContentType();
  $scope.httpHostname();
  $scope.httpURL();

  $scope.httpUserAgent = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_user_agent"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      $scope.http_user_agent = response.data.data
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpAcceptEncoding = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_accept_encoding"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      $scope.http_accept_encoding = response.data.data
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }


  //pichart configuration
  var pie_conf = {
                    caption: "Age profile of website visitors",
                    subcaption: "Last Year",
                    startingangle: "120",
                    // showlabels: "0",
                    showlegend: "1",
                    enablemultislicing: "0",
                    slicingdistance: "15",
                    showpercentvalues: "1",
                    showpercentintooltip: "0",
                    theme: "fint",
                    plottooltext: "$label : $value",
                    "showLabels":"1",
                    "showValues":"1"

                }
  //pie charts
  $scope.httpXFF = function(){
    console.log("bytes")
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_xff"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      var data_list = response.data.data_list
      $scope.piechart_http_xff = {
                          "chart": pie_conf,
                          "data": data_list
                      }
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpMethod = function(){
    console.log("bytes")
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_method"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      var data_list = response.data.data_list
      $scope.piechart_http_method = {
                          "chart": pie_conf,
                          "data": data_list
                      }
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpLength = function(){
    console.log("bytes")
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_length"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      var data_list = response.data.data_list
      $scope.piechart_http_length = {
                          "chart": pie_conf,
                          "data": data_list
                      }
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpStatusCode = function(){
    console.log("bytes")
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_status_code"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      $scope.http_status_code = response.data.data
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpDocuments = function(){
    console.log("bytes")
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"http_documents"
    }
    $http({
      method: 'post',
      data: $.param(params),
      url: '/dashboard/http_extended_dash',
      headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
    }).then(function successCallback(response) {
      $scope.documents = response.data.data
        // this callback will be called asynchronously
        // when the response is available
     
                      
      }, function errorCallback(response) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  }

  $scope.httpUserAgent();
  $scope.httpAcceptEncoding();
  $scope.httpXFF();
  $scope.httpMethod();
  $scope.httpLength();
  $scope.httpStatusCode();
  $scope.httpDocuments();

}
