function InfraController($scope,$http,$state,$stateParams,HttpRequestService,$rootScope){
    $scope.AlertEventSource = {}
    $scope.AlertSignatures = {}
    $scope.AlertSiverity = []
    $scope.alertcategories = {}
    $scope.alertdetails = []
    $scope.alerttrend = {}
    $scope.alertworld = {}
    $scope.alertusa = {}
    $scope.loading_image1 = false
    $scope.loading_image2 = false
    $scope.loading_image3 = false
    $scope.loading_image4 = false
    $scope.loading_image5 = false
    $scope.loading_image6 = false
    $scope.loading_image7 = false
    $scope.loading_image8 = false
    $scope.todos = []
    //pagination variables
    $scope.filteredalertdetails = []
    $scope.currentPage = 1
    $scope.numPerPage = 10
    $scope.maxSize = 5;
    $scope.entryLimit = 10;    

    $scope.dash_heading = "Infra Map";
    $scope.customize_dash_area = true;
    $scope.host_filter_area = true;    

    $scope.filter = $stateParams.filter;
    $scope.host_id = $stateParams.host;
    $scope.current_state = $state.current.name;
    $scope.filter_heading = "Duration";    
    
    if($scope.filter && $scope.filter != 'date_range'){
      $scope.duration_selected = " Last " + filter_names($scope.filter);      
    }
    else if($scope.filter == 'date_range'){        
      $scope.duration_selected = "( " + ($rootScope.custome_date).replace(" - "," to ") + " )"      
    }
    else{
      $scope.duration_selected = "Last 24 hours";
    }

    $scope.host_filter_hidden = true;

    $scope.init = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
        }
        HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
            if(d.status == 'success'){
                $scope.customer_host = d.response.host_item;
                $scope.hostip = d.response.hostip; 
            }
        });
    }

    function setevents(scope_variable,to_hide){
      $scope[scope_variable] = {
                          renderComplete:function(evnt,data) {
                              $scope.$apply(function() {
                                  $scope[to_hide] = true;
                              });
                          }
                      }
    }

    $scope.infra_details = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id,
          'duration':$scope.filter,
          'custome_date': $rootScope.custome_date                   
        }
        HttpRequestService.postRequest("/dashboard/infra_details",params).then(function(d) {
            if(d.status == 'success'){
                var treeData = d.response;
                root = treeData[0];
                root.x0 = height / 2;
                root.y0 = 0;

                update(root);
                d3.select(self.frameElement).style("height", "800px");
            }
        });
    }
    $scope.infra_details();
}