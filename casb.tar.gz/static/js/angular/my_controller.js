function MyController($scope,$http,$state,$stateParams,HttpRequestService,$filter,$log,$location,$controller,$rootScope){
    angular.extend(this,$controller('IntrusionController', {$scope: $scope}));
    angular.extend(this,$controller('HttpController', {$scope: $scope}));
    angular.extend(this,$controller('SSHController', {$scope: $scope}));
    angular.extend(this,$controller('TLSController', {$scope: $scope}));
    angular.extend(this,$controller('PrivacyController', {$scope: $scope}));
    angular.extend(this,$controller('QueryController', {$scope: $scope}));
    angular.extend(this,$controller('FlowController', {$scope: $scope})); 
    angular.extend(this,$controller('MessageController', {$scope: $scope}));        

    $scope.dash_heading = "Custom Analytics Dashboard"; 

    $scope.customize_btn_flag = true;
    $scope.savedash_btn_flag = false;
    $scope.restore_btn_dash = true;
    $scope.delete_item_flag = false;
    $scope.realtime_btn = true;
    $scope.SelectGraph = "";
    $scope.SelectDashboard = "";

    $scope.filter = $stateParams.filter;
    $scope.operation = $stateParams.op;
    $scope.op_status = $stateParams.op_status;
    $scope.host_id = $stateParams.host;
    $scope.temp_widget = $stateParams.temp_widget;
    $scope.current_state = $state.current.name;

    $scope.filter_heading = "Duration";

    if($scope.operation=="drag"){        
        $scope.widget_move = "true";        
        $scope.savedash_btn_flag = true;
        $scope.delete_item_flag = true;
        $scope.realtime_btn = false; 
    }
    else{
      $scope.widget_move = "false";
    }    
    
    if($scope.filter && $scope.filter != 'date_range'){
      $scope.duration_selected = " Last " + filter_names($scope.filter);      
    }
    else if($scope.filter == 'date_range'){        
      $scope.duration_selected = "( " + $rootScope.custome_date.replace(" - "," to ") + " )"       
    }
    else{
      $scope.duration_selected = "Last 24 hours";
    }
    
    //Code for Drag and Drop
    $scope.options = {
        cellHeight: 75,
        verticalMargin: 5
    };

    $scope.widgets = []
    $scope.widgets_preview = []      

    $scope.addWidget = function(newWidget) {        
        $scope.widgets.push(newWidget);
    };

    $scope.removeWidget = function(w) {
        bootbox.confirm("Are you sure. You want to delete this graph?", function(result) {            
            if(result == true){
                $scope.$apply(function() {                    
                    $scope.savedash_btn_flag = true;
                    var index = $scope.widgets.indexOf(w);
                    $scope.widgets.splice(index, 1);
                    $rootScope.widget_mydash = $scope.widgets;
                    $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"temp_widget":"yes","op":"drag","op_status":""}); 
                });
            }
        });
    };

    $scope.onChange = function(event, items) {
        $log.log("onChange Start: "+items); 
    };

    $scope.onDragStart = function(event, ui) {
        $log.log("onDrag Start: "+ui);
    };

    $scope.onDragStop = function(event, ui) {        
        $log.log("onDragStop event: "+event+" ui:"+ui);        
        $scope.savedash_btn_flag = true;
    };

    $scope.onResizeStart = function(event, ui) {
        $log.log("onResize Start: "+ui);
    };

    $scope.onResizeStop = function(event, ui) {
       $log.log("onResizeStop item: "+ui);       
       $scope.savedash_btn_flag = true;
    };

    $scope.onItemAdded = function(item) {
        $log.log("onItemAdded item: "+item);
    };

    $scope.onItemRemoved = function(item) {
        $log.log("onItemRemoved item: "+item);
    };  
    //End Drag and Drop Code

    $scope.save_dashboard_changes = function(){
        $('#btn_save_dash').addClass('loadicon');
        $('#btn_save_dash').removeClass('saveicon');
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();        
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type':"Mydash",
          'widgets':angular.toJson($scope.widgets)
        }
        HttpRequestService.postRequest("/dashboard/save_dashboard",params).then(function(d) {
            if(d.status == 'success'){
                if(d.response.status == "success"){                                               
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"success","op":"","temp_widget":""});
                }
                else{
                    $scope.ErrorMessage = "Unable to save dashboard changes";
                    $scope.error_box = true;
                }
            }
            else if(d.status == "error"){                            
              $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":"drag","temp_widget":"yes"});
            }            
            $('#btn_save_dash').addClass('saveicon');
            $('#btn_save_dash').removeClass('loadicon');
            $scope.savedash_btn_flag = false;
        });
    }    


    $scope.restore_dashboard = function(){
        $('#btn_restore').button("loading");
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type':"Alert"          
        }
        HttpRequestService.postRequest("/dashboard/restore_dashboard",params).then(function(d) {
            if(d.status == 'success'){
                if(d.response.status == 'success'){                                               
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"restored","op":""});
                }
                else{
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
                }
            }
            else if(d.status == "error"){                           
              $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
            }
            $('#btn_restore').button('reset');
            //$('#btn_restore').hide();
            $scope.savedash_btn_flag = false;
        });
    }

    $scope.init = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        loading_overlay("show");

        if($scope.temp_widget == "yes"){
            loading_overlay("hide");
            $scope.widgets = $rootScope.widget_mydash; 
            //$('#btn_save_dash').show();
            $scope.savedash_btn_flag = true;
            $scope.delete_item_flag = true;
        }
        else{
          params = {          
              'csrfmiddlewaretoken': $scope.csrf_token,
              'dash_type': "Mydash"                   
            }                        
          HttpRequestService.postRequest("/dashboard/widget_details",params).then(function(d) {
              if(d.status == 'success'){                            
                $scope.widgets = d.response;
                if($scope.widgets.length==0){
                    $scope.empty_dash = true;
                }
                else{            
                    $scope.empty_dash = false;
                }                                                              
                loading_overlay("hide");              
              }
              else if(d.status == 'error'){
                  loading_overlay("hide");                  
                  $scope.empty_dash = true;                               
              }
          });
        }

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
        }
        HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
            if(d.status == 'success'){
                $scope.customer_host = d.response.host_item;
                $scope.hostip = d.response.hostip;                                
            }
        });

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token                             
        }
        HttpRequestService.postRequest("/dashboard/dash_details",params).then(function(d) {
            if(d.status == 'success'){
                var dash_select = $('#dashboard');
                $.each(d.response.dash_info,function(){
                    dash_select.append($('<option />').val(this.dashboard).text(this.display_name));
                });                                          
            }
        });
    }

    $scope.customize_dash = function(){
        $('#btn_customize').button("loading");
        $('#demo-set').removeClass("open");
        $('#graph_modal').modal("show");
        $('#btn_customize').button("reset");
    }

    $scope.getting_grah_info = function(){
        $('#error_dashsel').hide();
        $scope.SelectGraph = "";        
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dashboard_info':$scope.SelectDashboard                            
        }
        $scope.loading_image = true;
        HttpRequestService.postRequest("/dashboard/dash_graph_info",params).then(function(d) {
            if(d.status == 'success'){
                //saving widget details for future reference
                $scope.widget_graph = d.response;
                $scope.graph_info = true;
                $scope.loading_image = false;
                $('#graph_info').empty();
                var graph_select = $('#graph_info');
                graph_select.append($('<option />').val('').text(''));                
                var count = 0;                
                $.each(d.response,function(){
                    graph_select.append($('<option />').val(count).text(this.graph));
                    count = count + 1;
                });                                       
            }
        });
    }

    $scope.add_to_dashboard = function(){
        if($scope.SelectDashboard=="" || $scope.SelectDashboard==undefined){
            $('#error_dashsel').html("Please select one dashboard");
            $('#error_dashsel').show(); 
        }
        else if($scope.SelectGraph=="" || $scope.SelectGraph==undefined){
            $('#error_dashsel').html("Please select one graph");
            $('#error_dashsel').show(); 
        }
        else{
            var selected_grph_obj = $scope.widget_graph[$scope.SelectGraph];
            var existing_flag = false;
            $.each($scope.widgets,function(){
                if(this.info==selected_grph_obj.info){
                    existing_flag = true;
                    $('#error_dashsel').html("Graph is already exists in this dashboard");
                    $('#error_dashsel').show();
                }          
            });

            if(existing_flag == false){
                $('#error_dashsel').hide();
                $('#btn_add_graph').button("loading");
                $scope.addWidget($scope.widget_graph[$scope.SelectGraph]);        
                $('#btn_add_graph').button("reset");
                $scope.empty_dash = false;
                $('#graph_modal').modal("hide");
                $rootScope.widget_mydash = $scope.widgets;
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"temp_widget":"yes","op":"drag","op_status":""});
            }
        }                       
    }

    $scope.graph_preview_details = function(){                
        if($scope.SelectGraph!= "" && $scope.SelectGraph!=undefined){
            $('#error_dashsel').hide(); 
            $('#btn_preview_graph').button("loading");
            $scope.widgets_preview = []        
            $scope.widgets_preview.push($scope.widget_graph[$scope.SelectGraph]);                                
            $('#preview_modal').modal("show");
            $('#btn_preview_graph').button("reset");
        }
        else{
            $('#error_dashsel').html("Please select one graph");
            $('#error_dashsel').show(); 
        }
    }

    function setevents(scope_variable,to_hide){
      $scope[scope_variable] = {
                          renderComplete:function(evnt,data) {
                              $scope.$apply(function() {
                                  $scope[to_hide] = true;
                              });
                          }
                      }
    }

}