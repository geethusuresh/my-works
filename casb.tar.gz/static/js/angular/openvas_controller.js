function OpenvasController($scope, $http, $state, $stateParams, HttpRequestService){

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.openvas = []
    $scope.allScan = false;
    $scope.myScan = false;
    $scope.newScan = false;
    $scope.openvas_edit_scan = false;
    $scope.openvas_scan = []

    $scope.OpenvasScanList = function(scan_type){
        $scope.openvas_loading = true
        $scope.openvas_scan = false
        $scope.scheduledScan = false;
        $scope.openvas_new_scan = false
        $scope.allScan = false;
        $scope.myScan = false;
        $scope.newScan = false;
        $scope.scanEdit = true;
        $scope.openvas_scan_lists = true
        $('#conf_error').attr('style', 'display: none');
        $('#no_data').attr('style', 'display: table-row');
        if ($stateParams.id){ $scope.openvas_scan_id = $stateParams.id
            url = "/vulnerability/openvas_scan?scan_id="+$stateParams.id
        }else if(scan_type == "all"){
            url = "/vulnerability/openvas_scan?type=all"
            $scope.allScan = true;
            $scope.scanEdit = false;
        }else{
            url = "/vulnerability/openvas_scan/"
            $scope.myScan = true;
        }
        $http.get(url).then(function(response) {
                if (response.data.status == 'error'){
                    $('#openvas_error').html(response.data.message);
                    $('#conf_error').attr('style', 'display: table-row');
                    $('#no_data').attr('style', 'display: none');
                    $scope.openvas_loading = false;
                    return false;
                }
                if (!$scope.openvas_new_scan && !$scope.scheduledScan){$scope.openvas_scan = response.data; $scope.openvas_loading = false}
                if ($stateParams.id){
                    $scope.openvas_scan_result = response.data.get_reports_response.report.report.results.result;
                    $scope.openvas_scan_hosts = response.data.get_reports_response.report.report.host_start;
                    $scope.openvas_scan_hosts_count = response.data.get_reports_response.report.report.hosts.count.$;
                }
            });
    }


    $scope.OpenvasGetStatus = function(scan_id){
        $http.get("/vulnerability/openvas/get-status/?scan_id="+scan_id).then(function(response) {
                for (i=0; i<$scope.openvas_scan.length; i++){
                    if ($scope.openvas_scan[i].id == response.data.scan_id)
                    { $scope.openvas_scan[i].status = response.data.scan_status }
                }
            });
    }


    $scope.OpenvasScan = function(){
        $('.scan-error-msg').attr('style', 'display: none')
        if (!$scope.name){
            $('#scan_name_error').attr('style', 'display: block');
        }
        if (!$scope.schedule_type){
            $('#schedule_type_error').attr('style', 'display: block');
        }
        if (!$scope.target){
            $('#target_error').attr('style', 'display: block');
        }
        if ($scope.target){
            var ip_array = $scope.target.split(",");
            for (var i = 0; i < ip_array.length; i++) {
                if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ip_array[i])){
                    // pass
                }else{
                    $('#ip_error').attr('style', 'display: block'); return false;
                }
            }
        }
        if ($scope.schedule_type == "once" && !$('#datetimepicker').val()){
            $('#schedule_date_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "daily" && !$('#timepicker').val()){
            $('#schedule_time_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "weekly" && !$scope.schedule_day){
            $('#schedule_day_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "weekly" && !$('#timepicker').val()){
            $('#schedule_time_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "monthly" && !$('#daypicker').val()){
            $('#schedule_day_of_the_month_error').attr('style', 'display: block'); return false;
        }
        if (!$scope.name || !$scope.schedule_type || !$scope.target){
            return false;
        }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'name': $scope.name,
          'target': $scope.target,
          'schedule_type': $scope.schedule_type,
          'schedule_day': $scope.schedule_day,
          'schedule_date': $('#datetimepicker').val(),
          'schedule_day_of_the_month': $('#daypicker').val(),
          'schedule_time': $('#timepicker').val(),
        }
        if ($scope.openvas_edit_scan==true){
            params['scan_id'] = $scope.openvas_edit_scan_id
        }
        HttpRequestService.postRequest("/vulnerability/openvas_scan/", params).then(function(response) {
            if (response.response.status == 'error'){
                swal({title: "Error", text: response.response.message, type: "error"});
            }
            else{
                swal({title: "Success", text: "Scan details submitted successfully", type: "success"},
                function(){ $('#my_schedules').click(); });
            }
        });
    }

     $scope.OpenvasScheduledScans = function(type){
        $scope.openvas_new_scan = false;
        $scope.openvas_scan_lists = false;
        $scope.scheduledScan = true;
        if (type=='all'){
            url = "/vulnerability/openvas_scheduled_scans?type=all"
            $scope.scheduledScanEdit = false;
        }else{
            $scope.scheduledScanEdit = true;
            url = "/vulnerability/openvas_scheduled_scans"
        }
        $http.get(url).then(function(response) {
                if (!$scope.openvas_scan_lists){ $scope.openvas_schedules = response.data; }
            });
    }

    $scope.OpenvasScheduleEdit = function(schedule){
        $('#schedule_day_of_month').attr('style', 'display: none');
        $('#schedule_date').attr('style', 'display: none');
        $('#schedule_time').attr('style', 'display: none');
        $('#schedule_day').attr('style', 'display: none');
        $scope.scheduledScan = false;
        $scope.openvas_new_scan = true;
        $scope.openvas_edit_scan = true;
        $scope.openvas_edit_scan_id = schedule.pk
        $scope.name = schedule.fields.name
        $scope.target = schedule.fields.target
        $scope.schedule_type = schedule.fields.type
        $scope.schedule_day = schedule.fields.day
        $scope.schedule_date = schedule.fields.date_time
        $scope.schedule_day_of_the_month = schedule.fields.day_of_the_month+" "+schedule.fields.time
        $scope.schedule_time = schedule.fields.time
        if ($scope.schedule_type == 'once'){ $('#schedule_date').attr('style', 'display: block'); }
        else if ($scope.schedule_type == 'monthly'){ $('#schedule_day_of_month').attr('style', 'display: block'); }
        if ($scope.schedule_type == 'daily'){ $('#schedule_time').attr('style', 'display: block'); }
        if ($scope.schedule_type == 'weekly'){ $('#schedule_time').attr('style', 'display: block');
                                               $('#schedule_day').attr('style', 'display: block'); }
    }

    $scope.OpenvasNewScan = function(schedule){
        $('#schedule_day_of_month').attr('style', 'display: none');
        $('#schedule_date').attr('style', 'display: none');
        $('#schedule_time').attr('style', 'display: none');
        $('#schedule_day').attr('style', 'display: none');
        $scope.scheduledScan = false;
        $scope.openvas_new_scan = true;
        $scope.openvas_scan_lists = false;
        $scope.openvas_edit_scan = false;
        $scope.name = '';
        $scope.target = '';
        $scope.schedule_type = '';

    }

    $scope.OpenvasScanDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        swal({
          title: "Are you sure?",
          text: "You will not be able to recover this item!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Yes, delete it!",
          closeOnConfirm: false
        },
        function(){
            HttpRequestService.postRequest("/vulnerability/openvas_delete_scan/", params).then(function(response) {
                    if(response.status == 'success'){
                        swal({title: "Success", text: "Openvas schedule successfully deleted", type: "success"},
                        function(){ $state.go('openvas', {}, {reload: true}); });
                    }
                });
        });
    }

    $scope.OpenvasScheduleDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        swal({
          title: "Are you sure?",
          text: "You will not be able to recover this item!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Yes, delete it!",
          closeOnConfirm: false
        },
        function(){
            HttpRequestService.postRequest("/vulnerability/openvas_delete_schedule/", params).then(function(response) {
                    if(response.status == 'success'){
                        swal({title: "Success", text: "Openvas schedule successfully deleted", type: "success"},
                        function(){ $('#my_schedules').click(); });
                    }
                });
        });
    }


    // Openvas Config ################################
    $scope.openvas_conf = []

    $scope.OpenvasConf = function(){
        $http.get("/vulnerability/openvas_conf/").then(function(response) {
            if (response.data.error){$scope.openvas_conf = [];}
            else{ $scope.openvas_conf = response.data; }
            });
    }

    $scope.Customer = function(){
        $http.get("/dashboard/customer").then(function(response) {
                $scope.customer = response.data;
                if (!$stateParams.id){ $scope.openvas_conf.customer = response.data[0].pk;}
            });
    }

    $scope.OpenvasConfDetails = function(){
        if ($stateParams.id){
            $http.get("/vulnerability/openvas_conf?id="+$stateParams.id).then(function(response) {
                    $scope.openvas_conf = response.data[0].fields;
                    $scope.openvas_conf_id = response.data[0].pk;
                });
        }
        else { $scope.add = true }
    }


    $scope.OpenvasConfUpdate = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.openvas_conf.username){
            $('#username_error').attr('style', 'display: inline-block');
        }
        if (!$scope.openvas_conf.password){
            $('#password_error').attr('style', 'display: inline-block');
        }
        if (!$scope.openvas_conf.openvas_server_url){
            $('#server_error').attr('style', 'display: inline-block');
        }
        if (!$scope.openvas_conf.port){
            $('#port_error').attr('style', 'display: inline-block');
        }
        if (!$scope.openvas_conf.username || !$scope.openvas_conf.password || !$scope.openvas_conf.openvas_server_url || !$scope.openvas_conf.port){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': $stateParams.id,
          'customer': $scope.openvas_conf.customer,
          'username': $scope.openvas_conf.username,
          'password': $scope.openvas_conf.password,
          'server_url': $scope.openvas_conf.openvas_server_url,
          'port': $scope.openvas_conf.port,
        }
        HttpRequestService.postRequest("/vulnerability/openvas_conf/", params).then(function(response) {
            if(response.response.status == 'success'){
                swal({title: "Success", text: "Openvas configuration successfully updated", type: "success"},
                function(){ $('#openvas-cancel').click() });
            }else{ swal("Error!", response.response.message, "error"); }
        });
    }

    $scope.OpenvasConfDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/vulnerability/openvas_conf_delete/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Openvas configuration successfully deleted", type: "success"},
                function(){ $state.go('openvas_config', {}, {reload: true}); });
            }
        });
    }

}
