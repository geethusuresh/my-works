function FlowController($scope, $http, HttpRequestService, $stateParams, $state, $filter,$log,$location, $modal, TEMPLATE_URL, $rootScope, $controller) {
  angular.extend(this,$controller('MessageController', {$scope: $scope}));

  $scope.dash_heading ="Network Analytics Dashboard";
  $scope.myDataSource = {};
  $scope.flow_destinations_ports = {};
  $scope.flow_source_ports = {};
  $scope.flow_destination_ip = {};
  $scope.flow_source_ip = {};
  $scope.piechart_bytes_client = {};
  $scope.piechart_bytes_server = {};
  $scope.piechart_bytes_client = {};
  $scope.piechart_packets_client = {};
  $scope.piechart_packets_server = {};
  $scope.flow_tcp_state = {};
  $scope.flow_tcp_flags = {};
  $scope.flow_tcp_flags_client = {};
  $scope.flow_tcp_flags_server = {};
  $scope.documents = [];  
  $scope.savedash_btn_flag = false;
  
  $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
  $scope.graph_theme = $('#graph_theme').val();

  $scope.filter = $stateParams.filter;
  $scope.operation = $stateParams.op;
  $scope.op_status = $stateParams.op_status;
  $scope.host_id = $stateParams.host;
  $scope.current_state = $state.current.name;
  $scope.filter_heading = "Duration"; 

  if($scope.filter && $scope.filter != 'date_range'){
    $scope.duration_selected = " Last " + filter_names($scope.filter);
  }
  else if($scope.filter == 'date_range'){        
    $scope.duration_selected = "( " + $rootScope.custome_date.replace(" - "," to ") + " )"       
  }
  else{
    $scope.duration_selected = "Last 24 Hours";  
  }

  if($scope.operation=="drag"){        
        $scope.widget_move = "true";
  }
  else{
    $scope.widget_move = "false";
  }

  //Code for Drag and Drop
  $scope.options = {
      cellHeight: 75,
      verticalMargin: 5
  };
     

  $scope.addWidget = function() {
      var newWidget = { x:0, y:0, width:1, height:1 };
      $scope.widgets.push(newWidget);
  };

  $scope.removeWidget = function(w) {
      var index = $scope.widgets.indexOf(w);
      $scope.widgets.splice(index, 1);
  };

  $scope.onChange = function(event, items) {
      $log.log("onChange Start: "+items); 
  };

  $scope.onDragStart = function(event, ui) {
      $log.log("onDrag Start: "+ui);
  };

  $scope.onDragStop = function(event, ui) {        
      $log.log("onDragStop event: "+event+" ui:"+ui);
      //$('#btn_save_dash').show();
      $scope.savedash_btn_flag = true;
  };

  $scope.onResizeStart = function(event, ui) {
      $log.log("onResize Start: "+ui);
  };

  $scope.onResizeStop = function(event, ui) {
     $log.log("onResizeStop item: "+ui);
     //$('#btn_save_dash').show();
     $scope.savedash_btn_flag = true;
  };

  $scope.onItemAdded = function(item) {
      $log.log("onItemAdded item: "+item);
  };

  $scope.onItemRemoved = function(item) {
      $log.log("onItemRemoved item: "+item);
  };  
  //End Drag and Drop Code

  $scope.save_dashboard_changes = function(){        
      //$('#btn_save_dash').button('loading');
      $('#btn_save_dash').addClass('loadicon');
      $('#btn_save_dash').removeClass('saveicon');
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();        
      params = {          
        'csrfmiddlewaretoken': $scope.csrf_token,
        'dash_type':"Flow",
        'widgets':angular.toJson($scope.widgets)
      }
      HttpRequestService.postRequest("/dashboard/save_dashboard",params).then(function(d) {
          if(d.status == 'success'){
              if(d.response.status == "success"){                                               
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"success","op":""});
              }
              else{
                  $scope.ErrorMessage = "Unable to save dashboard changes";
                  $scope.error_box = true;
              }
          }
          else if(d.status == "error"){                            
            $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":""});
          }
          //$('#btn_save_dash').button('reset');
          //$('#btn_save_dash').hide();
          $('#btn_save_dash').addClass('saveicon');
          $('#btn_save_dash').removeClass('loadicon');  
          $scope.savedash_btn_flag = false;
      });
  }

  $scope.restore_dashboard = function(){
      $('#btn_restore').button("loading");
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
        'csrfmiddlewaretoken': $scope.csrf_token,
        'dash_type':"Flow"          
      }
      HttpRequestService.postRequest("/dashboard/restore_dashboard",params).then(function(d) {
          if(d.status == 'success'){
              if(d.response.status == 'success'){                                               
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"restored","op":""},{reload: true});
              }
              else{
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
              }
          }
          else if(d.status == "error"){                           
            $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
          }
          $('#btn_restore').button('reset');
          $('#btn_restore').hide();
      });
  }


  function setevents(scope_variable, to_hide, chart_item, current_spinner){
    $scope[scope_variable] = {
                        renderComplete:function(evnt,data) {
                            $scope.$apply(function() {
                                $scope[to_hide] = true;
                            });
                        },
                        dataPlotClick: function (eventObj, dataObj) {
                          $rootScope.startLoading(current_spinner);
                          $scope.showModal = function(item) {
                              // console.log(item);
                              
                              var modalInstance = $modal.open({
                                templateUrl: TEMPLATE_URL+'modal_popup.html',
                                controller: 'myModal',
                                backdrop: 'static',
                                keyboard: false,
                                // windowClass: 'my-dialog',                                  
                                resolve: {
                                  item: function(){
                                    return item;
                                  }
                                }
                              });
                          };
                          params = {          
                              'csrfmiddlewaretoken': $scope.csrf_token,
                              'chart_item': chart_item,
                              'value': dataObj.categoryLabel,
                              'request_from': 'flow_dashboard',
                              'duration':$scope.filter,
                              'host':$scope.host_id,
                              'custome_date': $rootScope.custome_date,
                              'category' : dataObj.datasetName,
                              'optional_filter': angular.toJson($rootScope.filter_details)
                            }
                            HttpRequestService.postRequest("/dashboard/popup/list",params).then(function(d) {
                              if($rootScope.plot_click_counter == 0){
                                  $scope.showModal(d.response);
                              }
                              $rootScope.plot_click_counter++;
                            });
                          
                          console.log('Chart clicked at ' + dataObj.categoryLabel);
                        }
                    }
  }


  $scope.init = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

        loading_overlay("show");
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type': "Flow"                   
        }

        HttpRequestService.postRequest("/dashboard/widget_details",params).then(function(d) {
            if(d.status == 'success'){                            
              $scope.widgets = d.response;                 
              loading_overlay("hide");              
            }
            else if(d.status == 'error'){
                loading_overlay("hide");
                $scope.ErrorMessage = "Unable to find any widget details";
                $scope.error_box = true;                               
            }
        });

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
        }
        HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
            if(d.status == 'success'){
                $scope.customer_host = d.response.host_item;
                $scope.hostip = d.response.hostip; 
            }
        });
  }

  $scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {
      if ( ! $.fn.DataTable.isDataTable('#tbl_flow')) {
        $('#tbl_flow').DataTable({
          "bLengthChange": false,
          "scrollY": "530px",
          "scrollCollapse": true,
        });
      }                       
  });

  //function for graph
  $scope.initGraph = function(){
    setevents('event_rate','loading_image1', 'flow_events', 'flow_event_spinner');
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"events_graph",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.myDataSource = {
                      "chart": {                         
                          "showvalues": "0",
                          "plotgradientcolor": "",
                          "formatnumberscale": "0",
                          "showplotborder": "0",              
                          "canvaspadding": "0",
                          //"bgcolor": "FFFFFF",
                          "showalternatehgridcolor": "0",
                          "divlinecolor": "CCCCCC",
                          "showcanvasborder": "0",
                          "legendborderalpha": "0",              
                          "canvasborderalpha": "0",
                          "showborder": "0",
                          // "labelStep":"500",
                          "yAxisName": "Events Count",
                          "labelDisplay": "rotate",
                          "slantLabels":"1",
                          "showLabels":"0",
                          "theme": $scope.graph_theme
                      },
                      "categories": [
                          {
                              "category": d.response.category
                          }
                      ],
                      "dataset": d.response.dataset
                  }
                }
                else{
                  $scope.loading_image1 = true;
                }
            });
  }

  $scope.destinationPort = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"destination_port",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_destinations_ports = d.response.data
                }
                $scope.loading_image2 = true;
            });
  }

  $scope.sourcePort = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"source_port",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_source_ports = d.response.data
                }
                $scope.loading_image3 = true;
            });
  }

  $scope.destinationIP = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"destination_ip",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_destination_ip = d.response.data
                }
                $scope.loading_image4 = true;
            });
  }

  $scope.sourceIP = function(){
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"source_ip",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_source_ip = d.response.data
                }
                $scope.loading_image5 = true;
            });
  }
  

  //pichart configuration
  var pie_conf = {
                    //"bgColor": "#ffffff",
                    "showBorder": "0",
                    "use3DLighting": "0",
                    "showShadow": "0",
                    // "enableSmartLabels": "0",
                    "startingAngle": "0",
                    "showPercentValues": "1",
                    "showPercentInTooltip": "0",
                    "decimals": "1",
                    "captionFontSize": "14",
                    "subcaptionFontSize": "14",
                    "subcaptionFontBold": "0",
                    "toolTipColor": "#ffffff",
                    "toolTipBorderThickness": "0",
                    "toolTipBgColor": "#000000",
                    "toolTipBgAlpha": "80",
                    "toolTipBorderRadius": "2",
                    "toolTipPadding": "5",
                    "showHoverEffect": "1",
                    "showLegend": "1",
                    "legendBgColor": "#ffffff",
                    "legendBorderAlpha": "0",
                    "legendShadow": "0",
                    "legendItemFontSize": "10",
                    //"legendItemFontColor": "#666666",
                    "useDataPlotColorForLabels": "1",
                    "plottooltext": "$label : $value",
                    "showLabels":"1",
                    "showValues":"1",
                    "theme":$scope.graph_theme

                }
  //pie charts
  $scope.bytesClient = function(){

    setevents('btc_event','loading_image6', 'bytes_to_client', 'bytes_to_client_spinner');
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"bytes_to_client",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  console.log("aaaaaaaaaaaaaaaaa",d.response)
                  var data_list = d.response.data_list
                  delete d.response.data_list
                  $scope.total_hits = d.response.data
                  $scope.piechart_bytes_client = {
                                      "chart": pie_conf,
                                      "data": data_list
                                  }
                  
                }
                else{
                  $scope.loading_image6 = true;
                }
            });
  }
  $scope.bytesServer = function(){
    
    setevents('event_bts','loading_image7', 'bytes_to_server', 'bytes_to_server_spinner');
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"bytes_to_server",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  var data_list = d.response.data_list
                  delete d.response.data_list
                  $scope.total_hits = d.response.data
                  $scope.piechart_bytes_server = {
                                      "chart": pie_conf,
                                      "data": data_list
                                  }
                  
                }
                else{
                  $scope.loading_image7 = true;
                }
            });
  }
  $scope.packetsClient = function(){
    
    setevents('event_ptc','loading_image8', 'packets_to_client', 'packet_to_client_spinner');
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"packets_to_client",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  var data_list = d.response.data_list
                  delete d.response.data_list
                  $scope.total_hits = d.response.data
                  $scope.piechart_packets_client = {
                                      "chart": pie_conf,
                                      "data": data_list
                                  }
                  
                }
                else{
                  $scope.loading_image8 = true;
                }
            });
  }
  $scope.packetsServer = function(){
    
    setevents('event_pts','loading_image9', 'packet_to_server', 'packet_to_server_spinner');
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"packets_to_server",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {

                if(d.status == 'success'){
                  var data_list = d.response.data_list
                  delete d.response.data_list
                  $scope.total_hits = d.response.data
                  $scope.piechart_packets_server = {
                                      "chart": pie_conf,
                                      "data": data_list
                                  }
                  
                }
                else{
                  $scope.loading_image9 = true;
                }
            });
  }
  

  $scope.tcpState = function(){

    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"tcp_state",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_tcp_state = d.response.data
                }
                $scope.loading_image10 = true;
            });
  }

  $scope.tcpFlags = function(){
    console.log("bytes")
    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"tcp_flags",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_tcp_flags = d.response.data 
                }
                $scope.loading_image11 = true;
            });
  }

  $scope.tcpFlagsClient = function(){

    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"tcp_flags_client",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }
    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_tcp_flags_client = d.response.data
                }
                $scope.loading_image12 = true;
            });
  }

  $scope.tcpFlagsServer = function(){

    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"tcp_flags_server",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.flow_tcp_flags_server = d.response.data
                }
                $scope.loading_image13 = true;
            });
  }
  

  //documents table
  $scope.documents = function(){

    params = {          
    'csrfmiddlewaretoken': $scope.csrf_token,
    'type':"documents",
    'duration':$scope.filter,
    'host':$scope.host_id,
    'custome_date': $rootScope.custome_date,
    'optional_filter': angular.toJson($rootScope.filter_details)
    }

    HttpRequestService.postRequest("/dashboard/flow_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.documents = d.response.data
                  $scope.loading_image14 = true;
                }
                
            });
  }

}