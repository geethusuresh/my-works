function HttpTrafficConfigController($scope, $http, $state, $stateParams, HttpRequestService, $stateParams){

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.http_traffic = []

    $scope.HttpTraffic = function(){
        $http.get("/dashboard/http_traffic").then(function(response) {
            if (response.data.error){$scope.http_traffic = [];}
            else{ $scope.http_traffic = response.data; }
            });
    }

    $scope.Customer = function(){
        $http.get("/dashboard/customer").then(function(response) {
                $scope.customer = response.data;
            });
    }

    $scope.HostInfo = function(){
        $http.get("/dashboard/host_info").then(function(response) {
                $scope.host_info = response.data;
                if (!$stateParams.id){ $scope.http_traffic.host = response.data[0].pk; }
            });
    }

    $scope.HttpTrafficDetails = function(){
        if ($stateParams.id){
            $http.get("/dashboard/http_traffic?id="+$stateParams.id).then(function(response) {
                    $scope.http_traffic = response.data[0].fields;
                    $scope.http_traffic_id = response.data[0].pk;
                });
        }
        else { $scope.add = true }
    }


    $scope.HttpTrafficUpdate = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.http_traffic.host){
            $('#http_traffic_host').attr('style', 'display: inline-block');
        }
        if (!$scope.http_traffic.host){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': $stateParams.id,
          'customer': $scope.http_traffic.customer,
          'host': $scope.http_traffic.host,
          'ip_range': $scope.http_traffic.ip_range,
        }
        HttpRequestService.postRequest("/dashboard/http_traffic", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Http traffic successfully updated", type: "success"},
                function(){ $state.go('http_traffic', {}, {reload: true}); });
            }
        });
    }

    $scope.HttpTrafficDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/dashboard/delete_http_traffic/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Http traffic successfully deleted", type: "success"},
                function(){ $state.go('http_traffic', {}, {reload: true}); });
            }
        });
    }

}


