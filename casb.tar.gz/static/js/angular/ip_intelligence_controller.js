function IpIntelligenceController($scope,$http,$state,$stateParams,HttpRequestService){


    $scope.timestamp = true;
    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

    $scope.ResetValues = function(){
        $scope.ip = [];
    }

    $scope.ipIntelligence = function(){
        $scope.ip = [];
        $('#ip_invalid').attr('style', 'display: none;');
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'ip': $("#ip_address").val(),
        }
        HttpRequestService.postRequest("/threat_intelligence/ip_intelligence/", params).then(function(d) {
            $('button.btn-save div').removeClass('loadicon');
            $('button.btn-save div').addClass('saveicon');
            if(d.response.status == 'success'){
                document.getElementById("scanipmain").className = "";
                $scope.ip = d.response;
            }
            else{ $('#ip_invalid').text(d.response.message); $('#ip_invalid').attr('style', 'display: table;'); }
        });
    }


}