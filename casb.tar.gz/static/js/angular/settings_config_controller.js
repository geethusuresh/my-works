function SettingsConfigController($scope, $http, $state, $stateParams, HttpRequestService){

    $scope.ibm = []
    $scope.virus_total = []
    $scope.opswat = []
    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.ibm_user_token = false;
    $scope.ibm_api_key = false;
    $scope.user_password = false;
    $scope.ip_report_api_url = false;
    $scope.dns_status_api_url = false;
    $scope.malware_status_api_url = false;
    $scope.whois_report_api_url = false;

    $scope.Help = function(){
        $http.get("/dashboard/help").then(function(response) {
                $scope.helps = response.data;
            });
    }

    $scope.Customer = function(){
        $http.get("/dashboard/customer").then(function(response) {
                $scope.customer = response.data;
                if (!$stateParams.id){
                    $scope.ibm.customer = response.data[0].pk;
                    $scope.virus_total.customer = response.data[0].pk;
                    $scope.opswat.customer = response.data[0].pk;
                }
            });
    }

    $scope.LoadConfig = function(type){
        if ($stateParams.id){ var url = "/dashboard/config?type="+type+"&id="+$stateParams.id;  }
        else{ var url = "/dashboard/config?type="+type; $scope.add = true }
        $http.get(url).then(function(response) {
                if (response.data.ibm){
                    if ($stateParams.id){ $scope.ibm = response.data.ibm[0].fields;
                                          $scope.ibm_id = response.data.ibm[0].pk; }
                    else{ $scope.ibm = response.data.ibm; }
                }
                if (response.data.virus_total){
                    if ($stateParams.id){ $scope.virus_total = response.data.virus_total[0].fields;
                                          $scope.virus_total_id = response.data.virus_total[0].pk; }
                    else{ $scope.virus_total = response.data.virus_total;}
                }
                if (response.data.opswat){
                    if ($stateParams.id){ $scope.opswat = response.data.opswat[0].fields;
                                          $scope.opswat_id = response.data.opswat[0].pk; }
                    else{$scope.opswat = response.data.opswat;}
                }
            });
    }


    $scope.IBMConfig = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.ibm.user_token){
            $('#ibm_user_token').attr('style', 'display: inline-block');
        }
        if (!$scope.ibm.user_api_key){
            $('#ibm_api_key').attr('style', 'display: inline-block');
        }
        if (!$scope.ibm.user_password){
            $('#ibm_pwd').attr('style', 'display: inline-block');
        }
        if (!$scope.ibm.ip_report_api_url){
            $('#ibm_ip_report').attr('style', 'display: inline-block');
        }
        if (!$scope.ibm.dns_status_api_url){
            $('#ibm_dns_status').attr('style', 'display: inline-block');
        }
        if (!$scope.ibm.malware_status_api_url){
            $('#ibm_malware').attr('style', 'display: inline-block');
        }
        if (!$scope.ibm.whois_report_api_url){
            $('#ibm_whois').attr('style', 'display: inline-block');
        }
        if (!$scope.ibm.user_token || !$scope.ibm.user_api_key || !$scope.ibm.user_password ||
            !$scope.ibm.ip_report_api_url || !$scope.ibm.dns_status_api_url || !$scope.ibm.malware_status_api_url ||
            !$scope.ibm.whois_report_api_url){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'type': 'ibm',
          'id': $stateParams.id,
          'customer': $scope.ibm.customer,
          'user_token': $scope.ibm.user_token,
          'user_api_key': $scope.ibm.user_api_key,
          'user_password': $scope.ibm.user_password,
          'ip_report_api_url': $scope.ibm.ip_report_api_url,
          'dns_status_api_url': $scope.ibm.dns_status_api_url,
          'malware_status_api_url': $scope.ibm.malware_status_api_url,
          'whois_report_api_url': $scope.ibm.whois_report_api_url,
        }
        HttpRequestService.postRequest("/dashboard/config", params).then(function(response) {
            if(response.response.status == 'success'){
                swal({title: "Success", text: "IBM x-force configuration updated", type: "success"},
                function(){ $state.go('ibm_config', {}, {reload: true}); })
            }else{ swal("Error!", response.response.message, "error"); }
        });
    }


    $scope.VirusTotalConfig = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.virus_total.user_api_key){
            $('#vt_user_api_key').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.host){
            $('#vt_host').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.file_scan_url){
            $('#vt_file_scan').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.file_report_url){
            $('#vt_file_report').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.url_scan_url){
            $('#vt_url_scan').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.url_report_url){
            $('#vt_url_report').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.ip_report_url){
            $('#vt_ip_report').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.domain_report_url){
            $('#vt_domian_report').attr('style', 'display: inline-block');
        }
        if (!$scope.virus_total.user_api_key || !$scope.virus_total.host || !$scope.virus_total.file_scan_url ||
            !$scope.virus_total.file_report_url || !$scope.virus_total.url_scan_url || !$scope.virus_total.url_report_url ||
            !$scope.virus_total.ip_report_url || !$scope.virus_total.domain_report_url){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'type': 'virus_total',
          'id': $stateParams.id,
          'customer': $scope.virus_total.customer,
          'user_api_key': $scope.virus_total.user_api_key,
          'host': $scope.virus_total.host,
          'file_scan_url': $scope.virus_total.file_scan_url,
          'file_report_url': $scope.virus_total.file_report_url,
          'url_scan_url': $scope.virus_total.url_scan_url,
          'url_report_url': $scope.virus_total.url_report_url,
          'ip_report_url': $scope.virus_total.ip_report_url,
          'domain_report_url': $scope.virus_total.domain_report_url,
        }
        HttpRequestService.postRequest("/dashboard/config", params).then(function(response) {
            if(response.response.status == 'success'){
                swal({title: "Success", text: "Virus Total configuration updated", type: "success"},
                function(){ $state.go('virus_total_config', {}, {reload: true}); })
            } else{ swal("Error!", response.response.message, "error"); }
        });
    }


    $scope.OpswatConfig = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.opswat.user_api_key){
            $('#opswat_user_api').attr('style', 'display: inline-block');
        }
        if (!$scope.opswat.hash_scan_url){
            $('#opswat_scan_url').attr('style', 'display: inline-block');
        }
        if (!$scope.opswat.user_api_key || !$scope.opswat.hash_scan_url){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'type': 'opswat',
          'id': $stateParams.id,
          'customer': $scope.opswat.customer,
          'user_api_key': $scope.opswat.user_api_key,
          'hash_scan_url': $scope.opswat.hash_scan_url,
        }
        HttpRequestService.postRequest("/dashboard/config", params).then(function(response) {
            if(response.response.status == 'success'){
                swal({title: "Success", text: "Opswat configuration updated", type: "success"},
                function(){ $state.go('opswat_config', {}, {reload: true}); })
            } else{ swal("Error!", response.response.message, "error"); }
        });
    }

    $scope.IBMConfigDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/dashboard/delete_ibm_config/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Successfully deleted", type: "success"},
                function(){ $state.go('ibm_config', {}, {reload: true}); });
            }
        });
    }

    $scope.VirusTotalConfigDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/dashboard/delete_virus_total_config/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Successfully deleted", type: "success"},
                function(){ $state.go('virus_total_config', {}, {reload: true}); });
            }
        });
    }

    $scope.OpswatConfigDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/dashboard/delete_opswat_config/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Successfully deleted", type: "success"},
                function(){ $state.go('opswat_config', {}, {reload: true}); });
            }
        });
    }

}


