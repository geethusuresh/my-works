function AzureController($scope, $http, $state, $stateParams, HttpRequestService){

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.error = false;


    // Azure Config ################################
    $scope.azure_conf = []

    $scope.AzureConf = function(){
        $http.get("/vulnerability/azure_conf/").then(function(response) {
            if (response.data.error){$scope.azure_conf = [];}
            else{ $scope.azure_conf = response.data; }
            });
    }

    $scope.Customer = function(){
        $http.get("/dashboard/customer").then(function(response) {
                $scope.customer = response.data;
                if (!$stateParams.id){ $scope.azure_conf.customer = response.data[0].pk;}
            });
    }

    $scope.AzureConfDetails = function(){
        if ($stateParams.id){
            $http.get("/vulnerability/azure_conf?id="+$stateParams.id).then(function(response) {
                    $scope.azure_conf = response.data[0].fields;
                    $scope.azure_conf_id = response.data[0].pk;
                });
        }
        else { $scope.add = true }
    }


    $scope.AzureConfUpdate = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.azure_conf.subscription_name){
            $('#subscription_name_error').attr('style', 'display: inline-block');
        }
        if (!$scope.azure_conf.subscription_id){
            $('#subscription_id_error').attr('style', 'display: inline-block');
        }
        if (!$scope.azure_conf.app_id){
            $('#app_id_error').attr('style', 'display: inline-block');
        }
        if (!$scope.azure_conf.app_secret){
            $('#app_secret_error').attr('style', 'display: inline-block');
        }
        if (!$scope.azure_conf.object_id){
            $('#object_id_error').attr('style', 'display: inline-block');
        }
        if (!$scope.azure_conf.authentication_endpoint){
            $('#endpoint_error').attr('style', 'display: inline-block');
        }
        if (!$scope.azure_conf.subscription_name || !$scope.azure_conf.subscription_id || !$scope.azure_conf.app_id || !$scope.azure_conf.app_secret || !$scope.azure_conf.object_id || !$scope.azure_conf.authentication_endpoint)
           { return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': $stateParams.id,
          'customer': $scope.azure_conf.customer,
          'subscription_name': $scope.azure_conf.subscription_name,
          'subscription_id': $scope.azure_conf.subscription_id,
          'app_id': $scope.azure_conf.app_id,
          'app_secret': $scope.azure_conf.app_secret,
          'object_id': $scope.azure_conf.object_id,
          'authentication_endpoint': $scope.azure_conf.authentication_endpoint,
        }
        HttpRequestService.postRequest("/vulnerability/azure_conf/", params).then(function(response) {
            if(response.response.status == 'success'){
                swal({title: "Success", text: "Azure configuration successfully updated", type: "success"},
                function(){ $('#azure-cancel').click() });
            }else{ swal("Error!", response.response.message, "error"); }
        });
    }

    $scope.AzureConfDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/vulnerability/azure_conf_delete/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Azure configuration successfully deleted", type: "success"},
                function(){ $state.go('azure_config', {}, {reload: true}); });
            }
        });
    }

    // Azure Dashboard #############################
    $scope.azure = false;
    $scope.azure_main = true;

    $scope.Azure = function(){
        $scope.policies = false;
        $scope.security_solutions = false;
        $scope.security_alerts = false;
        $scope.security_health_details = false;
        $scope.azure_main = true;

        if (!$scope.azure){
            $http.get("/vulnerability/azure").then(function(response) {
                    if(response.data.status=='error'){ $scope.error = true; $scope.azure_main = false; return false; }
                    $scope.azure = response.data;
                    $scope.azure_security_solutions = response.data.security_solutions.value;
                    $scope.azure_alerts = response.data.alert.value;
                    $scope.azure_policy = response.data.policy.value;
                    $scope.low = 0;
                    $scope.medium = 0;
                    $scope.high = 0;
                    angular.forEach(response.data.security_status.value, function(value, key) {
                      if(value.properties.securityState=='High'){$scope.high++};
                      if(value.properties.securityState=='Medium'){$scope.medium++};
                      if(value.properties.securityState=='Low'){$scope.low++};
                    });
                    $scope.total = $scope.high + $scope.medium + $scope.low;
                    FusionCharts.ready(function () {
                    var revenueChart = new FusionCharts({
                        type: 'doughnut2d',
                        renderAt: 'chart-container',
                        width: '350',
                        height: '350',
                        dataFormat: 'json',
                        dataSource: {
                            "chart": {
                                "numberPrefix": "",
                                "paletteColors": "#cc1800,#ff6400,#ffbd00",
                                "bgColor": "none",
                                "showBorder": "0",
                                "use3DLighting": "0",
                                "showShadow": "0",
                                "enableSmartLabels": "0",
                                "startingAngle": "310",
                                "showLabels": "0",
                                "showPercentValues": "1",
                                "showLegend": "1",
                                "legendShadow": "0",
                                "legendBorderAlpha": "0",
                                "defaultCenterLabel": "Total: " + $scope.total,
                                "centerLabel": "$label: $value",
                                "centerLabelBold": "1",
                                "showTooltip": "0",
                                "decimals": "0",
                                "captionFontSize": "14",
                                "subcaptionFontSize": "14",
                                "subcaptionFontBold": "0"
                            },
                            "data": [
                                {
                                    "label": "High Severity",
                                    "value": $scope.high
                                },
                                {
                                    "label": "Medium Severity",
                                    "value": $scope.medium
                                },
                                {
                                    "label": "Low Severity",
                                    "value": $scope.low
                                }
                            ]
                        }
                    }).render();
                });
            });
        }
    }

    $scope.ListPolicies = function(){
        $scope.azure_main = false;
        $scope.security_solutions = false;
        $scope.security_alerts = false;
        $scope.security_health_details = false;
        $scope.policies = true;
    }

    $scope.ListSecuritySolutions = function(){
        $scope.azure_main = false;
        $scope.policies = false;
        $scope.security_alerts = false;
        $scope.security_health_details = false;
        $scope.security_solutions = true;
    }

    $scope.ListSecurityAlerts = function(){
        $scope.azure_main = false;
        $scope.policies = false;
        $scope.security_solutions = false;
        $scope.security_health_details = false;
        $scope.security_alerts = true;
    }

    $scope.SecurityHealthDetails = function(id){
        $scope.security_health = []
        $scope.azure_main = false;
        $scope.policies = false;
        $scope.security_solutions = false;
        $scope.security_alerts = false;
        angular.forEach($scope.azure.security_status.value, function(value, key) {
            if(value.id==id){ $scope.security_health = value; return false; };
        });
        $scope.security_health_details = true;
    }

    $scope.addClass = function(){
        $(".nav-tabs li:first").addClass("active");
    }

    $scope.addClassAzureContent = function(){
        $(".tab-content div:first").addClass("active");
    }

}
