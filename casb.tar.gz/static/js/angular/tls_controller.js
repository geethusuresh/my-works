function TLSController($scope,$http, HttpRequestService,$stateParams,$state, $filter, $log, $location, $modal, TEMPLATE_URL, $rootScope, $controller){
  angular.extend(this,$controller('MessageController', {$scope: $scope}));
  $scope.TLSEventSource = {}
  $scope.tls_subject_info = {}
  $scope.tls_dn_info = {}
  $scope.TLSVersionInfo = {}
  $scope.TLSFinger = {}
  $scope.TCPPortsInfo = {}
  $scope.TLSTransaction = []
  $scope.TLSTransaction2 = []
  $scope.tlstrend = {}
  $scope.tlsworld = {}
  $scope.tlsusa = {}
  $scope.savedash_btn_flag = false;
  $scope.graph_theme = $('#graph_theme').val();

  $scope.dash_heading = "TLS Data Analytics Dashboard";

  $scope.filter = $stateParams.filter;
  $scope.operation = $stateParams.op;
  $scope.op_status = $stateParams.op_status;
  $scope.host_id = $stateParams.host;
  $scope.current_state = $state.current.name;
  $scope.filter_heading = "Duration";

  if($scope.operation=="drag"){        
        $scope.widget_move = "true";
  }
  else{
    $scope.widget_move = "false";
  }  

  if($scope.filter && $scope.filter != 'date_range'){
    $scope.duration_selected = " Last " + filter_names($scope.filter);      
  }
  else if($scope.filter == 'date_range'){        
    $scope.duration_selected = "( " + $rootScope.custome_date.replace(" - "," to ") + " )"       
  }
  else{
    $scope.duration_selected = "Last 24 hours";
  }

  //Code for Drag and Drop
  $scope.options = {
      cellHeight: 75,
      verticalMargin: 5
  };

  $scope.widgets = []                                   
                         

  $scope.addWidget = function() {
      var newWidget = { x:0, y:0, width:1, height:1 };
      $scope.widgets.push(newWidget);
  };

  $scope.removeWidget = function(w) {
      var index = $scope.widgets.indexOf(w);
      $scope.widgets.splice(index, 1);
  };

  $scope.onChange = function(event, items) {
      $log.log("onChange Start: "+items); 
  };

  $scope.onDragStart = function(event, ui) {
      $log.log("onDrag Start: "+ui);
  };

  $scope.onDragStop = function(event, ui) {        
      $log.log("onDragStop event: "+event+" ui:"+ui);
      //$('#btn_save_dash').show();
      $scope.savedash_btn_flag = true;
  };

  $scope.onResizeStart = function(event, ui) {
      $log.log("onResize Start: "+ui);
  };

  $scope.onResizeStop = function(event, ui) {
     $log.log("onResizeStop item: "+ui);
     //$('#btn_save_dash').show();
     $scope.savedash_btn_flag = true;
  };

  $scope.onItemAdded = function(item) {
      $log.log("onItemAdded item: "+item);
  };

  $scope.onItemRemoved = function(item) {
      $log.log("onItemRemoved item: "+item);
  };  
  //End Drag and Drop Code

  $scope.save_dashboard_changes = function(){        
      //$('#btn_save_dash').button('loading');
      $('#btn_save_dash').addClass('loadicon');
      $('#btn_save_dash').removeClass('saveicon');
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();        
      params = {          
        'csrfmiddlewaretoken': $scope.csrf_token,
        'dash_type':"TLS",
        'widgets':angular.toJson($scope.widgets)
      }
      HttpRequestService.postRequest("/dashboard/save_dashboard",params).then(function(d) {
          if(d.status == 'success'){
              if(d.response.status == "success"){                                               
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"success","op":""});
              }
              else{
                  $scope.ErrorMessage = "Unable to save dashboard changes";
                  $scope.error_box = true;
              }
          }
          else if(d.status == "error"){                            
            $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":""});
          }
          //$('#btn_save_dash').button('reset');
          //$('#btn_save_dash').hide();
          $('#btn_save_dash').addClass('saveicon');
          $('#btn_save_dash').removeClass('loadicon');
          $scope.savedash_btn_flag = false;
      });
  }

  $scope.restore_dashboard = function(){
      $('#btn_restore').button("loading");
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
        'csrfmiddlewaretoken': $scope.csrf_token,
        'dash_type':"TLS"          
      }
      HttpRequestService.postRequest("/dashboard/restore_dashboard",params).then(function(d) {
          if(d.status == 'success'){
              if(d.response.status == 'success'){                                               
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"restored","op":""},{reload: true});
              }
              else{
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
              }
          }
          else if(d.status == "error"){                           
            $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
          }
          $('#btn_restore').button('reset');
          $('#btn_restore').hide();
      });
  }

  function setevents(scope_variable, to_hide, chart_item, current_spinner){
    console.log(chart_item)
      $scope[scope_variable] = {
                          renderComplete:function(evnt,data) {
                              $scope.$apply(function() {
                                  $scope[to_hide] = true;
                              });
                          },
                          dataPlotClick: function (eventObj, dataObj) {
                            $rootScope.startLoading(current_spinner);
                            $scope.showModal = function(item) {
                                // console.log(item);
                                var modalInstance = $modal.open({
                                  templateUrl: TEMPLATE_URL+'modal_popup.html',
                                  controller: 'myModal',
                                  backdrop: 'static',
                                  keyboard: false,
                                  // windowClass: 'my-dialog',
                                  resolve: {
                                    item: function(){
                                      return item;
                                    }
                                  }
                                });
                            };
                            params = {          
                                'csrfmiddlewaretoken': $scope.csrf_token,
                                'chart_item': chart_item,
                                'value': dataObj.categoryLabel,
                                'request_from': 'tls_dashboard',
                                'duration':$scope.filter,
                                'host':$scope.host_id,
                                'custome_date': $rootScope.custome_date,
                                'optional_filter': angular.toJson($rootScope.filter_details)
                              }
                            HttpRequestService.postRequest("/dashboard/popup/list",params).then(function(d) {
                              if($rootScope.plot_click_counter == 0){
                                  $scope.showModal(d.response);
                              }
                              $rootScope.plot_click_counter++;
                            });
                            
                            console.log('Chart clicked at ' + dataObj.categoryLabel);
                          }
                      }
    }

  

  $scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {
      if ( ! $.fn.DataTable.isDataTable( '#tbl_tls' ) ) {
          $('#tbl_tls').DataTable({
            "bLengthChange": false,
            "scrollY": "530px",
            "scrollCollapse": true,
          });
      }                       
  });

  $scope.init = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

        loading_overlay("show");
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type': "TLS"                   
        }
        HttpRequestService.postRequest("/dashboard/widget_details",params).then(function(d) {
            if(d.status == 'success'){                            
              $scope.widgets = d.response;                 
              loading_overlay("hide");              
            }
            else if(d.status == 'error'){
                loading_overlay("hide");
                $scope.ErrorMessage = "Unable to find any widget details";
                $scope.error_box = true;                               
            }
        });

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
        }
        HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
            if(d.status == 'success'){
                $scope.customer_host = d.response.host_item;
                $scope.hostip = d.response.hostip; 
            }
        });
  }

  $scope.tls_events = function(){          

          setevents('event_rate','loading_image1','tls_events','tls_event_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_events",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_tls(d.response,'tls_events');
                  if (d.response.length == 0){
                    $scope.loading_image1 = true;
                  }
                }
                else{
                  $scope.loading_image1 = true;
                }
            });
  }

  $scope.tls_subject = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_subject",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.tls_subject_info = d.response;
                }
                $scope.loading_image6 = true;
            });
  }

  $scope.tls_issuerdn = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_issuerdn",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.tls_dn_info = d.response;
                }
                $scope.loading_image7 = true;
            });
  }

  $scope.tls_version = function(){          

          setevents('event_version','loading_image8','tls_version','tls_version_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_version",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_tls(d.response,'tls_version');
                  if (d.response.length == 0){
                    $scope.loading_image8 = true;
                  }
                }
                else{
                  $scope.loading_image8 = true;
                }
            });
  }

  $scope.tls_fingerprint = function(){          

          setevents('event_fingerprint','loading_image5','tls_finger','tls_finger_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_finger",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_tls(d.response,'tls_finger');
                  if (d.response.length == 0){
                    $scope.loading_image5 = true;
                  }
                }
                else{
                  $scope.loading_image5 = true;
                }
            });
  }

  $scope.tls_ports = function(){          

          setevents('event_ports','loading_image9','tls_ports','tls_ports_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_ports",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_tls(d.response,'tls_ports');
                  if (d.response.length == 0){
                    $scope.loading_image9 = true;
                  }
                }
                else{
                  $scope.loading_image9 = true;
                }
            });
  }

  $scope.tls_transaction = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_transaction",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.TLSTransaction = d.response;                 
                }                
                $scope.loading_image10 = true;
            });
  }

  $scope.tls_trend = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"tls_trend",
            'duration':$scope.filter,
            'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
        }

        HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.tlstrend = d.response;
                }
                $scope.loading_image2 = true;
        });
        $('[data-toggle="tooltip"]').tooltip();
  }

  $scope.tls_world = function(){

        setevents('event_world','loading_image3');
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"tls_world",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            'optional_filter': angular.toJson($rootScope.filter_details)
        }

        HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_tls(d.response,'tls_world');
                  if (d.response.length == 0){
                    $scope.loading_image3 = true;
                  }
                }
                else{
                  $scope.loading_image3 = true;
                }
            });
  }

  $scope.tls_usa = function(){

      setevents('event_usa','loading_image4');
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_usa",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
      }

      HttpRequestService.postRequest("/dashboard/tls_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_tls(d.response,'tls_usa');
                  if (d.response.length == 0){
                    $scope.loading_image3 = true;
                  }
                }
                else{
                  $scope.loading_image3 = true;
                }
            });
  }

  $scope.tls_map = function(){
    $scope.tls_world();
    $scope.tls_usa();
    new Switchery(document.getElementById('map-panel-switch-tls'),{size:'small'});          
    $('#map-panel-switch-tls').change(function(){
      var duration_info = $scope.duration_selected;      
      if($('#world_map_tls').css("display")=="none"){
        $('#world_map_tls').show();
        $('#usa_map_tls').hide();
        $('#map_headings_tls').html("World - "+duration_info);        
      }
      else if($('#usa_map_tls').css("display")=="none"){
        $('#world_map_tls').hide();
        $('#usa_map_tls').show();
        $('#map_headings_tls').html("USA - "+duration_info);
      }
    });
}

  $scope.graph_details_tls = function(data_details,graph_type){
      if(graph_type == "tls_events"){                           
          $scope.TLSEventSource = {
            chart: {                    
                    "numberPrefix": "",
                    "theme": $scope.graph_theme,
                    "yAxisName": "Events Count",
                    "labelStep":"10",
                    "showValues": "0",
                    "showLabels":"0",
                    "labelDisplay": "rotate",
                    "slantLabels":"1"
                },
                data: data_details
          };
      }
      else if(graph_type == "tls_version"){
          $scope.TLSVersionInfo = {
              "chart": {                    
                    "useDataPlotColorForLabels": "1",
                    "theme": $scope.graph_theme
                },
                "data":data_details
          };
      }
      else if(graph_type == "tls_finger"){
          $scope.TLSFinger = {
              chart: {                     
                      "numberPrefix": "",
                      "theme": $scope.graph_theme,
                      "yAxisName": "Finger Print Count",
                      "labelDisplay": "rotate",
                      "showValues": "0",
                      "slantLabels":"1",
                      "paletteColors": "#EED17F,#97CBE7,#074868,#B0D67A,#2C560A,#DD9D82",
                      "showlabels": "0",
                  },
                  data: data_details
          };
      }
      else if(graph_type == "tls_ports"){
          $scope.TCPPortsInfo = {
              "chart": {                    
                    "useDataPlotColorForLabels": "1",
                    "theme": $scope.graph_theme
                },
                "data":data_details
          };
      }
      else if(graph_type == "tls_world"){
              $scope.tlsworld = {
                "chart": {                    
                    "theme": $scope.graph_theme,
                    "formatNumberScale": "0",
                    "numberSuffix": " Transactions",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Transactions"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Transactions"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Transactions"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 Transactions"
                        }
                    ]
                },
                "data":data_details 
            }
        }
        else if(graph_type == "tls_usa"){ 
            $scope.tlsusa = {
                "chart": {                   
                    "theme": $scope.graph_theme,
                    "formatNumberScale": "0",
                    "numberSuffix": " Transactions",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Transactions"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Transactions"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Transactions"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 Transactions"
                        }
                    ]
                },
                "data":data_details 
            }
        }                               
  }
  
}