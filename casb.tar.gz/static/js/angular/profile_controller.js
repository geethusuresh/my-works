function ProfileController($scope,$http,$state,$stateParams,HttpRequestService,$filter,$log,$location, $window, $timeout, fileUpload){	
    $scope.dash_heading = "Profile";
    $scope.profile_info = {}    
    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.two_factor = $stateParams.two_factor;
    $scope.showSuccessAlert = false;
    $scope.timezones = []

    if($scope.two_factor == "enabled"){
        $scope.SuccessMessage = "Two-factor authentication successfully enabled in your profile";        
        $('#succss_box').show();
    }
    if($stateParams.op_status == "img_error"){
        $scope.ErrorMessage = "Not able to update profile image";
        $('#error_box').show();
    }
    if($stateParams.op_status == "profile_success"){
        $scope.SuccessMessage = "Profile updated successfully";                    
        $('#succss_box').show();
    }
    if($stateParams.op_status == "profile_error"){
        $scope.ErrorMessage = "Not able to update profile";
        $('#error_box').show();
    }     

    //$scope.check_value = true;
    $scope.profile_details = function(){    	        
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'action':'info'          
        }
        HttpRequestService.postRequest("/dashboard/profile_details",params).then(function(d) {
            if(d.status == 'success'){
                $scope.profile_info = d.response;
                if (!$scope.profile_info.image){ $scope.profile_info.image = "/static/images/av1.png"; $scope.profile_info.default_image = true; }
                else{ $scope.profile_info.image = '/media/' + $scope.profile_info.image; $scope.profile_info.default_image = false; }
                profile_obj = d.response;
                $scope.firstname = profile_obj.firstname
                $scope.lastname = profile_obj.lastname
                $scope.location = profile_obj.location
                $scope.title = profile_obj.title
                $scope.city = profile_obj.city
                $scope.country = profile_obj.country
                $scope.image = profile_obj.image
                $scope.timezone = profile_obj.timezone
                $scope.twofactor_status = profile_obj.twofactor_status
                if($scope.twofactor_status == "enabled"){
                    $scope.check_value = true;
                }
                else{
                    $scope.check_value = false;
                }
            }
            else if(d.status == "error"){

            }             
        });
    } 
    $scope.profile_details();


   $(document).on('change','#profile-image' , function(){
        var file = $scope.selectedPic;
        if (file != undefined) {
            var uploadUrl = "/dashboard/profile_details";
            var fd = new FormData();
            fd.append('file', file);
            fd.append('action', "profile_pic");
            fd.append('csrfmiddlewaretoken',$scope.csrf_token);

            fileUpload.uploadFileToUrl(fd, uploadUrl).then(function(d){
                if(d.data.status == "failed"){
                    $state.go($state.current, {"op_status":"img_error"}, {reload: true});
                }
                else{
                    $scope.profile_info.default_image = false;
                    $scope.profile_info.image = '/media/' + d.data.image;
                }
            });
        }
        else{

            $state.go($state.current, {"op_status":"profile_success"}, {reload: true});
        }
    });


    $scope.removeProfilePic = function(){

        params = {
            'csrfmiddlewaretoken': $scope.csrf_token,
            'action':'remove_profile_pic',
        }
        HttpRequestService.postRequest("/dashboard/profile_details",params).then(function(d){
            if(d.response.status == "success"){
                $scope.profile_info.default_image = true;
                $scope.profile_info.image = "/static/images/av1.png";
            }
            else{
                $state.go($state.current, {"op_status":"profile_error"}, {reload: true});
            }
        });

    };


    $scope.update_profile = function(){

        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'action':'profile_data',
            'location': $scope.location,
            'title': $scope.title,
            'city': $scope.city,
            'country': $scope.country,
            'timezone': $scope.timezone,
        }
        HttpRequestService.postRequest("/dashboard/profile_details",params).then(function(d){
            if(d.response.status == "success"){
                $state.go($state.current, {"op_status":"profile_success"}, {reload: true});
            }
            else{               
                $state.go($state.current, {"op_status":"profile_error"}, {reload: true});
            }
        });

    };


    $scope.TimeZone = function(){
        $http.get("/dashboard/time_zone/").then(function(response) {
            $scope.timezones = response.data;
            });
    }


    $scope.reset_password = function(){
        $scope.submitted = true 
        function countdown(current_time){
            if(current_time === 0){
            //call function to connect to server
                $window.location.href = 'logout/';
            }
            else{
                current_time--;
            }
                $scope.time = current_time;
                $timeout(function(){countdown(current_time)}, 1000);
        };

        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'action':'password_change',
            'old_password': $scope.old_password,
            'password1': $scope.password1,
            'password2': $scope.password2,
        }
        if ($scope.change_password.$valid) {
            HttpRequestService.postRequest("/dashboard/profile_details",params).then(function(d){
                if(d.response.status== "success"){
                    $scope.showSuccessAlert = true;
                    countdown(5);
                }
                else{
                    //bootbox.alert("Passwords don't match");
                    $scope.ErrorMessage = "Passwords are not matching";
                    $('#error_box').show();
                }
            });
        }

    };

    $scope.enable_twofactor = function(){                    
        if ($scope.check_value){
            timer = $timeout(function () {
                $state.go("two_factor_auth");
            }, 800);            
        }
        else{            
            params = {          
                'csrfmiddlewaretoken': $scope.csrf_token,                              
            }
            HttpRequestService.postRequest("/two_factor_auth/disable",params).then(function(d) {
                if(d.status == 'success'){
                    if(d.response.status == "success"){
                        $scope.SuccessMessage = "Two factor authentication has been disabled successfully";                        
                        $('#succss_box').show();                       
                    }
                    else if(d.response.status == "error"){                       
                        $scope.ErrorMessage = "Some error occured. Please try after sometime";                       
                        $('#error_box').show();
                    }                                       
                }
                else if(d.status == "error"){
                    $scope.ErrorMessage = "Some error occured. Please try after sometime";                    
                    $('#error_box').show();
                }             
            });
        }
    };
}