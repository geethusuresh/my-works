function VirusScanController($scope, $http,$state,$stateParams,HttpRequestService, fileUpload){

    $scope.timestamp = true;
    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

    $scope.ResetValues = function(){
        $scope.scan_result = []
        $scope.opswat_result = []
        $('.validate-msg').attr('style', 'display: none');
    }


    $scope.VirusTotalScan = function($event){
        $scope.scan_result = [];
        $('.validate-msg').attr('style', 'display: none');
        $('#virus-total-scan-btn').removeClass('saveicon');
        $('#virus-total-scan-btn').addClass('loadicon');
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'value': $scope.virusTotal,
        }
        HttpRequestService.postRequest("/threat_intelligence/virus_scan/", params).then(function(d) {
            $('#virus-total-scan-btn').addClass('saveicon');
            $('#virus-total-scan-btn').removeClass('loadicon');
            if(d.status == 'success'){
                $scope.scan_result = d.response.scan_report;
                $scope.detected = d.response.detected;
                $scope.total_count = d.response.total_count;
                $scope.detected_count = d.response.detected_count;
            }
            if (d.response.status == "error"){
                $('.validate-msg').text(d.response.message);
                $('.validate-msg').attr('style', 'display: table');
            }
        });
    }

    $scope.VirusTotalFileScan = function(){
        if (!$scope.virus_total_file){ $('.validate-msg').attr('style', 'display: table'); return true; }
        $scope.scan_result = [];
        $('.validate-msg').attr('style', 'display: none');
        $('#virus-total-file-scan').addClass('loadicon');
        $('#virus-total-file-scan').removeClass('saveicon');
        var file = $scope.virus_total_file;
        var fd = new FormData();
        fd.append('file', file);
        fd.append('action', "virus_total");
        fd.append('csrfmiddlewaretoken', $scope.csrf_token);
        fileUpload.uploadFileToUrl(fd, "/threat_intelligence/virus_scan/").then(function(d){
            $('#virus-total-file-scan').addClass('saveicon');
            $('#virus-total-file-scan').removeClass('loadicon');
            if (d.response){$scope.scan_result = d.response.scan_report; $scope.detected = d.response.detected;
                $scope.detected_count = d.response.detected_count;
                $scope.total_count = d.response.total_count;}
            else {
                if (d.data.status == "error"){
                    $('.validate-msg').text(d.data.message);
                    $('.validate-msg').attr('style', 'display: table');
                }
                else{
                    $scope.scan_result = d.data.scan_report;
                    $scope.detected = d.data.detected;
                    $scope.detected_count = d.data.detected_count;
                    $scope.total_count = d.data.total_count;
                }
             }
        });
    }

    $scope.OpswatFileScan = function(){
        if (!$scope.opswat_file){ $('.validate-msg').attr('style', 'display: table'); return true; }
        $scope.opswat_result = [];
        $('.validate-msg').attr("style", "display: none;")
        $('#opswat-file-scan').addClass('loadicon');
        $('#opswat-file-scan').removeClass('saveicon');
        var file = $scope.opswat_file;
        var fd = new FormData();
        fd.append('file', file);
        fd.append('action', "opswat");
        fd.append('csrfmiddlewaretoken', $scope.csrf_token);
        fileUpload.uploadFileToUrl(fd, "/threat_intelligence/opswat_scan_report/").then(function(d){
            $('#opswat-file-scan').addClass('saveicon');
            $('#opswat-file-scan').removeClass('loadicon');
            if (d.response){
                if (d.response.status == "error"){
                    $('.validate-msg').text(d.response.message);
                    $('.validate-msg').attr("style", "display: table;");
                }
                else{
                    $scope.opswat_result = d.response.scan_report;
                    $scope.detected = d.response.detected;
                    $scope.detected_count = d.response.detected_count;
                    $scope.total_count = d.response.total_count;
                }
                }
            else{
                if (d.data.status == "error"){
                    $('.validate-msg').text(d.data.message);
                    $('.validate-msg').attr("style", "display: table;");
                }
                else{
                    $scope.opswat_result = d.data.scan_report;
                    $scope.detected = d.data.detected;
                    $scope.detected_count = d.data.detected_count;
                    $scope.total_count = d.data.total_count;
                }
            }
        });
    }


    $scope.OpswatScan = function($event){
        $scope.opswat_result = [];
        $('.validate-msg').attr("style", "display: none;")
        $('#opswat-scan-btn').removeClass('saveicon');
        $('#opswat-scan-btn').addClass('loadicon');
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'value': $scope.opswatScan,
        }
        HttpRequestService.postRequest("/threat_intelligence/opswat_scan_report/", params).then(function(d) {
            $('#opswat-scan-btn').addClass('saveicon');
            $('#opswat-scan-btn').removeClass('loadicon');
            if(d.status == 'success'){
                $scope.opswat_result = d.response.scan_report;
                $scope.detected = d.response.detected;
                $scope.detected_count = d.response.detected_count;
                $scope.total_count = d.response.total_count;
            }
            if (d.response.status == "error"){
                $('.validate-msg').text(d.response.message);
                $('.validate-msg').attr("style", "display: table;")
            }
        });
    }


}