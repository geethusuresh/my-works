'use strict';
var app = angular.module('casb', ['ngRoute','ng-fusioncharts','ui.router','gridstack-angular','ui.bootstrap','ui.select2','ngMessages', 'toggle-switch', 'darthwade.dwLoading']);

app.config(function($interpolateProvider)
{
$interpolateProvider.startSymbol('[[');
$interpolateProvider.endSymbol(']]');
})
app.config(['$routeProvider', '$locationProvider', function($routes, $location) {
}]);
app.config(['$httpProvider', function($httpProvider) {
$httpProvider.defaults.headers.common["X-Requested-With"] = 'XMLHttpRequest';
}]);

//cors config
app.config(function($httpProvider) {
  $httpProvider.defaults.useXDomain = true;
  // delete $httpProvider.defaults.headers.common['X-Requested-With'];
});


app.config(function($stateProvider, $urlRouterProvider, TEMPLATE_URL, $locationProvider) {
    $stateProvider   
    .state("my_dashboard",{
        url:'/',
        templateUrl:TEMPLATE_URL+'my_dashboard.html',
        controller:'MyController',
        params:{'filter': null,'host':null,'op':null,'op_status':null,'temp_widget':null}
    })     
    .state("intrusion_dashboard",{
        url:'/dashboard/intrusion/',
        templateUrl:TEMPLATE_URL+'intrusion_dashboard.html',
        controller:'IntrusionController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })
    .state("real_time_alert",{
        url:'/dashboard/alerts/real-time/',
        templateUrl:TEMPLATE_URL+'real_time_alerts_dashboard.html',
        controller:'IntrusionController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })
    .state("flow_dashboard", {
        url:'/dashboard/flow/',
        templateUrl: TEMPLATE_URL+'flow_dashboard.html',
        controller: 'FlowController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })   
    .state("ssh_dashboard", {
        url:'/dashboard/ssh/',
        templateUrl: TEMPLATE_URL+'ssh_dashboard.html',
        controller: 'SSHController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })
    .state("tls_dashboard", {
        url:'/dashboard/tls/',
        templateUrl: TEMPLATE_URL+'tls_dashboard.html',
        controller: 'TLSController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
      })
    .state("privacy_dashboard", {
        url:'/dashboard/privacy/',
        templateUrl: TEMPLATE_URL+'privacy_dashboard.html',
        controller: 'PrivacyController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
      })
    .state("file_dashboard", {
        url:'/dashboard/file/',
        templateUrl: TEMPLATE_URL+'file_dashboard.html',
        controller: 'QueryController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
      })
    .state("http_extended_dashboard", {
        url:'/dashboard/http_extended/?filter&host&op',
        templateUrl: TEMPLATE_URL+'http_extended_dashboard.html',
        controller: 'HttpExtendedController',
      })
    .state("proxy_dashboard", {
        url:'/dashboard/proxy',
        templateUrl: '/static/templates/casb/proxy_analyzer.html',
        controller: 'ProxyController',
    })
    .state("http_dashboard", {
        url:'/dashboard/http/',
        templateUrl: TEMPLATE_URL+'http_dashboard.html',
        controller: 'HttpController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })
    .state("test_dashboard", {
        url:'/dashboard/test/',
        templateUrl: TEMPLATE_URL+'test_dashboard.html',
        controller: 'TestController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })
    .state("alert_dashboard", {
        url:'/dashboard/alert/',
        templateUrl: TEMPLATE_URL+'alert_dashboard.html',
        controller: 'AlertsController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })
    .state("intrusion_prevention", {
        url:'/intrusion/prevention',
        templateUrl: TEMPLATE_URL+'IP_dashboard.html',
        controller: 'PreventionController',
        params:{'filter': null,'host':null,'op':null,'op_status':null}
    })
    .state("infra_dashboard", {
        url:'/dashboard/infra/?filter&host&op',
        templateUrl: TEMPLATE_URL+'infra_dashboard.html',
        controller: 'InfraController',
    })
    .state("two_factor_auth", {
        url:'/two_factor_auth/setup/',
        templateUrl: TEMPLATE_URL+'two_factor_setup.html',
        controller: 'FactorController',
    })
    .state("ip_intelligence", {
        url:'/ip/intelligence/',
        templateUrl: TEMPLATE_URL+'ip_intelligence.html',
        controller: 'IpIntelligenceController',
    })
    .state("virus_scan", {
        url:'/virus/scan/',
        templateUrl: TEMPLATE_URL+'virus_scan.html',
        controller: 'VirusScanController',
    })
    .state("profile_details", {
        url:'/profile/info',
        templateUrl: TEMPLATE_URL+'profile_info.html',
        controller: 'ProfileController',
        params:{'two_factor': null,'op_status':null}
    })
    .state("help", {
        url:'/help/',
        templateUrl: TEMPLATE_URL+'help.html',
        controller: 'HelpController',
    })
    .state("ibm_config", {
        url:'/admin/ibm-x-force/configurations/',
        templateUrl: TEMPLATE_URL+'ibm_config.html',
        controller: 'SettingsConfigController',
    })
    .state('ibm_config.detail', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'ibm_config_form.html',
                controller: 'SettingsConfigController',
            }
        },
    })
    .state("add_ibm_config", {
        url:'/admin/add/ibm-x-force/configurations/',
        templateUrl: TEMPLATE_URL+'ibm_config_form.html',
        controller: 'SettingsConfigController',
    })
    .state("virus_total_config", {
        url:'/admin/virus-total/configurations/',
        templateUrl: TEMPLATE_URL+'virus_total_config.html',
        controller: 'SettingsConfigController',
    })
    .state('virus_total_config.detail', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'virus_total_config_form.html',
                controller: 'SettingsConfigController',
            }
        },
    })
    .state("add_virus_total_config", {
        url:'/admin/add/virus-total/configurations/',
        templateUrl: TEMPLATE_URL+'virus_total_config_form.html',
        controller: 'SettingsConfigController',
    })
    .state("opswat_config", {
        url:'/admin/opswat/configurations/',
        templateUrl: TEMPLATE_URL+'opswat_config.html',
        controller: 'SettingsConfigController',
    })
    .state('opswat_config.detail', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'opswat_config_form.html',
                controller: 'SettingsConfigController',
            }
        },
    })
    .state("add_opswat_config", {
        url:'/admin/add/opswat/configurations/',
        templateUrl: TEMPLATE_URL+'opswat_config_form.html',
        controller: 'SettingsConfigController',
    })
    .state("severity", {
        url:'/admin/severity/',
        templateUrl: TEMPLATE_URL+'severity_list.html',
        controller: 'SeverityConfigController',
    })
    .state('severity.detailAsRoot', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'severity_form.html',
                controller: 'SeverityConfigController',
            }
        },
    })
    .state("nessus_config", {
        url:'/admin/nessus/configurations/',
        templateUrl: TEMPLATE_URL+'nessus_conf.html',
        controller: 'NessusController',
    })
    .state('nessus_config.detail', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'nessus_conf_form.html',
                controller: 'NessusController',
            }
        },
    })
    .state("add_nessus_config", {
        url:'/admin/add/nessus/configuration/',
        templateUrl: TEMPLATE_URL+'nessus_conf_form.html',
        controller: 'NessusController',
    })
    .state("azure_config", {
        url:'/admin/azure/configurations/',
        templateUrl: TEMPLATE_URL+'azure_conf.html',
        controller: 'AzureController',
    })
    .state('azure_config.detail', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'azure_conf_form.html',
                controller: 'AzureController',
            }
        },
    })
    .state("add_azure_config", {
        url:'/admin/add/azure/configuration/',
        templateUrl: TEMPLATE_URL+'azure_conf_form.html',
        controller: 'AzureController',
    })
    .state("openvas_config", {
        url:'/admin/openvas/configurations/',
        templateUrl: TEMPLATE_URL+'openvas_conf.html',
        controller: 'OpenvasController',
    })
    .state('openvas_config.detail', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'openvas_conf_form.html',
                controller: 'OpenvasController',
            }
        },
    })
    .state("add_openvas_config", {
        url:'/admin/add/openvas/configuration/',
        templateUrl: TEMPLATE_URL+'openvas_conf_form.html',
        controller: 'OpenvasController',
    })
    .state("add_severity", {
        url:'/admin/add/severity/',
        templateUrl: TEMPLATE_URL+'severity_form.html',
        controller: 'SeverityConfigController',
    })
    .state("http_traffic", {
        url:'/admin/http-traffic/',
        templateUrl: TEMPLATE_URL+'http_traffic_list.html',
        controller: 'HttpTrafficConfigController',
    })
    .state('http_traffic.detailAsRoot', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'http_traffic_form.html',
                controller: 'HttpTrafficConfigController',
            }
        },
    })
    .state("add_http_traffic", {
        url:'/admin/add/http-traffic/',
        templateUrl: TEMPLATE_URL+'http_traffic_form.html',
        controller: 'HttpTrafficConfigController',
    })
    .state("host_settings", {
        url:'/admin/host-settings/',
        templateUrl: TEMPLATE_URL+'host_settings_list.html',
        controller: 'HostSettingsConfigController',
    })
    .state('host_settings.detailAsRoot', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'host_settings_form.html',
                controller: 'HostSettingsConfigController',
            }
        },
    })
    .state("add_host_settings", {
        url:'/admin/add/host-settings/',
        templateUrl: TEMPLATE_URL+'host_settings_form.html',
        controller: 'HostSettingsConfigController',
    })
    .state("help_settings", {
        url:'/admin/help/',
        templateUrl: TEMPLATE_URL+'help_list.html',
        controller: 'HelpController',
    })
    .state('help_settings.detailAsRoot', {
        url: ':id/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'help_form.html',
                controller: 'HelpController',
            }
        },
    })
    .state("add_help", {
        url:'/admin/add/help/',
        templateUrl: TEMPLATE_URL+'help_form.html',
        controller: 'HelpController',
    })
    .state("settings", {
        url:'/settings/',
        templateUrl: TEMPLATE_URL+'settings.html',
        controller: 'SettingsController',
    })
    .state("nessus", {
        url:'/nessus/scans/',
        templateUrl: TEMPLATE_URL+'nessus.html',
        controller: 'NessusController',
    })
    .state('nessus.detail', {
        url: ':id/hosts/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'nessus_detail.html',
                controller: 'NessusController',
            }
        },
    })
    .state('nessus.detail.hostDetail', {
        url: ':host_id/vulnerabilities/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'nessus_host_detail.html',
                controller: 'NessusController',
            }
        },
    })
    .state("openvas", {
        url:'/openvas/scans/',
        templateUrl: TEMPLATE_URL+'openvas.html',
        controller: 'OpenvasController',
    })
    .state('openvas.detail', {
        url: ':id/vulnerabilities/',
        views: {
            '@': {
                templateUrl: TEMPLATE_URL+'openvas_host_detail.html',
                controller: 'OpenvasController',
            }
        },
    })
    .state("azure", {
        url:'/azure/',
        templateUrl: TEMPLATE_URL+'azure.html',
        controller: 'AzureController',
    });
    $urlRouterProvider.otherwise('/');    
});
