function PreventionController($scope,$http,$state,$stateParams,HttpRequestService){

    
    //pagination variables
    $scope.filteredalertdetails = []
    $scope.currentPage = 1
    $scope.numPerPage = 10
    $scope.maxSize = 5;
    $scope.entryLimit = 10;    

    $scope.timestamp = true;

    $scope.dash_heading = "Prevention Dashboard";    

    $scope.filter = $stateParams.filter;
    $scope.host_id = $stateParams.host;
    $scope.current_state = $state.current.name;
    $scope.filter_heading = "Alerts";  
    $scope.blocked_ips = [];  
    $scope.tab1 = true;
    $scope.tab2 = false;
    $scope.tab3 = false;
    $scope.error_prevention = false;
    $scope.severities = []
    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.priority = 0;
    $scope.severity = null;
    $scope.existing_preventions = [];
    $scope.hosts = []
    $scope.interval = 0
    $scope.timetypes = [
                    { name: 'Minutes', value: 'minutes' }, 
                    { name: 'Hour', value: 'hour' }
                    ];
    
    $scope.type = $scope.timetypes[0].value;
    
    if($stateParams.op_status == "unblock_success"){
        $scope.SuccessMessage = "IP has been successfully unblocked";                    
        $('#succss_box').show();
    }

    if($stateParams.op_status == "remove_ip_success"){
        $scope.SuccessMessage = "IP has been removed successfully";                    
        $('#succss_box').show();
    }

    if($stateParams.op_status == "remove_prevention_success"){
        $scope.SuccessMessage = "Prevention setting has been removed successfully";                    
        $('#succss_box').show();
    }

    if($stateParams.op_status == "adding_prevention_success"){
        $scope.SuccessMessage = "Prevention setting has been added successfully";                    
        $('#succss_box').show();
    }

    if($stateParams.op_status == "disable_prevention_success"){
        $scope.SuccessMessage = "Pevention has been successfully disabled";                    
        $('#succss_box').show();
    }

    if($stateParams.op_status == "enable__success"){
        $scope.SuccessMessage = "Pevention has been successfully enabled";                    
        $('#succss_box').show();
    }

    if($stateParams.op_status == "disable_auto_unblock_success"){
        $scope.SuccessMessage = "Auto unblock has been successfully disabled";                    
        $('#succss_box').show();
    }

    if($stateParams.op_status == "enable_auto_unblock_success"){
        $scope.SuccessMessage = "Auto unblock has been successfully enabled";                    
        $('#succss_box').show();
    }     

    if($stateParams.op_status == "unblock_success"){
        $scope.SuccessMessage = "IP has been successfully unblocked";                    
        $('#succss_box').show();
    }
    
    $scope.init = function(){
        
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'action':'',
        }
        HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d) {
            if(d.status == 'success'){
                console.log("ssss",d.response)
                $scope.blocked_ips = d.response.blocked_ips
                $scope.severities = d.response.severities
                $scope.existing_preventions = d.response.existing_preventions
                $scope.waiting_block = d.response.waiting_block
                $scope.waiting_unblock = d.response.waiting_unblock
                $scope.hosts = d.response.remaining_hosts
                
            }
        });
    }

    $scope.createSeverity = function(){
        $scope.priority = $("#priority").val();
        $scope.severity = $("#severity").val();
        if($scope.severity){
            params = {          
              'csrfmiddlewaretoken': $scope.csrf_token,
              'severity':$scope.severity,
              'priority': $scope.priority,
              'action':'create_severity',
            }
            HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d) {
                if(d.status == 'success'){
                    console.log("ssss",d.response)
                    $scope.existing_preventions = d.response.existing_preventions
                    $scope.severities = d.response.severities                    
                    $('#change_time').modal('hide')
                    document.getElementById('severity').value = '';
                    document.getElementById('priority').value = '';
                    $scope.SuccessMessage = "Severity has been successfully added";
                    $('#succss_box').show();                    
                }
                else if(d.status == 'error'){
                   $scope.ErrorMessage = "Some error occured. Please try again";
                   $('#error_box').show(); 
                }
            });   
        }
    }

    $scope.startPrevention = function(){
        if($scope.select2 && $scope.selected_host){
            var severities = []           
            console.log("asd",$scope.select2)
            params = {          
              'csrfmiddlewaretoken': $scope.csrf_token,
              'host':$scope.selected_host[0],
              'severities':$scope.select2,
              'action':'start_prevention',
            }

            HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d){                                
                if(d.response.status == 'success'){
                    $scope.existing_preventions = d.response.existing_preventions
                    if(d.response.prev_status == 'existing'){
                        $scope.prevention_message = "This prevention setting already exists";                        
                        $('#prevention_message').show();
                    }
                    else{
                        $state.go($state.current, {"op_status":"adding_prevention_success"}, {reload: true});
                    }
                }
                else if(d.response.status == 'error'){
                    $scope.ErrorMessage = "Some error occured. Please try again";
                    $('#error_box').show();
                }
            });
        }
    }


    $scope.enable_prevention = function(prev_id,action){        
        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'action':action,
            'prev_id':prev_id                             
        }
        bootbox.confirm("Are you sure. You want to "+action+" this prevention setting?", function(result) {
            if(result == true){
                HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d) {
                    if(d.status == 'success'){
                        $scope.existing_preventions = d.response.existing_preventions
                        if(d.response.status == "success"){
                            if(action == "disable"){
                                $state.go($state.current, {"op_status":"disable_prevention_success"}, {reload: true});
                            }
                            else if(action == "enable"){
                                $state.go($state.current, {"op_status":"enable_prevention_success"}, {reload: true});
                            }                       
                        }
                        else if(d.response.status == "error"){                       
                            $scope.ErrorMessage = "Some error occured. Please try after sometime";                       
                            $('#error_box').show();
                        }                                       
                    }
                    else if(d.status == "error"){
                        $scope.ErrorMessage = "Some error occured. Please try after sometime";                    
                        $('#error_box').show();
                    }             
                });
            }
        });                        
    }

    $scope.removePrevention = function(pre_id){
        bootbox.confirm("Are you sure. You want to delete this prevention settings?", function(result) {
            if(result == true){ 
                console.log('pree',pre_id);
                params = {          
                  'csrfmiddlewaretoken': $scope.csrf_token,
                  'action':'delete_prevention',
                  'prevention_id':pre_id,
                }
                HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d) {
                    if(d.status == 'success'){
                        $scope.existing_preventions = d.response.existing_preventions
                        $state.go($state.current, {"op_status":"remove_prevention_success"}, {reload: true});
                    }
                    else if(d.status == 'error'){
                        $scope.ErrorMessage = "Some error occured. Please try again";
                        $('#error_box').show();
                    }
                });
            }
        });
    }

    $scope.removeIP = function(pre_id){
        bootbox.confirm("Are you sure. You want to delete this IP?", function(result) {
            if(result == true){ 
                console.log('pree',pre_id);
                params = {          
                  'csrfmiddlewaretoken': $scope.csrf_token,
                  'action':'delete_waiting_block',
                  'ip_id':pre_id,
                }
                HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d) {
                    if(d.status == 'success'){                        
                        $scope.waiting_block = d.response.waiting_block;
                        $state.go($state.current, {"op_status":"remove_ip_success"}, {reload: true});
                    }
                    else if(d.status == 'error'){
                        $scope.ErrorMessage = "Some error occured. Please try again";
                        $('#error_box').show();
                    }
                });
            }
        });
    }

    $scope.unblock_ip = function(block_id){
        bootbox.confirm("Are you sure. You want to unblock this IP?", function(result) {
            if(result == true){ 
                params = {          
                  'csrfmiddlewaretoken': $scope.csrf_token,
                  'action':'unblock',
                  'unblock_id':block_id,
                }
                HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d) {
                    if(d.status == 'success'){
                        if(d.response.status == 'success'){                        
                            $scope.blocked_ips = d.response.blocked_ips;
                            $state.go($state.current, {"op_status":"unblock_success"}, {reload: true});
                        }
                        else if(d.response.status == 'error'){
                            $scope.ErrorMessage = "Some error occured. Please try again";
                            $('#error_box').show();
                        }
                    }
                    else if(d.status == 'error'){
                        $scope.ErrorMessage = "Some error occured. Please try again";
                        $('#error_box').show();
                    }
                });                
            }
        });
    }

    $scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {
         if ( ! $.fn.DataTable.isDataTable( '#blockedips' ) ) {
              $('#blockedips').DataTable({
                "bLengthChange": false,
                "bSort": false                
              });
        };        
    });

    $scope.$on('ipsSettingListFinished', function(ngRepeatListFinishedEvent) {        
        if (!$.fn.DataTable.isDataTable('#existingprev' )){
          $('#existingprev').DataTable({
            "bLengthChange": false,  
            "aaSorting": [],
            "bSort": false         
          }); 
        };
    });

    $scope.$on('ipsBlockWaitingListFinished', function(ngRepeatListFinishedEvent) {        
        if (!$.fn.DataTable.isDataTable('#waiting_blockip' )){
          $('#waiting_blockip').DataTable({
            "bLengthChange": false,  
            "aaSorting": [],
            "bSort": false         
          }); 
        };
    });

    $scope.$on('ipsUnblockWaitingListFinished', function(ngRepeatListFinishedEvent) {        
        if (!$.fn.DataTable.isDataTable('#waiting_unblockip' )){
          $('#waiting_unblockip').DataTable({
            "bLengthChange": false,  
            "aaSorting": [],
            "bSort": false         
          }); 
        };
    });
    
    $scope.disable_prev = function(id){        
        $('#btn_disable_'+id).toggleClass('enable-disable disabled-btn');
    }


    $scope.unblock_interval = function(duration, type){
        // debugger;
        if ($scope.auto_unblock ){
            var action = 'off';
        }
        else{
            var action = 'on';
        }
        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'action': action,
            'duration':duration,
            'type':type , 
            'prev_id':$scope.current_id                             
        }
                
        HttpRequestService.postRequest("/dashboard/intrusion_prevention",params).then(function(d) {
            if(d.status == 'success'){
                $scope.existing_preventions = d.response.existing_preventions
                if(d.response.status == "success"){
                    if(action == "off"){
                        $state.go($state.current, {"op_status":"disable_auto_unblock_success"}, {reload: true});
                    }
                    else if(action == "on"){
                        $state.go($state.current, {"op_status":"enable_auto_unblock_success"}, {reload: true});
                    }                       
                }
                else if(d.response.status == "error"){                       
                    $scope.ErrorMessage = "Some error occured. Please try after sometime";                       
                    $('#error_box').show();
                }                                       
            }
            else if(d.status == "error"){
                $scope.ErrorMessage = "Some error occured. Please try after sometime";                    
                $('#error_box').show();
            }             
        });
    }

    $scope.auto_unblock = function(prev_id, auto_unblock, action){ 
        bootbox.confirm("Are you sure. You want to "+action+" auto unblocking setting?", function(result) {
            if(result == true){
                $scope.current_id = prev_id
                $scope.auto_unblock = auto_unblock
                $("#unblock").modal()
            }
        });                        
    }
}