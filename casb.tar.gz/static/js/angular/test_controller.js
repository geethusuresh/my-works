function TestController($scope,$http,$state,$stateParams,HttpRequestService,$filter,$log,$location, $rootScope){
    $scope.AlertEventSource = {}
    $scope.AlertSignatures = {}
    $scope.AlertSiverity = []
    $scope.alertcategories = {}
    $scope.alertdetails = []
    $scope.alertdetails2 = []
    $scope.alerttrend = {}
    $scope.alertworld = {}
    $scope.alertusa = {}
    $scope.loading_image1 = false
    $scope.loading_image2 = false
    $scope.loading_image3 = false
    $scope.loading_image4 = false
    $scope.loading_image5 = false
    $scope.loading_image6 = false
    $scope.loading_image7 = false
    $scope.loading_image8 = false
    $scope.todos = []  

    $('#title_header').html("Test Dashboard");    

    $scope.filter = $stateParams.filter;
    $scope.operation = $stateParams.op;
    $scope.op_status = $stateParams.op_status;
    $scope.host_id = $stateParams.host;
    $scope.current_state = $state.current.name;    

    console.log($scope.filter);
    console.log($scope.operation);    

    $scope.filter_heading = "Alerts";

    if($scope.operation=="drag"){        
        $scope.widget_move = "true";
    }
    else{
      $scope.widget_move = "false";
    }

    if($scope.op_status == "success"){       
        $scope.SuccessMessage = "Dashboard has been successfully saved";
        $scope.succss_box = true;
        $scope.widget_move = "false";        
    }
    else if($scope.op_status == "error"){        
        $scope.ErrorMessage = "Not able to save dashboard details";
        $scope.error_box = true;
        $scope.widget_move = "false";        
    }
    else if($scope.op_status == "restored"){        
        $scope.SuccessMessage = "Dashboard has been successfully restored";
        $scope.succss_box = true;
        $scope.widget_move = "false";        
    }
    else if($scope.op_status == "not-restored"){        
        $scope.ErrorMessage = "Not able to restore dashboard";
        $scope.error_box = true;
        $scope.widget_move = "false";        
    }
    
    if($scope.filter && $scope.filter != 'date_range'){
      $scope.duration_selected = " Last " + filter_names($scope.filter);      
    }
    else if($scope.filter == 'date_range'){        
      $scope.duration_selected = "( " + $rootScope.custome_date.replace(" - "," to ") + " )"       
    }
    else{
      $scope.duration_selected = "Last 24 hours";
    }

    //Code for Drag and Drop
    $scope.options = {
        cellHeight: 75,
        verticalMargin: 5
    };

    $scope.widgets = []      

    $scope.addWidget = function() {
        var newWidget = { x:0, y:0, width:1, height:1 };
        $scope.widgets.push(newWidget);
    };

    $scope.removeWidget = function(w) {
        var index = $scope.widgets.indexOf(w);
        $scope.widgets.splice(index, 1);
    };

    $scope.onChange = function(event, items) {
        $log.log("onChange Start: "+items); 
    };

    $scope.onDragStart = function(event, ui) {
        $log.log("onDrag Start: "+ui);
    };

    $scope.onDragStop = function(event, ui) {        
        $log.log("onDragStop event: "+event+" ui:"+ui);
        $('#btn_save_dash').show();
    };

    $scope.onResizeStart = function(event, ui) {
        $log.log("onResize Start: "+ui);
    };

    $scope.onResizeStop = function(event, ui) {
       $log.log("onResizeStop item: "+ui);
       $('#btn_save_dash').show();
    };

    $scope.onItemAdded = function(item) {
        $log.log("onItemAdded item: "+item);
    };

    $scope.onItemRemoved = function(item) {
        $log.log("onItemRemoved item: "+item);
    };  
    //End Drag and Drop Code

    $scope.save_dashboard_changes = function(){        
        $('#btn_save_dash').button('loading');
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();        
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type':"Alert",
          'widgets':angular.toJson($scope.widgets)
        }
        HttpRequestService.postRequest("/dashboard/save_dashboard",params).then(function(d) {
            if(d.status == 'success'){
                if(d.response.status == "success"){                                               
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"success","op":""});
                }
                else{
                    $scope.ErrorMessage = "Unable to save dashboard changes";
                    $scope.error_box = true;
                }
            }
            else if(d.status == "error"){                            
              $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":""});
            }
            $('#btn_save_dash').button('reset');
            $('#btn_save_dash').hide();
        });
    }

    $scope.restore_dashboard = function(){
        $('#btn_restore').button("loading");
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type':"Alert"          
        }
        HttpRequestService.postRequest("/dashboard/restore_dashboard",params).then(function(d) {
            if(d.status == 'success'){
                if(d.response.status == 'success'){                                               
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"restored","op":""});
                }
                else{
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
                }
            }
            else if(d.status == "error"){                           
              $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
            }
            $('#btn_restore').button('reset');
            $('#btn_restore').hide();
        });
    }

    $scope.init = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        loading_overlay("show");

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type': "Alert"                   
        }

        HttpRequestService.postRequest("/dashboard/widget_details",params).then(function(d) {
            if(d.status == 'success'){                            
              $scope.widgets = d.response;                 
              loading_overlay("hide");              
            }
            else if(d.status == 'error'){
                loading_overlay("hide");
                $scope.ErrorMessage = "Unable to find any widget details";
                $scope.error_box = true;                               
            }
        });

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
        }
        HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
            if(d.status == 'success'){
                $scope.customer_host = d.response.host_item;
                $scope.hostip = d.response.hostip;                                
            }
        });
    }

    function setevents(scope_variable,to_hide){
      $scope[scope_variable] = {
                          renderComplete:function(evnt,data) {
                              $scope.$apply(function() {
                                  $scope[to_hide] = true;
                              });
                          }
                      }
    }

    $scope.$on('ngRepeatFinished', function(ngRepeatFinishedEvent) {
          new Switchery(document.getElementById('map-panel-switch'),{size:'small'});          
          $('#map-panel-switch').change(function(){
            var duration_info = $('#duration_info').val();      
            if($('#world_map').css("display")=="none"){
              $('#world_map').show();
              $('#usa_map').hide();
              $('#map_headings').html("World - "+duration_info);        
            }
            else if($('#usa_map').css("display")=="none"){
              $('#world_map').hide();
              $('#usa_map').show();
              $('#map_headings').html("USA - "+duration_info);
            }
          });     
          $('[data-toggle="tooltip"]').tooltip();              
    });

    $scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {
          $('#tbl_alert').DataTable({
            "bLengthChange": false,
            "scrollY": "530px",
            "scrollCollapse": true,
          });                       
    });

    $scope.alert_events = function(){          

          setevents('alert_rate','loading_image1');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_events",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          }
          HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
              if(d.status == 'success'){
                $scope.graph_details(d.response,'alert_events');
              }
              else{
                $scope.loading_image1 = true;
              }
          });
    }

    $scope.alert_signatures = function(){
            
            setevents('alert_signatures','loading_image5');
            params = {
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_signatures",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            }

            HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details(d.response,'alert_signatures');
                  if(d.response.length == 0){
                    $scope.loading_image5 = true;
                  }
                }
                else{
                  $scope.loading_image5 = true;
                }
            });
          
    }

    $scope.alert_siverity = function(){          
            
            setevents('alert_severity','loading_image6');
            params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_siverity",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            }

             HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details(d.response,'alert_siverity');
                  if(d.response.length == 0){
                    $scope.loading_image6 = true
                  }
                }
                else{
                  $scope.loading_image6 = true;
                }
            });
          
    }

    $scope.alert_categories = function(){          
            
            setevents('alert_category','loading_image7');
            params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_categories",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            }

            HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details(d.response,'alert_category');
                  if(d.response.length == 0){
                    $scope.loading_image7 = true
                  }
                }
                else{
                  $scope.loading_image7 = true;
                }
            });

          
    }

    $scope.alert_details = function(){          
            
            params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_details",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            }

            HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.alertdetails = d.response
                  $scope.alertdetails2 = d.response
                }
                $scope.loading_image8 = true
                // $scope.$watch("currentPage + numPerPage", function() {
                //     var begin = (($scope.currentPage - 1) * $scope.numPerPage)
                //     var end = begin + $scope.numPerPage;
                //     console.log(begin,end,"paging");
                //     $scope.filteredalertdetails = $scope.alertdetails.slice(begin, end);
                // });                
            });
    }

    $scope.alert_trend = function(){
      
      params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_trend",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
      }

      HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.alerttrend = d.response
                }
                $scope.loading_image2 = true
            });
    }

    $scope.alert_world = function(){
      
      setevents('map_world','loading_image3');

      params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_world",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
      }

      HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details(d.response,'alert_world');
                }
                else{
                  $scope.loading_image3 = true;
                }
            });
    }

    $scope.alert_usa = function(){
      
      setevents('map_usa','loading_image4');
      params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_usa",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
      }

      HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details(d.response,'alert_usa');
                }
                else{
                  $scope.loading_image3 = true;
                }
            });

    }

  $scope.graph_details = function(data_details,graph_type){

        if(graph_type == "alert_events"){                          
            
            $scope.AlertEventSource = {
               chart: {
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "No. of alerts",
                      "labelDisplay": "rotate",
                      "showValues": "0",
                      "labelStep":"10",
                      "slantLabels":"1",
                      "showLabels":"0",                      
                },
                "categories": [
                    {
                        "category": data_details.category
                    }
                ],
                "dataset": data_details.dataset,
            };
        }
        else if(graph_type == "alert_signatures"){
            $scope.AlertSignatures = {
                "chart": {                    
                    "useDataPlotColorForLabels": "1",
                    "theme": "zune",
                    "paletteColors": "#EED17F,#97CBE7,#074868,#B0D67A,#2C560A,#DD9D82",
                    "showlabels": "0",
                },
                "data":data_details
            }
        }
        else if(graph_type == "alert_siverity"){
            $scope.AlertSiverity = {
                "chart": {                                        
                    "theme": "zune",                    
                },
                "data":data_details
            }           
        }
        else if(graph_type == "alert_category"){
            $scope.alertcategories = {
                "chart": {                                        
                    "theme": "zune",
                    "useDataPlotColorForLabels": "1", 
                    //"showlabels": "0",                   
                },
                "data":data_details
            }           
        }
        else if(graph_type == "alert_world"){
              $scope.alertworld = {
                "chart": {                   
                    "theme": "zune",
                    "formatNumberScale": "0",
                    "numberSuffix": " Alerts",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Alerts"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Alerts"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Alerts"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 alerts"
                        }
                    ]
                },
                "data":data_details 
            }
        }
        else if(graph_type == "alert_usa"){ 
            $scope.alertusa = {
                "chart": {                    
                    "theme": "zune",
                    "formatNumberScale": "0",
                    "numberSuffix": " Alerts",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Alerts"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Alerts"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Alerts"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 alerts"
                        }
                    ]
                },
                "data":data_details 
            }           

        }
  }

  $scope.alert_events();
  $scope.alert_signatures();
  $scope.alert_siverity();
  $scope.alert_categories();
  $scope.alert_details();
  $scope.alert_trend();
  $scope.alert_world();
  $scope.alert_usa();  

}