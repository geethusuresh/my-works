function IntrusionController($scope,$http,$state,$stateParams,HttpRequestService,$filter,$log,$location, $modal, TEMPLATE_URL, $rootScope, $interval, $controller){
    angular.extend(this,$controller('MessageController', {$scope: $scope}));    

    $scope.AlertEventSource = {}
    $scope.AlertSignatures = {}
    $scope.AlertSiverity = []
    $scope.alertcategories = {}
    $scope.alertdetails = []
    $scope.alertdetails2 = []
    $scope.alerttrend = {}
    $scope.alertworld = {}
    $scope.alertusa = {}
    $scope.near_by_alerts = false
    $scope.time_interval = 10;
    $scope.alertLoading = true;
    $scope.loading_image1 = false
    $scope.loading_image2 = false
    $scope.loading_image3 = false
    $scope.loading_image4 = false
    $scope.loading_image5 = false
    $scope.loading_image6 = false
    $scope.loading_image7 = false
    $scope.loading_image8 = false
    $scope.loading_image_map = false
    $scope.realtime_btn = true;
    $scope.todos = []
    $scope.savedash_btn_flag = false;   
    $scope.graph_theme = $('#graph_theme').val(); 
    
    $scope.dash_heading = "Intrusion Analytics Dashboard";    

    $scope.filter = $stateParams.filter;
    $scope.operation = $stateParams.op;
    $scope.op_status = $stateParams.op_status;
    $scope.host_id = $stateParams.host;
    $scope.current_state = $state.current.name;    

    $scope.filter_heading = "Duration";

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

    if($scope.operation=="drag"){        
        $scope.widget_move = "true";
        $scope.realtime_btn = false;
    }
    else{
      $scope.widget_move = "false";
    }        
    
    if($scope.filter && $scope.filter != 'date_range'){
      $scope.duration_selected = " Last " + filter_names($scope.filter);      
    }
    else if($scope.filter == 'date_range'){        
      $scope.duration_selected = "( " + $rootScope.custome_date.replace(" - "," to ") + " )"    
    }
    else{
      $scope.duration_selected = "Last 24 hours";
    }

    //Code for Drag and Drop
    $scope.options = {
        cellHeight: 75,
        verticalMargin: 5
    };

    $scope.widgets = []      

    $scope.addWidget = function() {
        var newWidget = { x:0, y:0, width:1, height:1 };
        $scope.widgets.push(newWidget);
    };

    $scope.removeWidget = function(w) {
        var index = $scope.widgets.indexOf(w);
        $scope.widgets.splice(index, 1);
    };

    $scope.onChange = function(event, items) {
        $log.log("onChange Start: "+items); 
    };

    $scope.onDragStart = function(event, ui) {
        $log.log("onDrag Start: "+ui);
    };

    $scope.onDragStop = function(event, ui) {        
        $log.log("onDragStop event: "+event+" ui:"+ui);
        //$('#btn_save_dash').show();
        $scope.savedash_btn_flag = true; 
    };

    $scope.onResizeStart = function(event, ui) {
        $log.log("onResize Start: "+ui);
    };

    $scope.onResizeStop = function(event, ui) {
       $log.log("onResizeStop item: "+ui);
       //$('#btn_save_dash').show();
       $scope.savedash_btn_flag = true; 
    };

    $scope.onItemAdded = function(item) {
        $log.log("onItemAdded item: "+item);
    };

    $scope.onItemRemoved = function(item) {
        $log.log("onItemRemoved item: "+item);
    };  
    //End Drag and Drop Code

    $scope.save_dashboard_changes = function(){          

        $('#btn_save_dash').addClass('loadicon');
        $('#btn_save_dash').removeClass('saveicon');
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();        
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type':"Alert",
          'widgets':angular.toJson($scope.widgets)
        }
        HttpRequestService.postRequest("/dashboard/save_dashboard",params).then(function(d) {
            if(d.status == 'success'){
                if(d.response.status == "success"){                                               
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"success","op":""});
                }
                else{
                    $scope.ErrorMessage = "Unable to save dashboard changes";
                    $scope.error_box = true;
                }
            }
            else if(d.status == "error"){                            
              $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":""});
            }
            
            $('#btn_save_dash').addClass('saveicon');
            $('#btn_save_dash').removeClass('loadicon');
            $scope.savedash_btn_flag = false; 
        });
    }

    $scope.restore_dashboard = function(){
        $('#btn_restore').button("loading");
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type':"Alert"          
        }
        HttpRequestService.postRequest("/dashboard/restore_dashboard",params).then(function(d) {
            if(d.status == 'success'){
                if(d.response.status == 'success'){                                               
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"restored","op":""},{reload: true});
                }
                else{
                  $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
                }
            }
            else if(d.status == "error"){                           
              $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
            }
            $('#btn_restore').button('reset');
            $('#btn_restore').hide();
        });
    }

    $scope.init = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        loading_overlay("show");

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type': "Alert"                   
        }

        HttpRequestService.postRequest("/dashboard/widget_details",params).then(function(d) {
            if(d.status == 'success'){                            
              $scope.widgets = d.response;                 
              loading_overlay("hide");              
            }
            else if(d.status == 'error'){
                loading_overlay("hide");
                $scope.ErrorMessage = "Unable to find any widget details";
                $scope.error_box = true;                               
            }
        });

        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
        }
        HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
            if(d.status == 'success'){
                $scope.customer_host = d.response.host_item;
                $scope.hostip = d.response.hostip;                                
            }
        });
    }
    function setevents(scope_variable, to_hide, chart_item, current_spinner){
        $scope[scope_variable] = {
            renderComplete:function(evnt,data) {
              $scope.$apply(function() {
                  $scope[to_hide] = true;
              });
            },
            dataPlotClick: function (eventObj, dataObj) {
                $rootScope.startLoading(current_spinner);
                $scope.showModal = function(item) {
                    var modalInstance = $modal.open({
                      templateUrl: TEMPLATE_URL+'modal_popup.html',
                      controller: 'myModal',
                      backdrop: 'static',
                      keyboard: false,
                      // windowClass: 'my-dialog',
                      resolve: {
                        item: function(){
                          return item;
                        }
                      }
                    });
                };
                params = {
                    'csrfmiddlewaretoken': $scope.csrf_token,
                    'chart_item': chart_item,
                    'value': dataObj.categoryLabel,
                    'request_from': 'alert_dashboard',
                    'duration':$scope.filter,
                    'host':$scope.host_id,
                    'custome_date': $rootScope.custome_date,
                    'category' : dataObj.datasetName,
                    'optional_filter': angular.toJson($rootScope.filter_details)
                };

                HttpRequestService.postRequest("/dashboard/popup/list",params).then(function(d) {
                    if($rootScope.plot_click_counter == 0){
                        $scope.showModal(d.response);
                    }
                    $rootScope.plot_click_counter++;
                });
            },
            legendItemClicked: function (eventObj, dataObj) {
            }
        }
    }    

    $scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {
        if ( ! $.fn.DataTable.isDataTable( '#tbl_alert' ) ) {
          $('#tbl_alert').DataTable({
            "bLengthChange": false,
            "scrollY": "530px",
            "scrollCollapse": true,
          });
        }
    });

    $scope.$on('ngRepeatListFinishedGroup', function(ngRepeatListFinishedGroupEvent) {
        if ($.fn.DataTable.isDataTable('#tbl_srcip_group')) {  
            $('#tbl_srcip_group').DataTable().destroy()
        }

        if ($.fn.DataTable.isDataTable('#tbl_dest_group')) {  
            $('#tbl_dest_group').DataTable().destroy()
        }   
        
        if (!$.fn.DataTable.isDataTable('#tbl_sig_group')) {
          $('#tbl_sig_group').DataTable({
            "bLengthChange": false,
            "order": [[1, "desc" ]]           
          });
        }                    
    });

    $scope.$on('ngRepeatListFinishedSrc', function(ngRepeatListFinishedSrcEvent) {
        if ($.fn.DataTable.isDataTable('#tbl_sig_group')) {  
            $('#tbl_sig_group').DataTable().destroy()
        }

        if ($.fn.DataTable.isDataTable('#tbl_dest_group')) {  
            $('#tbl_dest_group').DataTable().destroy()
        } 

        if (!$.fn.DataTable.isDataTable('#tbl_srcip_group')) {
          $('#tbl_srcip_group').DataTable({
            "bLengthChange": false,
            "order": [[1, "desc" ]]           
          });
        }                     
    });

    $scope.$on('ngRepeatListFinishedDest', function(ngRepeatListFinishedDestEvent) {
        if ($.fn.DataTable.isDataTable('#tbl_sig_group')) {  
            $('#tbl_sig_group').DataTable().destroy()
        }

        if ($.fn.DataTable.isDataTable('#tbl_srcip_group')) {  
            $('#tbl_srcip_group').DataTable().destroy()
        }

        if (!$.fn.DataTable.isDataTable('#tbl_dest_group')) {
          $('#tbl_dest_group').DataTable({
            "bLengthChange": false,
            "order": [[1, "desc" ]]           
          });
        }

                       
    });

    $scope.event_group_selection = function(group_item,action,call_type){
        if(call_type != "init"){
            $scope.loading_image8 = false;
        }

        params = {
                    'csrfmiddlewaretoken': $scope.csrf_token,
                    'action': action,
                    'group_item':group_item,
                    'duration':$scope.filter,
                    'host':$scope.host_id,
                    'custome_date': $rootScope.custome_date,                    
                    'optional_filter': angular.toJson($rootScope.filter_details)
                };        

        $scope.entry_type = group_item;

        HttpRequestService.postRequest("/dashboard/event_group",params).then(function(d) {
            if(d.status == "success"){                
                if(group_item == "sig"){
                    $scope.sig_group_details = d.response;
                    $scope.sig_group_area = true;
                    $scope.srcip_group_area = false;
                    $scope.dest_group_area = false;
                }
                else if(group_item == "src_ip"){
                    $scope.srcip_group_details = d.response;
                    $scope.sig_group_area = false;
                    $scope.srcip_group_area = true;
                    $scope.dest_group_area = false;
                }
                else if(group_item == "dest_ip"){
                    $scope.dest_group_details = d.response;
                    $scope.sig_group_area = false;
                    $scope.srcip_group_area = false;
                    $scope.dest_group_area = true;
                }
                if(call_type != "init"){
                    $scope.loading_image8 = true;
                }
            }
        });
    }

    $scope.events_group_details =  function(event_details,event_type){
        loading_overlay("show");        
        var events_filter = {"event":event_details,"event_type":event_type}        
        events_filter = angular.toJson(events_filter)
        params = {
                    'csrfmiddlewaretoken': $scope.csrf_token,                    
                    'value': events_filter,
                    'request_from': 'events_grouping',
                    'duration':$scope.filter,
                    'host':$scope.host_id,
                    'custome_date': $rootScope.custome_date,                    
                    'optional_filter': angular.toJson($rootScope.filter_details)
                };
        HttpRequestService.postRequest("/dashboard/popup/list",params).then(function(d) {
            var item = d.response;
            loading_overlay("hide"); 
            if(item){           
                var modalInstance = $modal.open({
                  templateUrl: TEMPLATE_URL+'modal_popup.html',
                  controller: 'myModal',
                  backdrop: 'static',
                  keyboard: false,             
                  resolve: {
                    item: function(){
                      return item;
                    }
                  }
                });
            }                     
        });
    }

    $scope.alert_events = function(){

          setevents('alert_rate','loading_image1', 'alert_events', 'event_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_events",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
          }

          HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
              if(d.status == 'success'){
                $scope.graph_details_alert(d.response,'alert_events');
              }
              else{
                $scope.loading_image1 = true;
              }
          });
    }

    $scope.alert_signatures = function(){

            setevents('alert_signatures','loading_image5','alert_signatures', 'signature_spinner');
            params = {
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_signatures",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            'optional_filter': angular.toJson($rootScope.filter_details)
            }

            HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_alert(d.response,'alert_signatures');
                  if(d.response.length == 0){
                    $scope.loading_image5 = true;
                  }
                }
                else{
                  $scope.loading_image5 = true;
                }
            });

    }


    $scope.alert_siverity = function(){          
            
            setevents('alert_severity','loading_image6', 'alert_severity', 'siverity_spinner');
            params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_siverity",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            'optional_filter': angular.toJson($rootScope.filter_details)
            }

             HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_alert(d.response,'alert_siverity');
                  if(d.response.length == 0){
                    $scope.loading_image6 = true
                  }
                }
                else{
                  $scope.loading_image6 = true;
                }
            });          
    }

    $scope.alert_categories = function(){          
            
            setevents('alert_category','loading_image7','alert_categories', 'category_spinner');
            params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_categories",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            'optional_filter': angular.toJson($rootScope.filter_details)
            }

            HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_alert(d.response,'alert_category');
                  if(d.response.length == 0){
                    $scope.loading_image7 = true
                  }
                }
                else{
                  $scope.loading_image7 = true;
                }
            });
          
    }

    $scope.alert_details = function(){          
            
            params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"alert_details",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            'optional_filter': angular.toJson($rootScope.filter_details)
            }

            HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.alertdetails = d.response
                  $scope.alertdetails2 = d.response
                }
                $scope.loading_image8 = true
                // $scope.$watch("currentPage + numPerPage", function() {
                //     var begin = (($scope.currentPage - 1) * $scope.numPerPage)
                //     var end = begin + $scope.numPerPage;
                //     $scope.filteredalertdetails = $scope.alertdetails.slice(begin, end);
                // });                
            });
            // $('#tbl_alert').DataTable({
            // "bLengthChange": false,
            // "scrollY": "530px",
            // "scrollCollapse": true,
            // });  
    }

    // Real time Analytics
    $scope.real_time_init = function start() {
        $scope.filter = "5m";
        setevents('real_time_alert_signatures','loading_image5','alert_signatures', 'real_time_signature_spinner');
        setevents('real_time_alert_severity','loading_image5','alert_severity', 'real_time_siverity_spinner');
        $interval(function() {
          $scope.real_time_alert_details();
        }, 2000);
      }

    $scope.real_time_alert_details = function(){

        params = {
        'csrfmiddlewaretoken': $scope.csrf_token,
        }
        if ($scope.alertLoading){
            HttpRequestService.postRequest("/dashboard/real_time_alert", params).then(function(d) {
                if(d.status == 'success'){ 
                if (d.response){
                    if ($scope.alertLoading){
                        $scope.alertdetails = d.response.alert_details;
                        $scope.graph_details_alert(d.response.alert_severity,'alert_siverity');
                        $scope.graph_details_alert(d.response.alert_signature,'alert_signatures');
                    }
                }
                else{ $scope.no_alert = true; }

                }
                $scope.real_time_loading_image = true
            });
        }
    }


    $scope.NearByAlerts = function(time_stamp){
        $scope.loading_image8 = false;
        params = {
            'csrfmiddlewaretoken': $scope.csrf_token,
            'time_stamp': time_stamp,
            'time_interval': $scope.time_interval,
            'graph_type':"alert_details",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'custome_date': $rootScope.custome_date,
            'optional_filter': angular.toJson($rootScope.filter_details)
        }

        HttpRequestService.postRequest("/dashboard/near_by_alerts/",params).then(function(response) {
            if(response.status == 'success'){
                $scope.near_by_alerts_after = response.response.alert_details_after;
                $scope.near_by_alerts_before = response.response.alert_details_before;
                $scope.loading_image8 = true;
                $(".int-after").html($scope.time_interval);
                $(".int-before").html($scope.time_interval);
                if ($scope.time_interval == 10){ $( "#int-minus" ).addClass( "int-change-disable" ); }
                else{ $( "#int-minus" ).removeClass( "int-change-disable" ); }
                if ($scope.time_interval == 60){$( "#int-plus" ).addClass( "int-change-disable" ); }
                else{ $( "#int-plus" ).removeClass( "int-change-disable" ); }
            }
        });
    }

    $scope.AlertsNearBy = function(time_stamp){
        $scope.time_interval = 10;
        $scope.near_by_alerts_after = false;
        $scope.near_by_alerts_before = false;
        $scope.time_stamp = time_stamp;
        $scope.NearByAlerts($scope.time_stamp);
    }

    $scope.IncreaseInterval = function(){
        if ($scope.time_interval<51){
            $scope.time_interval = $scope.time_interval + 10;
            $scope.NearByAlerts($scope.time_stamp);
        }
    }

    $scope.DecreaseInterval = function(){
        if ($scope.time_interval>10){
            $scope.time_interval = $scope.time_interval - 10;
            $scope.NearByAlerts($scope.time_stamp);
        }
    }

    $scope.ResetInterval = function(){
        $scope.time_interval = 10;
        $scope.NearByAlerts($scope.time_stamp)
    }


    $scope.pauseAlertLoading = function(){
        $scope.alertLoading = false;
    }

    $scope.resumeAlertLoading = function(){
        $scope.alertLoading = true;
    }

    $scope.alert_trend = function(){
      
      params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_trend",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
      }

      HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.alerttrend = d.response
                }
                $scope.loading_image2 = true
            });
      $('[data-toggle="tooltip"]').tooltip();
    }

    $scope.alert_world = function(){      
      setevents('map_world','loading_image3');
      params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_world",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details)
      }

      HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_alert(d.response,'alert_world');                  
                  $scope.loading_image3 = true
                }
                else{                  
                  $scope.loading_image3 = true
                }
            });           
    }

    $scope.alert_usa = function(){      
      setevents('map_usa','loading_image_usa');
      params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_usa",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'custome_date': $rootScope.custome_date,
          'optional_filter': angular.toJson($rootScope.filter_details)
      }

      HttpRequestService.postRequest("/dashboard/alert_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_alert(d.response,'alert_usa');
                }
                else{                  
                  $scope.loading_image_usa = true
                }
            });
    }

  $scope.alert_map = function(){
       $scope.alert_world();
       $scope.alert_usa();
       if($('.switchery').length==0){
         new Switchery(document.getElementById('map-panel-switch-alert'),{size:'small'});          
          $('#map-panel-switch-alert').change(function(){
            var duration_info = $scope.duration_selected;      
            if($('#world_map_alert').css("display")=="none"){
              $('#world_map_alert').show();
              $('#usa_map_alert').hide();
              $('#map_headings_alert').html("World - "+duration_info);        
            }
            else if($('#usa_map_alert').css("display")=="none"){
              $('#world_map_alert').hide();
              $('#usa_map_alert').show();
              $('#map_headings_alert').html("USA - "+duration_info);
            }
          });
      }     
  }

  $scope.graph_details_alert = function(data_details, graph_type){

        if(graph_type == "alert_events"){                          
            
            $scope.AlertEventSource = {
               chart: {
                      "numberPrefix": "",
                      "theme": $scope.graph_theme,
                      "yAxisName": "No. of alerts",
                      "labelDisplay": "rotate",
                      "showValues": "0",
                      "labelStep":"10",
                      "slantLabels":"1",
                      "showLabels":"0",                      
                },
                "categories": [
                    {
                        "category": data_details.category
                    }
                ],
                "dataset": data_details.dataset,
            };
        }
        else if(graph_type == "alert_signatures"){
            $scope.AlertSignatures = {
                "chart": {                    
                    "useDataPlotColorForLabels": "1",
                    "theme": $scope.graph_theme,
                    "paletteColors": "#EED17F,#97CBE7,#074868,#B0D67A,#2C560A,#DD9D82",
                    "showlabels": "0",
                },
                "data":data_details
            }
        }
        else if(graph_type == "alert_siverity"){
            $scope.AlertSiverity = {
                "chart": {                                        
                    "theme": $scope.graph_theme,                    
                },
                "data":data_details
            }           
        }
        else if(graph_type == "alert_category"){
            $scope.alertcategories = {
                "chart": {                                        
                    "theme": $scope.graph_theme,
                    "useDataPlotColorForLabels": "1", 
                    //"showlabels": "0",                   
                },
                "data":data_details
            }           
        }
        else if(graph_type == "alert_world"){
              $scope.alertworld = {
                "chart": {                   
                    "theme": $scope.graph_theme,
                    "formatNumberScale": "0",
                    "numberSuffix": " Alerts",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Alerts"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Alerts"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Alerts"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 alerts"
                        }
                    ]
                },
                "data":data_details 
            }
        }
        else if(graph_type == "alert_usa"){ 
            $scope.alertusa = {
                "chart": {                    
                    "theme": $scope.graph_theme,
                    "formatNumberScale": "0",
                    "numberSuffix": " Alerts",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Alerts"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Alerts"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Alerts"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 alerts"
                        }
                    ]
                },
                "data":data_details 
            }           

        }
  }  

}