function SSHController($scope,$http, HttpRequestService, $stateParams, $state, $filter, $log, $location, $modal, TEMPLATE_URL, $rootScope, $controller){
    angular.extend(this,$controller('MessageController', {$scope: $scope}));

    $scope.SSHEventSource = {}
    $scope.sshclientversion = {}
    $scope.sshserverversion = {}
    $scope.ports = {}
    $scope.SSHServerProto = {}
    $scope.SSHClientProto = {}
    $scope.sshtransaction = []
    $scope.sshtrend = {}
    $scope.sshworld = {}
    $scope.sshusa = {}
    $scope.savedash_btn_flag = false;
    $scope.graph_theme = $('#graph_theme').val();
    
    $scope.dash_heading = "SSH Analytics Dashboard";

    $scope.filter = $stateParams.filter;
    $scope.operation = $stateParams.op;
    $scope.op_status = $stateParams.op_status;
    $scope.host_id = $stateParams.host;
    $scope.current_state = $state.current.name;
    $scope.filter_heading = "Duration"; 

    if($scope.operation=="drag"){        
        $scope.widget_move = "true";
    }
    else{
        $scope.widget_move = "false";
    }      


    if($scope.filter && $scope.filter != 'date_range'){
      $scope.duration_selected = " Last " + filter_names($scope.filter);      
    }
    else if($scope.filter == 'date_range'){        
      $scope.duration_selected = "( " + $rootScope.custome_date.replace(" - "," to ") + " )"       
    }
    else{
      $scope.duration_selected = "Last 24 hours";
    }

    //Code for Drag and Drop
    $scope.options = {
        cellHeight: 75,
        verticalMargin: 5
    };       

      $scope.addWidget = function() {
          var newWidget = { x:0, y:0, width:1, height:1 };
          $scope.widgets.push(newWidget);
      };

      $scope.removeWidget = function(w) {
          var index = $scope.widgets.indexOf(w);
          $scope.widgets.splice(index, 1);
      };

      $scope.onChange = function(event, items) {
          $log.log("onChange Start: "+items); 
      };

      $scope.onDragStart = function(event, ui) {
          $log.log("onDrag Start: "+ui);
      };

      $scope.onDragStop = function(event, ui) {        
          $log.log("onDragStop event: "+event+" ui:"+ui);
          //$('#btn_save_dash').show();
          $scope.savedash_btn_flag = true;
      };

      $scope.onResizeStart = function(event, ui) {
          $log.log("onResize Start: "+ui);
      };

      $scope.onResizeStop = function(event, ui) {
         $log.log("onResizeStop item: "+ui);
         //$('#btn_save_dash').show();
         $scope.savedash_btn_flag = true;
      };

      $scope.onItemAdded = function(item) {
          $log.log("onItemAdded item: "+item);
      };

      $scope.onItemRemoved = function(item) {
          $log.log("onItemRemoved item: "+item);
      };  
      //End Drag and Drop Code

      $scope.save_dashboard_changes = function(){        
          //$('#btn_save_dash').button('loading');
          $('#btn_save_dash').addClass('loadicon');
          $('#btn_save_dash').removeClass('saveicon');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();        
          params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'dash_type':"SSH",
            'widgets':angular.toJson($scope.widgets)
          }
          HttpRequestService.postRequest("/dashboard/save_dashboard",params).then(function(d) {
              if(d.status == 'success'){
                  if(d.response.status == "success"){                                               
                    $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"success","op":""});
                  }
                  else{
                      $scope.ErrorMessage = "Unable to save dashboard changes";
                      $scope.error_box = true;
                  }
              }
              else if(d.status == "error"){                            
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"error","op":""});
              }
              //$('#btn_save_dash').button('reset');
              //$('#btn_save_dash').hide();
              $('#btn_save_dash').addClass('saveicon');
              $('#btn_save_dash').removeClass('loadicon');
              $scope.savedash_btn_flag = false;
          });
      }

      $scope.restore_dashboard = function(){
          $('#btn_restore').button("loading");
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'dash_type':"SSH"          
          }
          HttpRequestService.postRequest("/dashboard/restore_dashboard",params).then(function(d) {
              if(d.status == 'success'){
                  if(d.response.status == 'success'){                                               
                    $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"restored","op":""},{reload: true});
                  }
                  else{
                    $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
                  }
              }
              else if(d.status == "error"){                           
                $state.go($state.current.name,{"filter":$scope.filter,"host":$scope.host_id,"op_status":"not-restored","op":""});
              }
              $('#btn_restore').button('reset');
              $('#btn_restore').hide();
          });
    }          


    function setevents(scope_variable, to_hide, chart_item, current_spinner){
        // call this function to register render complete event to graphs
        // pass scope variable for event and scope variable for hiding loading image
        // render complete event is used here to hide loading image
        
      $scope[scope_variable] = {
                          renderComplete:function(evnt,data) {
                              $scope.$apply(function() {
                                  $scope[to_hide] = true;
                              });
                          },
                          dataPlotClick: function (eventObj, dataObj) {
                            $rootScope.startLoading(current_spinner);
                            $scope.showModal = function(item) {
                                // console.log(item);
                                var modalInstance = $modal.open({
                                  templateUrl: TEMPLATE_URL+'modal_popup.html',
                                  controller: 'myModal',
                                  backdrop: 'static',
                                  keyboard: false,
                                  // windowClass: 'my-dialog',
                                  resolve: {
                                    item: function(){
                                      return item;
                                    }
                                  }
                                });
                            };
                            if (chart_item == 'ssh_events') {
                              value = (dataObj.toolText.split('@')[1]).trim();
                            }
                            else{
                              value = dataObj.categoryLabel;
                            }
                            
                            params = {          
                                'csrfmiddlewaretoken': $scope.csrf_token,
                                'chart_item': chart_item,
                                'value': value,
                                'request_from': 'ssh_dashboard',
                                'duration':$scope.filter,
                                'host':$scope.host_id,
                                'optional_filter': angular.toJson($rootScope.filter_details),
                                'custome_date': $rootScope.custome_date
                              }
                            HttpRequestService.postRequest("/dashboard/popup/list",params).then(function(d) {
                              if($rootScope.plot_click_counter == 0){
                                  $scope.showModal(d.response);
                              }
                              $rootScope.plot_click_counter++;
                            });
                            console.log('Chart clicked at ' + dataObj.categoryLabel);
                          }
                      }
    }

    

    $scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {
        if ( ! $.fn.DataTable.isDataTable( '#tbl_ssh' ) ) {
          $('#tbl_ssh').DataTable({
            "bLengthChange": false,
            "scrollY": "530px",
            "scrollCollapse": true,
          });
        }                       
    });      


     $scope.init = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

        loading_overlay("show");
        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dash_type': "SSH"                   
        }
        HttpRequestService.postRequest("/dashboard/widget_details",params).then(function(d) {
            if(d.status == 'success'){                            
              $scope.widgets = d.response;                 
              loading_overlay("hide");              
            }
            else if(d.status == 'error'){
                loading_overlay("hide");
                $scope.ErrorMessage = "Unable to find any widget details";
                $scope.error_box = true;                               
            }
        });


        params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'selected_host':$scope.host_id                    
        }
        HttpRequestService.postRequest("/dashboard/customer_host",params).then(function(d) {
            if(d.status == 'success'){
                $scope.customer_host = d.response.host_item;
                $scope.hostip = d.response.hostip; 
            }
        });
    }

    $scope.ssh_events = function(){          

          setevents('event_rate','loading_image1','ssh_events', 'ssh_event_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_events",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }

          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_ssh(d.response,'ssh_events');
                  if (d.response.length == 0){
                    $scope.loading_image1 = true;
                  }
                }
                else{
                  $scope.loading_image1 = true;
                }
            });
  }

  $scope.ssh_clientversion = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_clientversion",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }

          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.sshclientversion = d.response;
                }
                $scope.loading_image7 = true;
            });
  }

  $scope.ssh_serverversion = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_serverversion",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }

          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.ssh_serverversion = d.response;
                }
                $scope.loading_image8 = true;
            });
  }

   $scope.ssh_ports = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_ports",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }

          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.ports = d.response;
                }
                $scope.loading_image9 = true;
            });
  }

  $scope.ssh_server_protocol = function(){          

          setevents('event_server','loading_image5', 'ssh_server', 'ssh_server_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_server_protocol",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }

          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_ssh(d.response,"ssh_server_protocol");
                  if (d.response.length == 0){
                    $scope.loading_image5 = true;
                  }
                }
                else{
                  $scope.loading_image5 = true;
                }
            });
  }

  $scope.ssh_client_protocol = function(){

          setevents('event_client','loading_image6', 'ssh_client', 'ssh_client_spinner');
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_client_protocol",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }

          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_ssh(d.response,"ssh_client_protocol");
                  if (d.response.length == 0){
                    $scope.loading_image6 = true;
                  }
                }
                else{
                  $scope.loading_image6 = true;
                }
            });
  }

  $scope.ssh_transaction = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_transaction",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }

          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.sshtransaction = d.response;
                }               
                $scope.loading_image10 = true;
            });          
  }

  $scope.ssh_trend = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_trend",
          'duration':$scope.filter,
          'host':$scope.host_id,
          'optional_filter': angular.toJson($rootScope.filter_details),
          'custome_date': $rootScope.custome_date
          }
          HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.sshtrend = d.response;
                }
                $scope.loading_image2 = true;
            });
          $('[data-toggle="tooltip"]').tooltip();
  }

  $scope.ssh_world = function(){

        setevents('event_world','loading_image3');
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"ssh_world",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'optional_filter': angular.toJson($rootScope.filter_details),
            'custome_date': $rootScope.custome_date
        }

        HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_ssh(d.response,'ssh_world');
                  if (d.response.length == 0){
                    $scope.loading_image3 = true;
                  }
                }
                else{
                  $scope.loading_image3 = true;
                }

            });
  }

  $scope.ssh_usa = function(){

        setevents('event_usa','loading_image3');
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"ssh_usa",
            'duration':$scope.filter,
            'host':$scope.host_id,
            'optional_filter': angular.toJson($rootScope.filter_details),
            'custome_date': $rootScope.custome_date
        }

        HttpRequestService.postRequest("/dashboard/ssh_dash",params).then(function(d) {
                if(d.status == 'success'){
                  $scope.graph_details_ssh(d.response,'ssh_usa');
                  if (d.response.length == 0){
                    $scope.loading_image4 = true;
                  }
                }
                else{
                  $scope.loading_image4 = true;
                }
            });
  }

  $scope.graph_details_ssh = function(data_details,graph_type){
        if(graph_type == "ssh_events"){                           
            $scope.SSHEventSource = {
              chart: {                      
                      "numberPrefix": "",
                      "theme": $scope.graph_theme,
                      "yAxisName": "Events Count",
                      //"labelStep":"10",
                      "showValues": "0",
                      "labelDisplay": "rotate",
                      "slantLabels":"1",
                      "showLabels":"0"
                  },
                  data: data_details
            };
        }
        else if(graph_type == "ssh_server_protocol"){
            $scope.SSHServerProto = {
              "chart": {                    
                    "useDataPlotColorForLabels": "1",
                    "theme": $scope.graph_theme
                },
                "data":data_details
            };
        }
        else if(graph_type == "ssh_client_protocol"){
            $scope.SSHClientProto = {
              "chart": {                    
                    "useDataPlotColorForLabels": "1",
                    "theme": $scope.graph_theme
                },
                "data":data_details
            };
        }
        else if(graph_type == "ssh_world"){
            $scope.sshworld = {
                "chart": {                   
                    "theme": $scope.graph_theme,
                    "formatNumberScale": "0",
                    "numberSuffix": "",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Connections"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Connections"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Connections"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 Connections"
                        }
                    ]
                },
                "data":data_details 
            }
        }
        else if(graph_type == "ssh_usa"){ 
            $scope.sshusa = {
                "chart": {                    
                    "theme": $scope.graph_theme,
                    "formatNumberScale": "0",
                    "numberSuffix": "",
                    "nullEntityColor": "#8c8c8c",
                    "nullEntityAlpha": "50",
                    "hoverOnNull": "0",
                },
                "colorrange": {
                    "color": [
                        {
                            "minvalue": "0",
                            "maxvalue": "1000",
                            "code": "#abb20b",
                            "displayValue": "< 1000 Connections"
                        },
                        {
                            "minvalue": "1000",
                            "maxvalue": "10000",
                            "code": "#e2ba15",
                            "displayValue": "1000-10000 Connections"
                        },
                        {
                            "minvalue": "10000",
                            "maxvalue": "50000",
                            "code": "#f0900f", 
                            "displayValue": "10000-50000 Connections"
                        },
                        {
                            "minvalue": "50000",
                            "maxvalue": "10000000000000",                            
                            "code": "#e44a00",
                            "displayValue": "> 50000 Connections"
                        }
                    ]
                },
                "data":data_details 
            }
        }                            
  }

  
  $scope.ssh_map = function(){
    $scope.ssh_world();
    $scope.ssh_usa();
    new Switchery(document.getElementById('map-panel-switch-ssh'),{size:'small'});          
    $('#map-panel-switch-ssh').change(function(){
      var duration_info = $scope.duration_selected;      
      if($('#world_map_ssh').css("display")=="none"){
        $('#world_map_ssh').show();
        $('#usa_map_ssh').hide();
        $('#map_headings_ssh').html("World - "+duration_info);        
      }
      else if($('#usa_map_ssh').css("display")=="none"){
        $('#world_map_ssh').hide();
        $('#usa_map_ssh').show();
        $('#map_headings_ssh').html("USA - "+duration_info);
      }
    });          
  }

}