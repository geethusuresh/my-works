function filter_names(filter_info){
	if(filter_info.indexOf("m") >=0){
		filter_info = filter_info.replace("m", " Minutes"); 
	}
    else if(filter_info.indexOf("1h") >= 0){
        filter_info = filter_info.replace("h", " Hour"); 
    }
	else if(filter_info.indexOf("h") >= 0){
		filter_info = filter_info.replace("h", " Hours"); 
	}
	else if(filter_info.indexOf("d") >= 0){
		filter_info = filter_info.replace("d", " Days"); 
	}

	return filter_info
}

function tree_expansion(){
    var expand = $('#expand_op').val();
    if(expand=="expand"){
        expandAll();
        $('#expand').html('<img src="/static/images/collapse-icon.png"/>&nbsp;Collapse All');
        $('#expand_op').val('collapse');
    }
    else if(expand=="collapse"){
        collapseAll();
        $('#expand_op').val('expand');
        $('#expand').html('<img src="/static/images/expand-icon.png"/>&nbsp;Expand All');
    }
}

function settings_toggle(){    
    if($('#demo-set').hasClass('open')){
        $('#demo-set').removeClass('open');
    }
    else{
        $('#demo-set').addClass('open');
    }
}

function op_alertbox(box){
    $("."+box).hide(200);
}

function loading_overlay(op){
    if(op == "show"){
        $.LoadingOverlay("show",{
          "color":"rgb(255,255,255,0.4)",
          "fontawesome":"fa fa-spinner fa-spin",
          "zIndex":2000          
        });
    }
    else{
        $.LoadingOverlay("hide");
    }
}





