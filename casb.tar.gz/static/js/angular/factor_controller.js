function FactorController($scope,$http,$state,$stateParams,HttpRequestService,$filter,$log,$location){
	$scope.dash_heading = "Two Factor Authentication";
	$scope.step1 = true;
	$scope.error_box = false;
	$scope.succss_box = false;
	$scope.btn_next_show = true;
	$scope.btn_prev_show = false;
	$scope.btn_finish_show = false;

	$scope.two_factor_enabled = '';
	$scope.two_factor_setup = '';

	$scope.init = function(){
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
		params = {          
		    'csrfmiddlewaretoken': $scope.csrf_token		                        
		}
		loading_overlay("show");
		HttpRequestService.postRequest("/two_factor_auth/two_factor_check",params).then(function(d) {
	        if(d.status == 'success'){
	          if(d.response.status == "enabled"){
	          		$scope.two_factor_enabled = "true";
	          		$scope.enabled_method = d.response.method;
	          		loading_overlay("hide");
	          }
	          else if(d.response.status == "not-enabled"){
	          		$scope.two_factor_enabled = "false";
	          		loading_overlay("hide");          				
	          }
        	}       
    	});
	}

	$scope.auth_setup = function(){
		var step_id = $('#step_info').val();
		console.log(step_id);		
		if(step_id == "step1"){
			if($('input[name=auth_method]:checked').length<=0){ 				
				$scope.ErrorMessage = "Please select atleast one authentication method";          	
	            //$scope.error_box = true;
	            $('#error_box').show();
        	}
        	else{
        		var method_name = $('input[name=auth_method]:checked').val();
        		$scope.method_details = method_name; 
        		console.log(method_name);       		        		
        		if(method_name == "call"){        			       						        		
		          	$scope.step2_callblock = true;
		          	$scope.step2_smsblock = false;
		          	$scope.step2_googleblock = false;
        		}
        		else if(method_name == "sms"){        			        		
	          		$scope.step2_callblock = false;
	          		$scope.step2_smsblock = true;
	          		$scope.step2_googleblock = false;	
	          		
        		}
        		else if(method_name == "gauth"){        				        		
	          		$scope.step2_callblock = false;
	          		$scope.step2_smsblock = false;
	          		$scope.step2_googleblock = true; 
        		}
        		//$scope.error_box = false;
        		$('#error_box').hide();
		        $scope.ErrorMessage = "";
        		$('#step_info').val('step2');
        		$scope.step_modify('step2');        		       		        		
        	}						
		}
		else if(step_id == "step2"){
			$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
			console.log($scope.method_details);
			//$('#btn_next').button("loading");
			$('#next_btn').addClass('loadicon');
			$('#next_btn').removeClass('saveicon');
			//console.log($('#phone').val());
			if($scope.method_details == "sms"){
				$scope.phone_number = $('#phone').val();				
				if($scope.phone_validate($scope.phone_number)){				
			        params = {          
			          'csrfmiddlewaretoken': $scope.csrf_token,
			          'auth_method':$scope.method_details,
			          'otp_step':step_id,
			          'phone':$scope.phone_number                  
			        }
			        HttpRequestService.postRequest("/two_factor_auth/setup",params).then(function(d) {
			            if(d.status == 'success'){
			              if(d.response.status == "success"){
			              		$scope.SuccessMessage = "Token has been successfully sent to your phone";          	
	            				//$scope.succss_box = true;
	            				$('#succss_box').show();
	            				$scope.step3_sms = true;
		          				$scope.step3_call = false;
		          				$scope.step3_google = false;		          				
		          				$('#step_info').val('step3');
		          				$scope.step_modify('step3');		          				
			              }
			              else if(d.response.status == "error"){
			              		$scope.ErrorMessage = "Unable to generate token";
			              		//$scope.error_box = true;
			              		$('#error_box').show();
			              		$scope.step2_callblock = false;
		          				$scope.step2_smsblock = true;
		          				$scope.step2_googleblock = false;		          				
		          				$('#step_info').val('step2');
		          				$scope.step_modify('step2');		          				
			              }

			            }
			            else if(d.status == 'error'){			               
			                $scope.ErrorMessage = "Unable to generate token";
			                //$scope.error_box = true;
			                $('#error_box').show();
			                $scope.step2_callblock = false;
		          			$scope.step2_smsblock = true;
		          			$scope.step2_googleblock = false; 		          			
		          			$('#step_info').val('step2');
		          			$scope.step_modify('step2');		          			
			            }

			            $('#next_btn').addClass('saveicon');
						$('#next_btn').removeClass('loadicon');
			        });
				}
		    }
		    else if($scope.method_details == "call"){		    	
		    	$scope.phone_number = $('#phone_call').val();
		    	console.log($scope.phone_number);
		    	if($scope.phone_validate($scope.phone_number)){				
			        params = {          
			          'csrfmiddlewaretoken': $scope.csrf_token,
			          'auth_method':$scope.method_details,
			          'otp_step':step_id,
			          'phone':$scope.phone_number                  
			        }
			        HttpRequestService.postRequest("/two_factor_auth/setup",params).then(function(d) {
			            if(d.status == 'success'){
			              if(d.response.status == "success"){
			              		$scope.SuccessMessage = "We are calling you at your number with a token";          	
	            				//$scope.succss_box = true;
	            				$('#succss_box').show();
	            				$scope.step3_sms = false;
		          				$scope.step3_call = true;
		          				$scope.step3_google = false;		          				
		          				$('#step_info').val('step3');
		          				$scope.step_modify('step3');		          				
			              }
			              else if(d.response.status == "error"){
			              		$scope.ErrorMessage = "We unable to call you. Please try again";
			              		//$scope.error_box = true;
			              		$('#error_box').show();
			              		$scope.step2_callblock = true ;
		          				$scope.step2_smsblock = false;
		          				$scope.step2_googleblock = false;		          				
		          				$('#step_info').val('step2');
		          				$scope.step_modify('step2');		          				
			              }

			            }
			            else if(d.status == 'error'){			               
			                $scope.ErrorMessage = "We unable to call you. Please try again.";
			                //$scope.error_box = true;
			                $('#error_box').show();
			                $scope.step2_callblock = true;
		          			$scope.step2_smsblock = false;
		          			$scope.step2_googleblock = false; 		          			
		          			$('#step_info').val('step2');
		          			$scope.step_modify('step2');		          			
			            }

			           	$('#next_btn').addClass('saveicon');
						$('#next_btn').removeClass('loadicon');
			        });
				}
		    }
		    else if($scope.method_details == "gauth"){
		    	$scope.step3_sms = false;
  				$scope.step3_call = false;
  				$scope.step3_google = true;
		    	$('#step_info').val('step3');		    	
		    	$scope.step_modify('step3');
		    	$('#next_btn').addClass('saveicon');
				$('#next_btn').removeClass('loadicon');
		    }			
		}
		else if(step_id == "step3"){			
			$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
			//$('#btn_next').button("loading");
			$('#next_btn').addClass('loadicon');
			$('#next_btn').removeClass('saveicon');

			if($scope.method_details == "sms"){
				var token = $('#token').val();
			}
			else if($scope.method_details == "call"){
				var token = $('#token_call').val();
			}
			else if($scope.method_details == "gauth"){
				var token = $('#qrcode').val();
			}

			//Condition for SMS , call and gauth method							
			if($scope.token_validate(token)){
				params = {          
		          'csrfmiddlewaretoken': $scope.csrf_token,
		          'auth_method':$scope.method_details,
		          'otp_step':step_id,
		          'token':token                  
		        }
		        HttpRequestService.postRequest("/two_factor_auth/setup",params).then(function(d) {
		            if(d.status == 'success'){                            
		              //$scope.widgets = d.response;                 
		              //loading_overlay("hide");			              
		              if(d.response.status == "success"){
		              		$scope.SuccessMessage = "Your token has been successfully validated";          	
            				//$scope.succss_box = true;
            				$('#succss_box').show();
            				$scope.step4_finish = true;
	          				$('#step_info').val('step4');
	          				$scope.step_modify('step4');
	          				//return true;
		              }
		              else if(d.response.status == "error"){
		              		$scope.ErrorMessage = "Your entered token is incorrect";
		              		//$scope.error_box = true;
		              		$('#error_box').show();			              		
	          				$('#step_info').val('step3');
	          				$scope.step_modify('step3');
	          				//return false;
		              }
		            }
		            else if(d.status == 'error'){
		                //loading_overlay("hide");
		                $scope.ErrorMessage = "Unable to validate token";
		                //$scope.error_box = true;
		                $('#error_box').show();			                
	          			$('#step_info').val('step3');
	          			$scope.step_modify('step3');	          			
	          			//return false;
		            }
		            $('#next_btn').addClass('saveicon');
					$('#next_btn').removeClass('loadicon');
		        });
			}								
		}		
	}

	$scope.phone_validate = function(phone){		
		 if(phone != ""){            
            var er = /^-?[0-9]+$/;
            if(!er.test(phone)){               
                $scope.ErrorMessage = "Please enter a valid phone number";
			    //$scope.error_box = true;
			    $('#error_box').show();
			    //$('#btn_next').button("reset");
			    $('#next_btn').addClass('saveicon');
				$('#next_btn').removeClass('loadicon');
                return false;          
            }
            else{
              $scope.ErrorMessage = "";
			  //$scope.error_box = false;
			  $('#error_box').hide();
              return true;
            }
          }
          else{          
	         $scope.ErrorMessage = "Please enter a phone number with country code";
			 //$scope.error_box = true;
			 $('#error_box').show();
			 //$('#btn_next').button("reset");
			 $('#next_btn').addClass('saveicon');
			 $('#next_btn').removeClass('loadicon');
	         return false;   
          }
	}

	$scope.token_validate = function(token){
		var er = /^-?[0-9]+$/;      		
		if(!er.test(token)){
			$scope.ErrorMessage = "Please enter a valid token";
			//$scope.error_box = true;
			$('#error_box').show();
			//$('#btn_next').button("reset");
			$('#next_btn').addClass('saveicon');
			$('#next_btn').removeClass('loadicon');
            return false;           
		}
		else{
			$scope.ErrorMessage = "";
			//$scope.error_box = false;
			$('#error_box').hide();
            return true;
		}
	}

	$scope.step_modify = function(step_info){
		if(step_info == "step2"){		

			$('#tab-2').addClass('active');
        	$('#tab-1').removeClass('active');

        	$('#tab-header1').removeClass('active');
        	$('#tab-header1 a').removeAttr('data-toggle');

        	$('#tab-header2').addClass('active');
        	$('#tab-header2 a').attr('data-toggle','tab');
        	$scope.btn_prev_show = true;
		}
		else if(step_info == "step3"){			

			$('#tab-3').addClass('active');
        	$('#tab-2').removeClass('active');

        	$('#tab-header2').removeClass('active');
        	$('#tab-header2 a').removeAttr('data-toggle');

        	$('#tab-header3').addClass('active');
        	$('#tab-header3 a').attr('data-toggle','tab');
		}
		else if(step_info == "step4"){			

			$('#tab-4').addClass('active');
        	$('#tab-3').removeClass('active');

        	$('#tab-header3').removeClass('active');
        	$('#tab-header3 a').removeAttr('data-toggle');

        	$('#tab-header4').addClass('active');
        	$('#tab-header4 a').attr('data-toggle','tab');

			$scope.btn_next_show = false;
			$scope.btn_finish_show = true;
		}
	}

	$scope.auth_setup_previous = function(){
		var step_id = $('#step_info').val();
		if(step_id == "step2"){
			
			$('#step_info').val('step1');			
        	$('#tab-1').addClass('active');
        	$('#tab-2').removeClass('active');

        	$('#tab-header2').removeClass('active');
        	$('#tab-header2 a').removeAttr('data-toggle');

        	$('#tab-header1').addClass('active');
        	$('#tab-header1 a').attr('data-toggle','tab');
        	$scope.btn_prev_show = false;

		}
		else if(step_id == "step3"){
			$('#step_info').val('step2');
			
			$('#tab-2').addClass('active');
        	$('#tab-3').removeClass('active');

        	$('#tab-header3').removeClass('active');
        	$('#tab-header3 a').removeAttr('data-toggle');

        	$('#tab-header2').addClass('active');
        	$('#tab-header2 a').attr('data-toggle','tab');

		}
		else if(step_id == "step4"){
			$('#step_info').val('step3');			

			$('#tab-3').addClass('active');
        	$('#tab-4').removeClass('active');

        	$('#tab-header4').removeClass('active');
        	$('#tab-header4 a').removeAttr('data-toggle');

        	$('#tab-header3').addClass('active');
        	$('#tab-header3 a').attr('data-toggle','tab');

			$scope.btn_next_show = true;
			$scope.btn_finish_show = false;
		}
	}	

	$scope.two_factor_finish = function(){
		var step_id = $('#step_info').val();		
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
		if($scope.method_details == "sms" || $scope.method_details == "call" || $scope.method_details == "gauth"){
			params = {          
	          'csrfmiddlewaretoken': $scope.csrf_token,
	          'auth_method':$scope.method_details,
	          'otp_step':step_id,
	          'phone':$scope.phone_number			                        
	        }
	        if(step_id == "step4"){
		        HttpRequestService.postRequest("/two_factor_auth/setup",params).then(function(d) {
		            if(d.status == 'success'){
		              if(d.response.status == "success"){
		              		//$scope.SuccessMessage = "Two-factor authentication successfully enabled in your profile";          	
            				//$scope.succss_box = true; 
            				console.log($state.current.name);
	          				$state.go('profile_details',{"two_factor":"enabled"});
		              }
		              else if(d.response.status == "error"){
		              		$scope.ErrorMessage = "Unable to enable two-factor in your profile. Please try again";
		              		//$scope.error_box = true;
		              		$('#error_box').show();		              			          				
		              }
		            }
		            else if(d.status == 'error'){
		                //loading_overlay("hide");
		                $scope.ErrorMessage = "Unable to enable two-factor in your profile. Please try again";
		                //$scope.error_box = true;
		                $('#error_box').show();
		            }
		        });
		    }			        
		}		
	}

	$scope.disable_confirm = function(){
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
		params = {          
	          'csrfmiddlewaretoken': $scope.csrf_token
	    }
	    bootbox.confirm("Are you sure. You want to disable two factor authentication in your profile?", function(result) {
	    	if(result == true){
			    $('#btn_disable').button("loading");        
		        HttpRequestService.postRequest("/two_factor_auth/disable",params).then(function(d) {
		            if(d.status == 'success'){
		              if(d.response.status == "success"){
		              		$scope.SuccessMessage = "Two-factor authentication successfully disabled from your profile";          	
		    				//$scope.succss_box = true;
		    				$('#succss_box').show(); 
		    				console.log($state.current.name);
		    				$('#btn_disable').button("reset"); 
		      				$state.go($state.current.name, {},{reload: true});
		              }
		              else if(d.response.status == "error"){
		              		$scope.ErrorMessage = "Unable to disable two-factor authentication in your profile. Please try again";
		              		//$scope.error_box = true;
		              		$('#error_box').show();
		              		$('#btn_disable').button("reset");		          				
		              }

		            }
		            else if(d.status == 'error'){
		                //loading_overlay("hide");
		                $scope.ErrorMessage = "Unable to disable two-factor authentication in your profile. Please try again";
		                //$scope.error_box = true;
		                $('#error_box').show();
		                $('#btn_disable').button("reset");
		            }
		        });
			}
        });  
	}	
}