function ProxyController($scope, $http) {
	$scope.dash_heading = "CASB Proxy Analyzer Dashboard";
}