app.factory('HttpRequestService', function($http) {
  //factory for http get and post request
  //returns response data from request

  return {
    postRequest: function(url,params) {
      //function for post request

      return $http({
                  method: 'POST',
                  url: url,
                  data: $.param(params),
		          headers : {
		              'Content-Type' : 'application/x-www-form-urlencoded',
		          }
                }).then(function successCallback(response) {
                    
                    result = {}
                    result['status'] = 'success'
                    result['response'] = response.data
                    // console.log('resp',response)
                    return result

                  }, function errorCallback(response) {
                    // called asynchronously if an error occurs
                    // or server returns response with an error status.

                    result = {}
                    result['status'] = 'error'
                    return result

                  });
    }
  };
});

//Service for uploading an image
app.service('fileUpload', function ($http) {
    return {
      uploadFileToUrl : function(fd, uploadUrl){        
       
      return $http({
          method: 'POST',
          url: uploadUrl,
          data: fd,
          transformRequest: angular.identity,
          headers: {
              'Content-Type': undefined
          }
      }).success(function (response) {
          // Do stuff with you response
          result = {}
          result['response'] = response.data;
          return result
      })
      .error(function(response){
        result = {}
        result['response'] = {"status":"failed"}
        return result
      });  
          
    }
  };
});