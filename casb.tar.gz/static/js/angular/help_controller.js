function HelpController($scope, $http, $state, $stateParams, $sce, HttpRequestService){

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.helps = []

    $scope.Help = function(){
        $http.get("/dashboard/help").then(function(response) {
                $scope.helps = response.data;
            });
    }

    $scope.HelpSettings = function(){
        $http.get("/dashboard/help?admin=true").then(function(response) {
                $scope.helps = response.data;
            });
    }


    $scope.HelpDetails = function(){
        if ($stateParams.id){
            $http.get("/dashboard/help?id="+$stateParams.id).then(function(response) {
                    $scope.helps = response.data[0].fields;
                    $scope.help_id = response.data[0].pk;
                });
        }
        else { $scope.add = true; $scope.helps.publish = true; $scope.helps.sort_order = 0; }
    }


    $scope.HelpUpdate = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.helps.title){
            $('#help_title_error').attr('style', 'display: inline-block');
        }
        if (!$scope.helps.content){
            $('#help_content_error').attr('style', 'display: inline-block');
        }
        if (!$scope.helps.title || !$scope.helps.content){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': $stateParams.id,
          'title': $scope.helps.title,
          'content': $scope.helps.content,
          'publish': $scope.helps.publish,
          'sort_order': $scope.helps.sort_order,
        }
        HttpRequestService.postRequest("/dashboard/help", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Help content successfully updated", type: "success"},
                function(){ $state.go('help_settings', {}, {reload: true}); });
            }
        });
    }

    $scope.HelpDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/dashboard/delete_help/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Help content successfully deleted", type: "success"},
                function(){ $state.go('help_settings', {}, {reload: true}); });
            }
        });
    }

}

