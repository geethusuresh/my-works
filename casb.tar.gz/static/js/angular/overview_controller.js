function OverviewCtrl($scope,$http){
	//$scope.heading = 'OverView'	
	$scope.file_data = {};
	$scope.alert_event_source = {};
	$scope.flow_data = {};
	$scope.http_event_source = {};
	$scope.pri_event_source = {};
	$scope.ssh_event_source = {};
	$scope.tls_event_source = {};
	$scope.http_extended = {};
	$scope.alerttrend = {};
	$scope.file_trend = {};
	$scope.httptrend = {};
	$scope.sshtrend = {};
	$scope.tlstrend = {};
	$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
	$('#title_header').html("Overview Dashboard");

	$scope.fileData = function(){
		params = {          
	    'csrfmiddlewaretoken': $scope.csrf_token,
	    'type':"events_graph"
	    }    

		$http({
			  method: 'post',
	      	data: $.param(params),
			  url: '/dashboard/file_dash',
	      	headers : {
	              'Content-Type' : 'application/x-www-form-urlencoded'
	          }
			}).then(function successCallback(response) {			
				 $scope.file_data = {
		          "chart": {
		              "caption": "Events Over TIme",
		              "showvalues": "0",
		              "plotgradientcolor": "",
		              "formatnumberscale": "0",
		              "showplotborder": "0",              
		              "canvaspadding": "0",
		              "bgcolor": "FFFFFF",
		              "showalternatehgridcolor": "0",
		              "divlinecolor": "CCCCCC",
		              "showcanvasborder": "0",
		              "legendborderalpha": "0",	             
		              "canvasborderalpha": "0",
		              "showborder": "0",
		              "labelStep":"10",
		              "yAxisName": "Events Count",
		              "labelDisplay": "rotate",	              
	                  "slantLabels":"1",
		              "theme": "zune",	             
		          },
		          "categories": [
		              {
		                  "category": response.data.category
		              }
		          ],
		          "dataset": response.data.dataset
		      }	  
	      		

			  }, function errorCallback(response) {
			    // called asynchronously if an error occurs
			    // or server returns response with an error status.    

			  });
	}

	$scope.alertEventSource = function(){
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_events"
          }
          $http({
          method: "post",
          url: "/dashboard/alert_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){
        	$scope.alert_event_source = {
              chart: {
                      "caption": "Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Events Count",
                      "labelStep":"10",
                      "showValues": "0",
                      "labelDisplay": "rotate",
                      "slantLabels":"1"
                  },
                  data: data
            };
            // $scope.graph_details(data,'alert_events');
        }).error(function(data){
          console.log(data);         
        })
	}

	$scope.flowData = function(){
		params = {          
	    'csrfmiddlewaretoken': $scope.csrf_token,
	    'type':"events_graph"
	    }
	    $http({
	      method: 'post',
	      data: $.param(params),
	      url: '/dashboard/flow_dash',
	      headers : {
	              'Content-Type' : 'application/x-www-form-urlencoded'
	          }
	    }).then(function successCallback(response) {
	        // this callback will be called asynchronously
	        // when the response is available
	     $scope.flow_data = {
	          "chart": {
	              "caption": "HISTOGRAM",
	              "showvalues": "0",
	              "plotgradientcolor": "",
	              "formatnumberscale": "0",
	              "showplotborder": "0",	              
	              "canvaspadding": "0",
	              "bgcolor": "FFFFFF",
	              "showalternatehgridcolor": "0",
	              "divlinecolor": "CCCCCC",
	              "showcanvasborder": "0",
	              "legendborderalpha": "0",	              
	              "canvasborderalpha": "0",
	              "showborder": "0",
	              // "labelStep":"500",
	              "yAxisName": "Events Count",
	              "labelDisplay": "rotate",
	              "slantLabels":"1",
	              "theme": "zune"
	          },
	          "categories": [
	              {
	                  "category": response.data.category
	              }
	          ],
	          "dataset": response.data.dataset
	      }
	    
	      }, function errorCallback(response) {
	        // called asynchronously if an error occurs
	        // or server returns response with an error status.
	      });
	}

	$scope.httpEventSource = function(){
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"http_events"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){
        	$scope.http_event_source = {
              chart: {
                      "caption": "HTTP Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Events Count",
                      "labelStep":"10",
                      "showValues": "0",
                      "labelDisplay": "rotate",
                      "slantLabels":"1"
                  },
                  data: data
            };
        }).error(function(data){
          console.log(data);
        })

	}

	$scope.priEventSource = function(){
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"privacy_events"
          }
          $http({
          method: "post",
          url: "/dashboard/privacy_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){
        	$scope.pri_event_source = {
               chart: {
                      "caption": "Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Count",
                      "labelDisplay": "rotate",
                      "showValues": "0",
                      "slantLabels":"1",                      
                },
                "categories": [
                    {
                        "category": data.category
                    }
                ],
                "dataset": data.dataset
          };      
            // $scope.graph_details(data,'privacy_events');            
        }).error(function(data){
          console.log(data);  
          // $scope.graph_details(data,'privacy_events');       
        })
	}

	$scope.sshEventSource = function(){
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_events"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){
        	$scope.ssh_event_source = {
              chart: {
                      "caption": "Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Events Count",
                      "labelStep":"10",
                      "showValues": "0",
                      "labelDisplay": "rotate",
                      "slantLabels":"1"
                  },
                  data: data
            };          
        }).error(function(data){
          console.log(data);         
        })
	}

	$scope.tlsEventSource = function(){
		$scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_events"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){
	        $scope.tls_event_source = {
	            chart: {
	                    "caption": "Events Over Time",
	                    "subCaption": "",
	                    "numberPrefix": "",
	                    "theme": "zune",
	                    "yAxisName": "Events Count",
	                    "labelStep":"10",
	                    "showValues": "0",
	                    "labelDisplay": "rotate",
	                    "slantLabels":"1"
	                },
	                data: data
	          };
        }).error(function(data){
          console.log(data);         
        })
	}	

	$scope.alert_trend = function(){
	    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
	    params = {          
	        'csrfmiddlewaretoken': $scope.csrf_token,
	        'graph_type':"alert_trend"
	    }
	    $http({
	      method: "post",
	      url: "/dashboard/alert_dash",
	      data: $.param(params),
	      headers : {
	          'Content-Type' : 'application/x-www-form-urlencoded'
	      }
	    }).success(function(data){            
	        $scope.alerttrend = data;
	    }).error(function(data){
	      console.log(data);         
	    })
	  }

	$scope.trend = function(){
	    params = {          
	    'csrfmiddlewaretoken': $scope.csrf_token,
	    'type':"trend"
	    }
	    $http({
	      method: 'post',
	      data: $.param(params),
	      url: '/dashboard/file_dash',
	      headers : {
	              'Content-Type' : 'application/x-www-form-urlencoded'
	          }
	    }).then(function successCallback(response) {

	      $scope.file_trend = response.data.data
	      // $("#file_transaction").dataTable();
	        // this callback will be called asynchronously
	        // when the response is available
	        
	      }, function errorCallback(response) {
	        // called asynchronously if an error occurs
	        // or server returns response with an error status.
	      }); 
	  }

	$scope.http_trend = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"http_trend"
        }
        $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.httptrend = data;
        }).error(function(data){
          console.log(data);         
        })
      }

    $scope.ssh_trend = function(){          
	          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
	          params = {          
	          'csrfmiddlewaretoken': $scope.csrf_token,
	          'graph_type':"ssh_trend"
	          }
	          $http({
	          method: "post",
	          url: "/dashboard/ssh_dash",
	          data: $.param(params),

	          headers : {
	              'Content-Type' : 'application/x-www-form-urlencoded'
	          }
	        }).success(function(data){
	            console.log(data);            
	            $scope.sshtrend = data;            
	        }).error(function(data){
	          console.log(data);         
	        })
	  }

	$scope.tls_trend = function(){
        $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
        params = {          
            'csrfmiddlewaretoken': $scope.csrf_token,
            'graph_type':"tls_trend"
        }
        $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.tlstrend = data;
        }).error(function(data){
          console.log(data);         
        })
  	}
	//call alll methods
	$scope.fileData();
	$scope.alertEventSource();
	$scope.flowData();
	$scope.httpEventSource();
	$scope.sshEventSource();
	$scope.tlsEventSource();	
	$scope.priEventSource();	
	$scope.alert_trend();
	$scope.trend();
	$scope.http_trend();
	$scope.ssh_trend();
	$scope.tls_trend();
}