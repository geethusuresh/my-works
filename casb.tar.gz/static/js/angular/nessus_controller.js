function NessusController($scope, $http, $state, $stateParams, HttpRequestService){

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.nessus = []
    $scope.allScan = false;
    $scope.myScan = false;
    $scope.newScan = false;
    $scope.nessus_edit_scan = false;


    $scope.NessusScanList = function(scan_type){
        $scope.nessus_loading = true
        $scope.nessus_scan = false
        $scope.scheduledScan = false;
        $scope.nessus_new_scan = false
        $scope.allScan = false;
        $scope.myScan = false;
        $scope.newScan = false;
        $scope.scanEdit = true;
        $scope.nessus_scan_lists = true
        $('#conf_error').attr('style', 'display: none');
        $('#no_data').attr('style', 'display: table-row');
        if ($stateParams.id){
            url = "/vulnerability/nessus_scan?scan_id="+$stateParams.id
        }else if(scan_type == "all"){
            url = "/vulnerability/nessus_scan?type=all"
            $scope.allScan = true;
            $scope.scanEdit = false;
        }else{
            url = "/vulnerability/nessus_scan"
            $scope.myScan = true;
        }
        $http.get(url).then(function(response) {
                if (response.data.status == 'error'){
                    $('#conf_error').attr('style', 'display: table-row');
                    $('#no_data').attr('style', 'display: none');
                    return false;
                }
                if (!$scope.nessus_new_scan && !$scope.scheduledScan){$scope.nessus_scan = response.data; $scope.nessus_loading = false}
                if ($stateParams.id){
                    $scope.elapsed_time = Math.round(($scope.nessus_scan.info.scanner_end - $scope.nessus_scan.info.scan_start)/60);
                    $scope.vulnerabilityInfoCount = 0;
                    $scope.vulnerabilityLowCount = 0;
                    $scope.vulnerabilityMediumCount = 0;
                    $scope.vulnerabilityHighCount = 0;
                    $scope.vulnerabilityCriticalCount = 0;
                    for(i=0; i<$scope.nessus_scan.hosts.length; i++){
                        $scope.vulnerabilityInfoCount = $scope.vulnerabilityInfoCount + $scope.nessus_scan.hosts[i].info;
                        $scope.vulnerabilityLowCount = $scope.vulnerabilityLowCount + $scope.nessus_scan.hosts[i].low;
                        $scope.vulnerabilityMediumCount = $scope.vulnerabilityMediumCount + $scope.nessus_scan.hosts[i].medium;
                        $scope.vulnerabilityHighCount = $scope.vulnerabilityHighCount + $scope.nessus_scan.hosts[i].high;
                        $scope.vulnerabilityCriticalCount = $scope.vulnerabilityCriticalCount + $scope.nessus_scan.hosts[i].critical;
                    }
                    FusionCharts.ready(function () {
                        var revenueChart = new FusionCharts({
                            type: 'doughnut2d',
                            renderAt: 'chart-container',
                            width: '350',
                            height: '350',
                            dataFormat: 'json',
                            dataSource: {
                                "chart": {
                                    "numberPrefix": "",
                                    "paletteColors": "#0075c2,#1aaf5d,#f2c500,#EC707B,#D70303",
                                    "bgColor": "none",
                                    "showBorder": "0",
                                    "use3DLighting": "0",
                                    "showShadow": "0",
                                    "enableSmartLabels": "0",
                                    "startingAngle": "310",
                                    "showLabels": "0",
                                    "showPercentValues": "1",
                                    "showLegend": "1",
                                    "legendShadow": "0",
                                    "legendBorderAlpha": "0",
                                    "defaultCenterLabel": "Vulnerabilities",
                                    "centerLabel": "Vulnerabilities $label: $value",
                                    "centerLabelBold": "1",
                                    "showTooltip": "0",
                                    "decimals": "0",
                                    "captionFontSize": "14",
                                    "subcaptionFontSize": "14",
                                    "subcaptionFontBold": "0"
                                },
                                "data": [
                                    {
                                        "label": "Info",
                                        "value": $scope.vulnerabilityInfoCount
                                    },
                                    {
                                        "label": "Low",
                                        "value": $scope.vulnerabilityLowCount
                                    },
                                    {
                                        "label": "Medium",
                                        "value": $scope.vulnerabilityMediumCount
                                    },
                                    {
                                        "label": "High",
                                        "value": $scope.vulnerabilityHighCount
                                    },
                                    {
                                        "label": "Critical",
                                        "value": $scope.vulnerabilityCriticalCount
                                    }
                                ]
                            }
                        }).render();
                    });
                }
            });
    }

    $scope.NessusHostDetails = function(){
        $scope.nessus_scan_id = $stateParams.id
        url = "/vulnerability/nessus_host_details?scan_id="+$stateParams.id+"&host="+$stateParams.host_id
        $http.get(url).then(function(response) {
                $scope.nessus_host = response.data;
                var d1 = new Date($scope.nessus_host.info.host_start);
                var d2 = new Date($scope.nessus_host.info.host_end);
                $scope.elapsed_time = Math.round((d2-d1)/60000);
            });
        $http.get("/vulnerability/nessus_scan?scan_id="+$stateParams.id).then(function(response) {
                $scope.nessus_scan = response.data;
                for(i=0;i<$scope.nessus_scan.hosts.length; i++){
                    if($scope.nessus_scan.hosts[i].host_id == $stateParams.host_id){
                        $scope.vl_info = $scope.nessus_scan.hosts[i].info
                        $scope.vl_low = $scope.nessus_scan.hosts[i].low
                        $scope.vl_medium = $scope.nessus_scan.hosts[i].medium
                        $scope.vl_high = $scope.nessus_scan.hosts[i].high
                        $scope.vl_critical = $scope.nessus_scan.hosts[i].critical
                        FusionCharts.ready(function () {
                            var revenueChart = new FusionCharts({
                                type: 'doughnut2d',
                                renderAt: 'chart-container',
                                width: '350',
                                height: '350',
                                dataFormat: 'json',
                                dataSource: {
                                    "chart": {
                                        "numberPrefix": "",
                                        "paletteColors": "#0075c2,#1aaf5d,#f2c500,#EC707B,#D70303",
                                        "bgColor": "none",
                                        "showBorder": "0",
                                        "use3DLighting": "0",
                                        "showShadow": "0",
                                        "enableSmartLabels": "0",
                                        "startingAngle": "310",
                                        "showLabels": "0",
                                        "showPercentValues": "1",
                                        "showLegend": "1",
                                        "legendShadow": "0",
                                        "legendBorderAlpha": "0",
                                        "defaultCenterLabel": "Vulnerabilities",
                                        "centerLabel": "Vulnerability $label: $value",
                                        "centerLabelBold": "1",
                                        "showTooltip": "0",
                                        "decimals": "0",
                                        "captionFontSize": "14",
                                        "subcaptionFontSize": "14",
                                        "subcaptionFontBold": "0"
                                    },
                                    "data": [
                                        {
                                            "label": "Info",
                                            "value": $scope.vl_info
                                        },
                                        {
                                            "label": "Low",
                                            "value": $scope.vl_low
                                        },
                                        {
                                            "label": "Medium",
                                            "value": $scope.vl_medium
                                        },
                                        {
                                            "label": "High",
                                            "value": $scope.vl_high
                                        },
                                        {
                                            "label": "Critical",
                                            "value": $scope.vl_critical
                                        }
                                    ]
                                }
                            }).render();
                        });
                    }
                }
            });
    }

    $scope.NessusScan = function(){
        $('.scan-error-msg').attr('style', 'display: none')
        if (!$scope.name){
            $('#scan_name_error').attr('style', 'display: block');
        }
        if (!$scope.schedule_type){
            $('#schedule_type_error').attr('style', 'display: block');
        }
        if (!$scope.target){
            $('#target_error').attr('style', 'display: block');
        }
        if ($scope.target){
            var ip_array = $scope.target.split(",");
            for (var i = 0; i < ip_array.length; i++) {
                if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ip_array[i])){
                    // pass
                }else{
                    $('#ip_error').attr('style', 'display: block'); return false;
                }
            }
        }
        if ($scope.schedule_type == "once" && !$('#datetimepicker').val()){
            $('#schedule_date_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "daily" && !$('#timepicker').val()){
            $('#schedule_time_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "weekly" && !$scope.schedule_day){
            $('#schedule_day_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "weekly" && !$('#timepicker').val()){
            $('#schedule_time_error').attr('style', 'display: block'); return false;
        }
        if ($scope.schedule_type == "monthly" && !$('#daypicker').val()){
            $('#schedule_day_of_the_month_error').attr('style', 'display: block'); return false;
        }
        if (!$scope.name || !$scope.schedule_type || !$scope.target){
            return false;
        }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'name': $scope.name,
          'target': $scope.target,
          'schedule_type': $scope.schedule_type,
          'schedule_day': $scope.schedule_day,
          'schedule_date': $('#datetimepicker').val(),
          'schedule_day_of_the_month': $('#daypicker').val(),
          'schedule_time': $('#timepicker').val(),
        }
        if ($scope.nessus_edit_scan==true){
            params['scan_id'] = $scope.nessus_edit_scan_id
        }
        HttpRequestService.postRequest("/vulnerability/nessus_scan/", params).then(function(response) {
            if (response.response.status == 'error'){
                swal({title: "Error", text: response.response.message, type: "error"});
            }
            else{
                swal({title: "Success", text: "Scan details submitted successfully", type: "success"},
                function(){ $('#my_schedules').click(); });
            }
        });
    }

     $scope.NessusScheduledScans = function(type){
        $scope.nessus_new_scan = false;
        $scope.nessus_scan_lists = false;
        $scope.scheduledScan = true;
        if (type=='all'){
            url = "/vulnerability/nessus_scheduled_scans?type=all"
            $scope.scheduledScanEdit = false;
        }else{
            $scope.scheduledScanEdit = true;
            url = "/vulnerability/nessus_scheduled_scans"
        }
        $http.get(url).then(function(response) {
                if (!$scope.nessus_scan_lists){ $scope.nessus_schedules = response.data; }
            });
    }

    $scope.NessusScheduleEdit = function(schedule){
        $('#schedule_day_of_month').attr('style', 'display: none');
        $('#schedule_date').attr('style', 'display: none');
        $('#schedule_time').attr('style', 'display: none');
        $('#schedule_day').attr('style', 'display: none');
        $scope.scheduledScan = false;
        $scope.nessus_new_scan = true;
        $scope.nessus_edit_scan = true;
        $scope.nessus_edit_scan_id = schedule.pk
        $scope.name = schedule.fields.name
        $scope.target = schedule.fields.target
        $scope.schedule_type = schedule.fields.type
        $scope.schedule_day = schedule.fields.day
        $scope.schedule_date = schedule.fields.date_time
        $scope.schedule_day_of_the_month = schedule.fields.day_of_the_month+" "+schedule.fields.time
        $scope.schedule_time = schedule.fields.time
        if ($scope.schedule_type == 'once'){ $('#schedule_date').attr('style', 'display: block'); }
        else if ($scope.schedule_type == 'monthly'){ $('#schedule_day_of_month').attr('style', 'display: block'); }
        if ($scope.schedule_type == 'daily'){ $('#schedule_time').attr('style', 'display: block'); }
        if ($scope.schedule_type == 'weekly'){ $('#schedule_time').attr('style', 'display: block');
                                               $('#schedule_day').attr('style', 'display: block'); }
    }

    $scope.NessusNewScan = function(schedule){
        $('#schedule_day_of_month').attr('style', 'display: none');
        $('#schedule_date').attr('style', 'display: none');
        $('#schedule_time').attr('style', 'display: none');
        $('#schedule_day').attr('style', 'display: none');
        $scope.scheduledScan = false;
        $scope.nessus_new_scan = true;
        $scope.nessus_scan_lists = false;
        $scope.nessus_edit_scan = false;
        $scope.name = '';
        $scope.target = '';
        $scope.schedule_type = '';

    }

    $scope.NessusScanDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        swal({
          title: "Are you sure?",
          text: "You will not be able to recover this item!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Yes, delete it!",
          closeOnConfirm: false
        },
        function(){
            HttpRequestService.postRequest("/vulnerability/nessus_delete_scan/", params).then(function(response) {
                    if(response.status == 'success'){
                        swal({title: "Success", text: "Nessus schedule successfully deleted", type: "success"},
                        function(){ $state.go('nessus', {}, {reload: true}); });
                    }
                });
        });
    }

    $scope.NessusScheduleDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        swal({
          title: "Are you sure?",
          text: "You will not be able to recover this item!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Yes, delete it!",
          closeOnConfirm: false
        },
        function(){
            HttpRequestService.postRequest("/vulnerability/nessus_delete_schedule/", params).then(function(response) {
                    if(response.status == 'success'){
                        swal({title: "Success", text: "Nessus schedule successfully deleted", type: "success"},
                        function(){ $('#my_schedules').click(); });
                    }
                });
        });
    }


    // Nessus Config ################################
    $scope.nessus_conf = []

    $scope.NessusConf = function(){
        $http.get("/vulnerability/nessus_conf/").then(function(response) {
            if (response.data.error){$scope.nessus_conf = [];}
            else{ $scope.nessus_conf = response.data; }
            });
    }

    $scope.Customer = function(){
        $http.get("/dashboard/customer").then(function(response) {
                $scope.customer = response.data;
                if (!$stateParams.id){ $scope.nessus_conf.customer = response.data[0].pk;}
            });
    }

    $scope.NessusConfDetails = function(){
        if ($stateParams.id){
            $http.get("/vulnerability/nessus_conf?id="+$stateParams.id).then(function(response) {
                    $scope.nessus_conf = response.data[0].fields;
                    $scope.nessus_conf_id = response.data[0].pk;
                });
        }
        else { $scope.add = true }
    }


    $scope.NessusConfUpdate = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.nessus_conf.username){
            $('#username_error').attr('style', 'display: inline-block');
        }
        if (!$scope.nessus_conf.password){
            $('#password_error').attr('style', 'display: inline-block');
        }
        if (!$scope.nessus_conf.nessus_server_url){
            $('#server_error').attr('style', 'display: inline-block');
        }
        if (!$scope.nessus_conf.username || !$scope.nessus_conf.password || !$scope.nessus_conf.nessus_server_url){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': $stateParams.id,
          'customer': $scope.nessus_conf.customer,
          'username': $scope.nessus_conf.username,
          'password': $scope.nessus_conf.password,
          'server_url': $scope.nessus_conf.nessus_server_url,
        }
        HttpRequestService.postRequest("/vulnerability/nessus_conf/", params).then(function(response) {
            if(response.response.status == 'success'){
                swal({title: "Success", text: "Nessus configuration successfully updated", type: "success"},
                function(){ $('#nessus-cancel').click() });
            }else{ swal("Error!", response.response.message, "error"); }
        });
    }

    $scope.NessusConfDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/vulnerability/nessus_conf_delete/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Nessus configuration successfully deleted", type: "success"},
                function(){ $state.go('nessus_config', {}, {reload: true}); });
            }
        });
    }

}
