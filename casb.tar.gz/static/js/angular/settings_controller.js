function SettingsController($scope, $http, $state,$stateParams, HttpRequestService){


    $scope.timestamp = true;
    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();


    $scope.loadMenuSettings = function(){
        $http.get("/dashboard/menu_settings").then(function(response) {
                $scope.dashboards = getSortedKeys(response.data.dashboards);
                $scope.dashboard_list = response.data.dashboard_list;
                $scope.threat_intelligence = response.data.threat_intelligence;
                $scope.vulnerability = response.data.vulnerability;
                $scope.other_settings = response.data.other_settings;
                $scope.nessus_status = response.data.nessus_status;
                $scope.auto_refresh = response.data.auto_refresh;
                $scope.refresh_interval = response.data.refresh_interval;
                if($scope.auto_refresh){ $('.auto-refresh-interval').attr('style', 'display: block;'); }
            });
    }



    $scope.menuSettings = function(){
        $scope.dashboards_list = []
        $scope.threat_intelligence_list = []
        $scope.vulnerability_list = []
        $scope.other_settings_list = []
        $('form input:hidden[name=dashboards]').each(function()
        {
            $scope.dashboards_list.push($(this).val());
        });
        $('form input:checkbox[name=threat_intelligence]').each(function()
        {
            if($(this).is(':checked'))
                $scope.threat_intelligence_list.push($(this).val());
        });
        $('form input:checkbox[name=vulnerability]').each(function()
        {
            if($(this).is(':checked'))
                $scope.vulnerability_list.push($(this).val());
        });
        $('form input:checkbox[name=other_settings]').each(function()
        {
            if($(this).is(':checked'))
                $scope.other_settings_list.push($(this).val());
        });

        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'dashboards': $scope.dashboards_list,
          'threat_intelligence': $scope.threat_intelligence_list,
          'vulnerability': $scope.vulnerability_list,
          'other_settings': $scope.other_settings_list,
          'auto_refresh': $scope.auto_refresh,
          'refresh_interval': $scope.refresh_interval
        }
        HttpRequestService.postRequest("/dashboard/menu_settings", params).then(function(d) {
            if(d.response.status == 'success'){
                swal({title: "Success", text: "Dashboard settings has been updated", type: "success",
                closeOnConfirm: false}, function(){ location.reload(); });
            }
        });
    }


}

function getSortedKeys(obj) {
    var keys = []; for(var key in obj) keys.push(key);
    return keys.sort(function(a,b){return obj[a]-obj[b]});
}