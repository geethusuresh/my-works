function MessageController($scope,$http,$state,$stateParams,HttpRequestService){	
	if($stateParams.op_status == "watch-failed"){		
        $scope.ErrorMessage = "Not able to add entry to watchlist";
        $scope.error_box = true;
        $scope.widget_move = "false"; 
    }
    else if($stateParams.op_status == "watch-success"){
        $scope.SuccessMessage = "Entry has been successfully added to watchlist";
        $scope.succss_box = true;
        $scope.widget_move = "false"; 
    }
    else if($stateParams.op_status == "watch-exists"){
        $scope.ErrorMessage = "Selected entry has been already exists in watchlist";
        $scope.error_box = true;
        $scope.widget_move = "false"; 
    }
    else if($stateParams.op_status == "filter-delete"){        
        $scope.SuccessMessage = "Filter has been removed successfully";
        $scope.succss_box = true;
        $scope.widget_move = "false";        
    }
    else if($stateParams.op_status == "success"){       
        $scope.SuccessMessage = "Dashboard has been successfully saved";
        $scope.succss_box = true;
        $scope.widget_move = "false";        
    }
    else if($stateParams.op_status == "error"){        
        $scope.ErrorMessage = "Not able to save dashboard details";
        $scope.error_box = true;
        $scope.widget_move = "false";        
    }
    else if($stateParams.op_status == "restored"){        
        $scope.SuccessMessage = "Dashboard has been successfully restored";
        $scope.succss_box = true;
        $scope.widget_move = "false";        
    }
    else if($stateParams.op_status == "wat_del_success"){ 
        $scope.SuccessMessage = "Watchlist has beeen successfully deleted";
        $scope.succss_box = true;
        $scope.widget_move = "false"; 
    }
    else if($stateParams.op_status == "wat_del_failed"){
        $scope.ErrorMessage = "Unable to delete this watchlist";
        $scope.error_box = true;
        $scope.widget_move = "false";     
    }
    else if($stateParams.op_status == "filter-success"){ 
        $scope.SuccessMessage = "Filter has been saved successfully";
        $scope.succss_box = true;
        $scope.widget_move = "false"; 
    }
    else if($stateParams.op_status == "filter-failed"){
        $scope.ErrorMessage = "Not able to save filter";
        $scope.error_box = true;
        $scope.widget_move = "false";     
    }
    else if($stateParams.op_status == "pin-off-success"){
        $scope.SuccessMessage = "filter has been cleared from all dashboards";
        $scope.succss_box = true;
        $scope.widget_move = "false";     
    }
    else if($stateParams.op_status == "filter-apply-success"){ 
        $scope.SuccessMessage = "Filter has been applied successfully";
        $scope.succss_box = true;
        $scope.widget_move = "false"; 
    }
    else if($stateParams.op_status == "filter-apply-failed"){
        $scope.ErrorMessage = "Not able to apply the filter";
        $scope.error_box = true;
        $scope.widget_move = "false";     
    }
    else if($stateParams.op_status == "filter-remove-success"){ 
        $scope.SuccessMessage = "Filter has been removed successfully";
        $scope.succss_box = true;
        $scope.widget_move = "false"; 
    }
    else if($stateParams.op_status == "filter-remove-failed"){
        $scope.ErrorMessage = "Unable to remove the filter";
        $scope.error_box = true;
        $scope.widget_move = "false";     
    }	
}