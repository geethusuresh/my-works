// We define an Angular controller that returns query results,
// Inputs: $scope and the 'es' service

function HttpController($scope, $http){

      $scope.httpEventSource = {}
      $scope.httpAgentSource = {}
      $scope.httpMethod = {}
      $scope.hostnameDetails = {}
      $scope.httpstatusdetails = {}
      $scope.httpreferels = {}
      $scope.transaction_details = {}
      $scope.http_urls = {}
      $scope.http_status_code = {}     
      $scope.http_events = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"http_events"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'http_events');
        }).error(function(data){
          console.log(data);
        })
      }

      $scope.http_useragent = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"http_useragent"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'http_useragent');
        }).error(function(data){
          console.log(data);                  
        })
      }

      $scope.http_method = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"http_method"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'http_method');
        }).error(function(data){
          console.log(data);                  
        })
      }

      $scope.http_hostname = function(){       
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"http_hostname"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.hostnameDetails = data;
        }).error(function(data){
          console.log(data);                  
        })
      }

      $scope.http_status = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"http_status"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.httpstatusdetails = data;
        }).error(function(data){
          console.log(data);                  
        })
      }      

      $scope.http_referels = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"http_referels"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.httpreferels = data;
            console.log($scope.httpreferels);
        }).error(function(data){
          console.log(data);                  
        })
      }

      $scope.httpURL = function(){
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'type':"http_url"
          }
          $http({
            method: 'post',
            data: $.param(params),
            url: '/dashboard/http_extended_dash',
            headers : {
                    'Content-Type' : 'application/x-www-form-urlencoded'
                }
          }).then(function successCallback(response) {
            $scope.http_urls = response.data.data                     
          }, function errorCallback(response) {
              // called asynchronously if an error occurs
              // or server returns response with an error status.
          });
      }

      $scope.transaction_details = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"transaction_details"
          }
          $http({
          method: "post",
          url: "/dashboard/http_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.transaction_details = data;
            console.log($scope.transaction_details);
        }).error(function(data){
          console.log(data);                  
        })
    }
     
      $scope.graph_details = function(data_details,graph_type){
        if(graph_type == "http_events"){                           
            $scope.httpEventSource = {
              chart: {
                      "caption": "HTTP Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Events Count",
                      "labelStep":"10",
                      "showValues": "0",
                      "labelDisplay": "rotate",
                      "slantLabels":"1"
                  },
                  data: data_details
            };
        }
        else if(graph_type == "http_useragent"){
            $scope.httpAgentSource = {
                    "chart": {
                        "caption": "HTTP User Agents",
                        "useDataPlotColorForLabels": "1",
                        "theme": "zune"
                    },
                    "data":data_details
                }
        }
        else if(graph_type == "http_method"){
            $scope.httpMethod = {
                    "chart": {
                        "caption": "HTTP Method",
                        "useDataPlotColorForLabels": "1",
                        "theme": "zune"
                    },
                    "data":data_details
            }
        }        
    }

    $scope.http_events();
    $scope.http_useragent();    
    $scope.http_method();
    $scope.http_hostname();
    $scope.http_status();
    $scope.http_referels();
    $scope.httpURL();    
    $scope.transaction_details();
}


function AlertsController($scope,$http){
    $scope.AlertEventSource = {}
    $scope.AlertSignatures = {}
    $scope.AlertSiverity = {}
    $scope.alertcategories = {}
    $scope.alertdetails = {}
    $scope.alert_events = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_events"
          }
          $http({
          method: "post",
          url: "/dashboard/alert_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'alert_events');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.alert_signatures = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_signatures"
          }
          $http({
          method: "post",
          url: "/dashboard/alert_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'alert_signatures');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.alert_siverity = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_siverity"
          }
          $http({
          method: "post",
          url: "/dashboard/alert_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'alert_siverity');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.alert_categories = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_categories"
          }
          $http({
          method: "post",
          url: "/dashboard/alert_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.alertcategories = data
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.alert_details = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"alert_details"
          }
          $http({
          method: "post",
          url: "/dashboard/alert_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.alertdetails = data
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.graph_details = function(data_details,graph_type){
        if(graph_type == "alert_events"){                           
            $scope.AlertEventSource = {
              chart: {
                      "caption": "Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Events Count",
                      "labelStep":"10",
                      "showValues": "0",
                      "labelDisplay": "rotate",
                      "slantLabels":"1"
                  },
                  data: data_details
            };
        }
        else if(graph_type == "alert_signatures"){
            $scope.AlertSignatures = {
                "chart": {
                    "caption": "Alert Signatures",
                    "useDataPlotColorForLabels": "1",
                    "theme": "zune"
                },
                "data":data_details
            }
        }
        else if(graph_type == "alert_siverity"){
            $scope.AlertSiverity = {
                "chart": {
                    "caption": "Alert Severity",
                    "useDataPlotColorForLabels": "1",
                    "theme": "zune"
                },
                "data":data_details
            }
        }                
  }

  $scope.alert_events();
  $scope.alert_signatures();
  $scope.alert_siverity();
  $scope.alert_categories();
  $scope.alert_details();
}

function SSHController($scope,$http){
    $scope.SSHEventSource = {}
    $scope.sshclientversion = {}
    $scope.sshserverversion = {}
    $scope.ports = {}
    $scope.SSHServerProto = {}
    $scope.SSHClientProto = {}
    $scope.sshtransaction = {}
    $scope.ssh_events = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_events"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'ssh_events');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.ssh_clientversion = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_clientversion"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.sshclientversion = data;
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.ssh_serverversion = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_serverversion"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.ssh_serverversion = data;
        }).error(function(data){
          console.log(data);         
        })
  }

   $scope.ssh_ports = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_ports"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.ports = data;
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.ssh_server_protocol = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_server_protocol"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,"ssh_server_protocol");
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.ssh_client_protocol = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_client_protocol"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,"ssh_client_protocol");
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.ssh_transaction = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"ssh_transaction"
          }
          $http({
          method: "post",
          url: "/dashboard/ssh_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){
            console.log(data);            
            $scope.sshtransaction = data;            
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.graph_details = function(data_details,graph_type){
        if(graph_type == "ssh_events"){                           
            $scope.SSHEventSource = {
              chart: {
                      "caption": "Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Events Count",
                      "labelStep":"10",
                      "showValues": "0",
                      "labelDisplay": "rotate",
                      "slantLabels":"1"
                  },
                  data: data_details
            };
        }
        else if(graph_type == "ssh_server_protocol"){
            $scope.SSHServerProto = {
              "chart": {
                    "caption": "SSH Server Protocol",
                    "useDataPlotColorForLabels": "1",
                    "theme": "zune"
                },
                "data":data_details
            };
        }
        else if(graph_type == "ssh_client_protocol"){
            $scope.SSHClientProto = {
              "chart": {
                    "caption": "SSH Client Protocol",
                    "useDataPlotColorForLabels": "1",
                    "theme": "zune"
                },
                "data":data_details
            };
        }                         
  }

  $scope.ssh_events();
  $scope.ssh_clientversion();
  $scope.ssh_serverversion();
  $scope.ssh_ports();
  $scope.ssh_server_protocol();
  $scope.ssh_client_protocol();
  $scope.ssh_transaction();
}

function TLSController($scope,$http){
  $scope.TLSEventSource = {}
  $scope.tls_subject_info = {}
  $scope.tls_dn_info = {}
  $scope.TLSVersionInfo = {}
  $scope.TLSFinger = {}
  $scope.TCPPortsInfo = {}
  $scope.TLSTransaction = {}
  $scope.tls_events = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_events"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'tls_events');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.tls_subject = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_subject"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.tls_subject_info = data;
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.tls_issuerdn = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_issuerdn"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.tls_dn_info = data;
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.tls_version = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_version"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'tls_version');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.tls_fingerprint = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_finger"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'tls_finger');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.tls_ports = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_ports"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'tls_ports');
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.tls_transaction = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"tls_transaction"
          }
          $http({
          method: "post",
          url: "/dashboard/tls_dash",
          data: $.param(params),

          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.TLSTransaction = data;            
        }).error(function(data){
          console.log(data);         
        })
  }

  $scope.graph_details = function(data_details,graph_type){
      if(graph_type == "tls_events"){                           
          $scope.TLSEventSource = {
            chart: {
                    "caption": "Events Over Time",
                    "subCaption": "",
                    "numberPrefix": "",
                    "theme": "zune",
                    "yAxisName": "Events Count",
                    "labelStep":"10",
                    "showValues": "0",
                    "labelDisplay": "rotate",
                    "slantLabels":"1"
                },
                data: data_details
          };
      }
      else if(graph_type == "tls_version"){
          $scope.TLSVersionInfo = {
              "chart": {
                    "caption": "TLS Version",
                    "useDataPlotColorForLabels": "1",
                    "theme": "zune"
                },
                "data":data_details
          };
      }
      else if(graph_type == "tls_finger"){
          $scope.TLSFinger = {
              chart: {
                      "caption": "TLS Finger Print",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Finger Print Count",
                      "labelDisplay": "rotate",
                      "showValues": "0",
                      "slantLabels":"1",
                      "paletteColors": "#EED17F,#97CBE7,#074868,#B0D67A,#2C560A,#DD9D82"
                  },
                  data: data_details
          };
      }
      else if(graph_type == "tls_ports"){
          $scope.TCPPortsInfo = {
              "chart": {
                    "caption": "TLS TCP Ports",
                    "useDataPlotColorForLabels": "1",
                    "theme": "zune"
                },
                "data":data_details
          };
      }                              
  }

  $scope.tls_events();
  $scope.tls_subject();
  $scope.tls_issuerdn();
  $scope.tls_version();
  $scope.tls_fingerprint();
  $scope.tls_ports();
  $scope.tls_transaction();
}

function PrivacyController($scope,$http){
    $scope.PriEventSource = {}
    $scope.PriFacebook = {}
    $scope.PriTwitter = {}
    $scope.PriAnalytics = {}
    $scope.PriHostname = {}
    $scope.PriDocuments = {}
    $scope.privacy_events = function(){          
          $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
          params = {          
          'csrfmiddlewaretoken': $scope.csrf_token,
          'graph_type':"privacy_events"
          }
          $http({
          method: "post",
          url: "/dashboard/privacy_dash",
          data: $.param(params),
          headers : {
              'Content-Type' : 'application/x-www-form-urlencoded'
          }
        }).success(function(data){            
            $scope.graph_details(data,'privacy_events');            
        }).error(function(data){
          console.log(data);  
          $scope.graph_details(data,'privacy_events');       
        })
  }

  $scope.facebook_events = function(){
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
      'csrfmiddlewaretoken': $scope.csrf_token,
      'graph_type':"facebook"
      }
      $http({
      method: "post",
      url: "/dashboard/privacy_dash",
      data: $.param(params),
      headers : {
          'Content-Type' : 'application/x-www-form-urlencoded'
      }
    }).success(function(data){            
       $scope.PriFacebook = data;            
    }).error(function(data){
      console.log(data);
    })
  }

  $scope.twitter_events = function(){
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
      'csrfmiddlewaretoken': $scope.csrf_token,
      'graph_type':"twitter"
      }
      $http({
      method: "post",
      url: "/dashboard/privacy_dash",
      data: $.param(params),
      headers : {
          'Content-Type' : 'application/x-www-form-urlencoded'
      }
    }).success(function(data){            
       $scope.PriTwitter = data;            
    }).error(function(data){
      console.log(data);
    })
  }

  $scope.analytics_events = function(){
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
      'csrfmiddlewaretoken': $scope.csrf_token,
      'graph_type':"analytics"
      }
      $http({
      method: "post",
      url: "/dashboard/privacy_dash",
      data: $.param(params),
      headers : {
          'Content-Type' : 'application/x-www-form-urlencoded'
      }
    }).success(function(data){            
       $scope.PriAnalytics = data;            
    }).error(function(data){
      console.log(data);
    })
  }

  $scope.http_hostname = function(){
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
      'csrfmiddlewaretoken': $scope.csrf_token,
      'graph_type':"hostname"
      }
      $http({
      method: "post",
      url: "/dashboard/privacy_dash",
      data: $.param(params),
      headers : {
          'Content-Type' : 'application/x-www-form-urlencoded'
      }
    }).success(function(data){            
       $scope.PriHostname = data;            
    }).error(function(data){
      console.log(data);
    })
  }

  $scope.privacy_documents = function(){
      $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
      params = {          
      'csrfmiddlewaretoken': $scope.csrf_token,
      'graph_type':"documents"
      }
      $http({
      method: "post",
      url: "/dashboard/privacy_dash",
      data: $.param(params),
      headers : {
          'Content-Type' : 'application/x-www-form-urlencoded'
      }
    }).success(function(data){            
       $scope.PriDocuments = data;
       console.log(data);            
    }).error(function(data){
      console.log(data);
    })
  }   
  
  $scope.graph_details = function(data_details,graph_type){     
      if(graph_type == "privacy_events"){
          $scope.PriEventSource = {
               chart: {
                      "caption": "Events Over Time",
                      "subCaption": "",
                      "numberPrefix": "",
                      "theme": "zune",
                      "yAxisName": "Count",
                      "labelDisplay": "rotate",
                      "showValues": "0",
                      "slantLabels":"1",                      
                },
                "categories": [
                    {
                        "category": data_details.category
                    }
                ],
                "dataset": data_details.dataset
          };
      }
  }

  $scope.privacy_events();
  $scope.facebook_events();
  $scope.twitter_events();
  $scope.analytics_events(); 
  $scope.http_hostname();
  $scope.privacy_documents();
}



