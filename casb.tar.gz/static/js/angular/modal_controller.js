function myModal($scope, $modalInstance, $stateParams, item, $filter, $rootScope) {
    $scope.data = "hi"
    $scope.message = "hi"
    $scope.popup_details = item
    $scope.keys = $scope.popup_details.keys   
    $scope.details = []
    temp = []
    for(item in $scope.popup_details.body){
      temp_list = []
      for(key in $scope.keys){        
        temp_var = $scope.keys[key].split('.')
        //console.log(temp_var)
        if(temp_var.length == 1){
          if(temp_var=='timestamp'){
//            converted_time = $filter('date')($scope.popup_details.body[item]._source[temp_var], "MM-dd-yyyy HH:mm:ss")
            converted_time = $scope.popup_details.body[item]._source[temp_var]
            temp_list.push({"data":converted_time,"type":temp_var[0]})
          }
          else{
            temp_list.push({"data":$scope.popup_details.body[item]._source[temp_var],"type":temp_var[0]})
          }
        }
        else{
          if(typeof $scope.popup_details.body[item]._source[temp_var[0]] === "undefined")
          {
            temp_list.push({"data":'',"type":temp_var[0]})
          }
          else{
            temp_list.push({"data":$scope.popup_details.body[item]._source[temp_var[0]][temp_var[1]],"type":temp_var[1]})
          }
        }
      }
      $scope.details.push(temp_list)
    }
    
    $scope.$on('ngRepeatListFinished', function(ngRepeatListFinishedEvent) {
        if (!$.fn.DataTable.isDataTable('#tbl_popup' )) {
            $('#tbl_popup').DataTable({
              "bLengthChange": false,
              "scrollY": "530px",
              "scrollCollapse": true,
            });
        }
    });



    $scope.ok = function() {
      // $modalInstance.close($scope.selected.item);
      $modalInstance.close();
    };

    $scope.cancel = function() {
      // $modalInstance.dismiss('cancel');
      $modalInstance.dismiss();
      //multiple modal generation fix
      $rootScope.plot_click_counter = 0;
    };

  }
