function HostSettingsConfigController($scope, $http, $state, $stateParams, HttpRequestService){

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();
    $scope.host_settings = []

    $scope.HostSettings = function(){
        $http.get("/dashboard/host_settings").then(function(response) {
            if (response.data.error){$scope.host_settings = [];}
            else{ $scope.host_settings = response.data; }
            });
    }

    $scope.Customer = function(){
        $http.get("/dashboard/customer").then(function(response) {
                $scope.customer = response.data;
                if (!$stateParams.id){  $scope.host_settings.customer = response.data[0].pk; }
            });
    }

    $scope.Cloud = function(){
        $http.get("/dashboard/cloud").then(function(response) {
                $scope.clouds = response.data;
                $scope.host_settings.cloud = $scope.host_settings.cloud;
            });
    }

    $scope.HostSettingsDetails = function(){
        if ($stateParams.id){
            $http.get("/dashboard/host_settings?id="+$stateParams.id).then(function(response) {
                    $scope.host_settings = response.data[0].fields;
                    $scope.host_settings_id = response.data[0].pk;
                });
        }
        else { $scope.add = true }
    }


    $scope.HostSettingsUpdate = function($event){
        $('.validate-msg').attr('style', 'display: none');
        if (!$scope.host_settings.host){
            $('#host_setting_host').attr('style', 'display: inline-block');
        }
        if (!$scope.host_settings.customer){
            $('#host_setting_customer').attr('style', 'display: inline-block');
        }
        if (!$scope.host_settings.hostname){
            $('#host_setting_name').attr('style', 'display: inline-block');
        }
        if (!$scope.host_settings.ip){
            $('#host_setting_ip').attr('style', 'display: inline-block');
        }
        if (!$scope.host_settings.host || !$scope.host_settings.customer || !$scope.host_settings.hostname || !$scope.host_settings.ip){ return false; }
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': $stateParams.id,
          'customer': $scope.host_settings.customer,
          'host': $scope.host_settings.host,
          'hostname': $scope.host_settings.hostname,
          'ip': $scope.host_settings.ip,
          'cloud': $scope.host_settings.cloud,
        }
        HttpRequestService.postRequest("/dashboard/host_settings", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Host setting successfully updated", type: "success"},
                function(){ $state.go('host_settings', {}, {reload: true}); });
            }
        });
    }

    $scope.HostSettingsDelete = function(id){
        params = {
          'csrfmiddlewaretoken': $scope.csrf_token,
          'id': id,
        }
        HttpRequestService.postRequest("/dashboard/delete_host_settings/", params).then(function(response) {
            if(response.status == 'success'){
                swal({title: "Success", text: "Host setting successfully deleted", type: "success"},
                function(){ $state.go('host_settings', {}, {reload: true}); });
            }
        });
    }

}


