/**
* Styleswitch stylesheet switcher built on jQuery
* Under an Attribution, Share Alike License
* By Kelvin Luck ( http://www.kelvinluck.com/ )
**/

(function($)
{
	$(document).ready(function() {
		$('.styleswitch').click(function()
		{
			switchStylestyle(this.getAttribute("rel"));
			user_themeinfo(this.getAttribute("rel"));
			return false;
		});
		//var c = readCookie('style');
		//if (c) switchStylestyle(c);
	});

	function switchStylestyle(styleName)
	{
		$('link[rel*=style][title]').each(function(i) 
		{
			this.disabled = true;
			if (this.getAttribute('title') == styleName) this.disabled = false;
		});

		//updating graph theme based on casb theme
		if(styleName=="dark"){
			$('#graph_theme').val('carbon');
		}
		else{
			$('#graph_theme').val('zune');
		}
		//End updating graph theme

		//createCookie('style', styleName, 365);
	}
})(jQuery);
// cookie functions http://www.quirksmode.org/js/cookies.html
function createCookie(name,value,days)
{
	if (days)
	{
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}
function readCookie(name)
{
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++)
	{
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}
function eraseCookie(name)
{
	createCookie(name,"",-1);
}
// /cookie functions


//function for store theme details to database
function user_themeinfo(theme_info){
	var csrf = $('input[name="csrfmiddlewaretoken"]').val(); 	
	$.ajax({
      url:"/dashboard/profile_details",
      type: "POST", 
      dataType:"json",
      data: {
        csrfmiddlewaretoken: csrf,                    
        action: 'theme',
        theme: theme_info
      },
      success: function(data){
      	 if(data.status == "success"){
      	 	$('#msg_box_success strong').html('Your CASB+ theme has been successfully changed');
      	 	$('#msg_box_success').show(); 
      	 }
      	 else{
      	 	$('#msg_box_error strong').html('Unable to change your CASB+ theme');
      	 	$('#msg_box_error').show();
      	 }
      },
      error: function(data){
      		$('#msg_box_error strong').html('Some error occured. Please try after sometime');
      	 	$('#msg_box_error').show();
      }
	});
}