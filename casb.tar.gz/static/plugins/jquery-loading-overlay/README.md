# jQuery LoadingOverlay

A flexible loading overlay jQuery plugin

---

Documentation and examples at http://gasparesganga.com/labs/jquery-loading-overlay/
