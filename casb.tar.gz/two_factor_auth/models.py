from django.db import models
from django.contrib.auth.models import User
from dashboard.models import UserProfile, Customer 
from django import forms
from hashlib import md5
from django.db.models.signals import post_save
import datetime

options=((3,"Google Auth"),
        (1, "call"),
        (2, "sms"),
        (4,"sms or whatsapp"))


class TwofactorSetup(models.Model):
	user = models.ForeignKey(UserProfile,null=True, blank=True)
	method = models.PositiveIntegerField(choices=options, null=True, blank=True)
	phone = models.TextField(null=True, blank=True)	
	secret = models.TextField(null=True, blank=True)
	active = models.NullBooleanField(default=True)

	def __str__(self):
		return self.user.user.username

	class Meta:
		verbose_name_plural = "Two Factor Setup"
