from django.contrib import admin

# Register your models here.
from two_factor_auth.models import TwofactorSetup

admin.site.register(TwofactorSetup)
