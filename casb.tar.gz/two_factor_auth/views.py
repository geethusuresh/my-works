from django.shortcuts import render_to_response, render
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.template import RequestContext
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.views.decorators.cache import cache_control
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.models import User
from django.core.serializers.json import DjangoJSONEncoder
from django.core import serializers
from getpass import getpass
from datetime import datetime
from django.core.servers.basehttp import FileWrapper
from dashboard.models import UserProfile, Customer
import json as simplejson
import time
import json
import base64
import re
import subprocess
import os
from totp_auth import TotpAuth
from two_factor_auth.models import TwofactorSetup
from twilio import twiml
from casb.settings import TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, MEDIA_ROOT, TWILIO_TWIML_DOMAIN,\
                             TWILIO_CALLER_ID, TWILIO_API_URL, TWILIO_API_CALL_URL, QR_CODE_DOMAIN
from twilio import twiml
import qrcode
import StringIO
import urlparse
import pyotp

# Create your views here.
def two_factor_check(request):
    user_profile = UserProfile.objects.get(user=request.user)
    try:
        two_factor_status = TwofactorSetup.objects.get(user=user_profile,active=True)    
        status = "enabled"
        method = two_factor_status.method
        if method == 1:
            method = "call"
        elif method == 2:
            method = "sms"
        elif method == 3:
            method = "Google Authenticator"
    except:
        status = "not-enabled"
        method = ""
    status_details = json.dumps({"status":status,"method":method}, cls=DjangoJSONEncoder)
    return HttpResponse(status_details,content_type="application/json")    

def setup(request):    
    if request.user.is_authenticated():
        user_profile = UserProfile.objects.get(user=request.user)
        sms_phone = False
        call_phone = False
        gauth_sec = False
        sms_whatsapp = False
        step = 0
        method = ""
        phone = ""
        phone_caller = ""
        two_factor_enabled = False
        qrcode_image = ""
        whatsapp_phone = ""
        show_method = ""
        proceed_step = 0

        two_factor_status = TwofactorSetup.objects.filter(user=user_profile,active=True).count()        
        if two_factor_status == 0:            
            if request.POST:
                method = request.POST.get('auth_method')
                phone = request.POST.get('phone')                
                token = request.POST.get('token')                                                           
                step = request.POST.get('otp_step')               

                if method == "sms":
                    if step == "step2":                                                                               
                        totp = TotpAuth(request.session['secret'])
                        token = totp.generate_token()
                        print token,"token="                                         
                        sms_status = send_sms(token,phone)                        
                        if sms_status:                            
                            request.session['otp_reg'] = token
                            status = "success"
                        else:                            
                            status = "error"
                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")
                    elif step == "step3":
                        if int(token) == int(request.session['otp_reg']):
                            status = "success"
                        else:
                            status = "error"
                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")
                    elif step == "step4":                        
                        try:
                            TwofactorSetup.objects.create(user=user_profile,method=2,\
                                                         phone=phone,active=True,secret=request.session['secret'])
                            status = "success"
                        except:
                            status = "error"
                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")

                elif method == "call":
                    if step == "step2":                   
                        totp = TotpAuth(request.session['secret'])
                        token = totp.generate_token()
                        print token, "call"                   
                        sms_status = send_call(token,phone)
                        if sms_status:                            
                            request.session['otp_reg'] = token                                                                                                                      
                            status = "success"
                        else:
                            status = "error"
                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")
                    elif step == "step3":                                                         
                        if int(token) == int(request.session['otp_reg']):                            
                            status = "success"
                        else:
                            status = "error"
                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")
                    elif step == "step4":
                        try:
                            TwofactorSetup.objects.create(user=user_profile,method=1,\
                                                         phone=phone,active=True,secret=request.session['secret'])
                            status = "success"
                        except:
                            status = "error"
                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")                    

                elif method == "gauth":                    
                    if step == "step3":                   
                        totp = TotpAuth(request.session['secret'])
                        verify_status = totp.valid(int(token))                        
                        if verify_status:                                                        
                            status = "success"
                        else:                            
                            status = "error"
                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")                            
                    elif step == "step4":
                        try:                                 
                            TwofactorSetup.objects.create(user=user_profile,method=3, \
                                                        phone=phone,active=True,secret=request.session['secret'])                 
                            status = "success"
                        except:
                            status = "error"

                        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
                        return HttpResponse(status_details, content_type="application/json")   

def send_sms(token,to_number):    
    body = "Your CASB authentication token is "+str(token)
    twilio_caller_id = TWILIO_CALLER_ID
    twilio_account_sid = TWILIO_ACCOUNT_SID
    twilio_auth_token = TWILIO_AUTH_TOKEN    
    twilio_api_url = TWILIO_API_URL
    to_number = str(to_number).strip()
    try:
        p = subprocess.Popen("curl -X POST '"+twilio_api_url+"' \
        --data-urlencode 'To=+"+to_number+"'  \
        --data-urlencode 'From="+twilio_caller_id+"'  \
        --data-urlencode 'Body="+body+"' \
        -u "+twilio_account_sid+":"+twilio_auth_token,stdout=subprocess.PIPE,shell=True)
        result = p.stdout.read()
        return True
    except:
        return False

def send_whatsapp(whatsapp_token,to_number):
    to_number = str(to_number).strip()
    try:
        body = 'Your authentication token is '+str(whatsapp_token)
        print 'yowsup-cli demos --config '+SITE_ROOT+'/whatsapp_config.py --send '+to_number+' "'+str(body) + '"'         
        p = os.system('yowsup-cli demos --config '+SITE_ROOT+'/whatsapp_config.py --send '+to_number+' "'+str(body)+'"')        
        return True
    except Exception as ex:
        print str(ex)
        return False

def send_call(token,to_number):
    token = str(token)
    val = ""
    for xn in token:
        val = val + xn + " , , "
    call_body = "Your CASB authentication token is "+ val
    r = twiml.Response()
    r.say(call_body,loop=5)
    path = os.path.join(MEDIA_ROOT, 'call')
    if not os.path.exists(path):
      os.makedirs(path) 
    path += '/'+token+'.xml'
    fp = open(str(path), 'wb')
    fp.write(str(r))
    print token
    # import ipdb; ipdb.set_trace()
    #uri = 'http://oneconsole.marlabs.com/media/call/'+token+'.xml'
    uri = TWILIO_TWIML_DOMAIN+'/media/call/'+token+'.xml'
    #uri = "http://oneconsole.us/media/call/860405.xml"

    twilio_caller_id = TWILIO_CALLER_ID
    twilio_account_sid = TWILIO_ACCOUNT_SID
    twilio_auth_token = TWILIO_AUTH_TOKEN    
    twilio_api_url = TWILIO_API_URL
    twilio_api_call_url = TWILIO_API_CALL_URL

    # print "curl -X POST '"+twilio_api_call_url+"' \
    #         --data-urlencode 'To="+to_number+"'  \
    #         --data-urlencode 'From="+twilio_caller_id+"'  \
    #         -d 'Url="+uri+"'  \
    #         -d 'Method=GET'  \
    #         -d 'FallbackMethod=GET'  \
    #         -d 'StatusCallbackMethod=GET' \
    #         -d 'IfMachine=Hangup'  \
    #         -d 'Record=false' \
    #         -d 'Timeout=15' \
    #         -u "+twilio_account_sid+":"+twilio_auth_token
    # import ipdb; ipdb.set_trace()
    try:
        p = subprocess.Popen("curl -X POST '"+twilio_api_call_url+"' \
            --data-urlencode 'To="+to_number+"'  \
            --data-urlencode 'From="+twilio_caller_id+"'  \
            -d 'Url="+uri+"'  \
            -d 'Method=GET'  \
            -d 'FallbackMethod=GET'  \
            -d 'StatusCallbackMethod=GET' \
            -d 'IfMachine=Hangup'  \
            -d 'Record=false' \
            -d 'Timeout=15' \
            -u "+twilio_account_sid+":"+twilio_auth_token,stdout=subprocess.PIPE,shell=True)
        return True
    except:
        return False

def disable(request):
    if request.user.is_authenticated():
        user_profile = UserProfile.objects.get(user=request.user)
        try:
            TwofactorSetup.objects.filter(user=user_profile).delete()
            #request.session['secret'] = ''
            status = "success"
        except:
            status = "error"
        status_details = json.dumps({"status":status}, cls=DjangoJSONEncoder)
        return HttpResponse(status_details, content_type="application/json")    

def auth_qr_code(request):
    if request.user.is_authenticated():
        """generate a QR code with the users TOTP secret

        We do this to reduce the risk of leaking
        the secret over the wire in plaintext"""
        try:
            if request.session["secret"] == '':                  
                request.session["secret"] = pyotp.random_base32()
        except:                
            request.session["secret"] = pyotp.random_base32()

        #FIXME: This logic should really apply site-wide
        # domain = urlparse.urlparse(request.url).netloc
        # if not domain:
        domain = QR_CODE_DOMAIN
        username = "%s (%s)" % (request.user.username, domain)
        totp = TotpAuth(request.session['secret'])
        qrcode = totp.qrcode(username)        
        stream = StringIO.StringIO()
        qrcode.save(stream)        
        image = stream.getvalue()        
        return HttpResponse(image, content_type='image/png')
    return HttpResponseRedirect("/login")

def two_factor_login(request):
    try:
        username = request.session['user_twofactor']
    except:
        username = ''
    if username != '':
        user = User.objects.get(username__iexact=username)
        user_profile = UserProfile.objects.get(user=user)        
        twofactor_count = TwofactorSetup.objects.filter(user=user_profile,active=True).count()
        enable_method = False
        if twofactor_count > 0:
            if request.POST:
                token_details = request.POST.get('token')
                try:
                    token_details = int(token_details)
                    obj_twofactor = TwofactorSetup.objects.get(user=user_profile,active=True)
                    method = obj_twofactor.method
                    phone = obj_twofactor.phone
                    secret = obj_twofactor.secret
                    totp = TotpAuth(secret)

                    if method == 3:
                        verify_status = totp.valid(token_details)
                        if verify_status:
                            user.backend = 'django.contrib.auth.backends.ModelBackend'
                            auth.login(request, user)
                            request.session['user_twofactor'] = ''
                            return HttpResponseRedirect('/')
                        else:
                            messages.error(request, "Your token is invalid. Please enter a valid token")
                    else:
                        generated_token = request.session['twofactor_login_token']                
                        if token_details == int(generated_token):
                            user.backend = 'django.contrib.auth.backends.ModelBackend'
                            auth.login(request, user)
                            request.session['user_twofactor'] = ''
                            return HttpResponseRedirect('/')
                        else:
                            messages.error(request, "Your token is invalid. Please enter a valid token")
                except:
                    messages.error(request, "Your token is invalid. Please enter a valid token")

            else:
                obj_twofactor = TwofactorSetup.objects.get(user=user_profile,active=True)
                method = obj_twofactor.method
                phone = obj_twofactor.phone
                secret = obj_twofactor.secret
                totp = TotpAuth(secret)                
                if method == 1:
                    token = totp.generate_token()
                    request.session['twofactor_login_token'] = token
                    call_status = send_call(token,phone)
                    messages.success(request, "We are calling your phone right now, please enter the digits you hear.")
                elif method == 2:
                    token = totp.generate_token()
                    request.session['twofactor_login_token'] = token
                    sms_status = send_sms(token,phone)
                    messages.success(request, "We sent you a text message, please enter the token we sent.")
                elif method == 3:
                    messages.success(request, "Please enter the token generated by your token generator.")                

            c = RequestContext(request,{})     

            return render_to_response("login_factor.html", context_instance=c)
        else:
            return HttpResponseRedirect("/login")
    else:
        return HttpResponseRedirect("/login")

    













