from django.conf.urls import include, url
from django.contrib.auth.decorators import login_required

#two factor
urlpatterns = [
  url(r'^setup', 'two_factor_auth.views.setup', name="setup"),
  url(r'^disable', 'two_factor_auth.views.disable', name="disable"),
  url(r'^login$', 'two_factor_auth.views.two_factor_login', name="two_factor_login"),
  url(r'^auth_qr_code$', 'two_factor_auth.views.auth_qr_code', name="auth_qr_code"),
  url(r'^two_factor_check$', 'two_factor_auth.views.two_factor_check', name="two_factor_check")
]