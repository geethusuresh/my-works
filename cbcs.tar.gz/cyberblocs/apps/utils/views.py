import os
import json
import uuid
import hashlib
import datetime
import calendar
import subprocess

from django.http import HttpResponse
from django.conf import settings
from django.template import Context
from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from django.db.models.signals import post_save

from Savoir import Savoir
import pyotp
from twilio.rest import Client

from apps.multichain.models import FileManager, ContactRequest, FileAccess, Files, Transactions
from apps.accounts.models import User


class JSONResponseMixin(object):
   """
   A mixin that can be used to render a JSON response.
   """
   def render_to_json_response(self, context, **response_kwargs):
       """
       Returns a JSON response, transforming 'context' to make the payload.
       """
       return HttpResponse(
           self.convert_context_to_json(context),
           content_type='application/json',
           **response_kwargs
       )

   def convert_context_to_json(self, context):
       "Convert the context dictionary into a JSON object"
       # Note: This is EXTREMELY naive; in reality, you'll need
       # to do much more complex handling to ensure that arbitrary
       # objects -- such as Django model instances or querysets
       # -- can be serialized as JSON.
       return json.dumps(context)


def copy_folder(data):
    new_data = []
    for value in data:
        for item in FileManager.objects.filter(parent__id=value['id']).exclude(id=value['parent']):
            files_obj = item.files.all()
            item_id = item.id
            item.pk = None
            item.parent = FileManager.objects.get(id=value['parent'])
            item.save()
            for obj in files_obj:
                item.files.add(obj)
            new_data.append({'id': item_id, 'parent': item.id})
    if new_data:
        return copy_folder(new_data)
    return True


def handle_uploaded_file(f, uploaded_user):
    sha256 = hashlib.sha256()
    password = uuid.uuid4().hex
    asset_name = uuid.uuid4().hex
    temp = settings.BASE_DIR + '/media/files/' + password
    with open(temp, 'w+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)
            sha256.update(chunk)
    file_hash = sha256.hexdigest()
    file_name = f.name.replace(" ", "_")
    path = settings.BASE_DIR + '/media/files/' + file_hash + '-' + file_name + '.bin'
    process = subprocess.Popen(['openssl', 'aes-256-cbc', '-a', '-salt', '-in', temp, '-out',
                                path, '-pass', 'pass:' + password])
    process.wait()
    os.remove(temp)
    api = Savoir(settings.RPC_USER, settings.RPC_PASSWORD, settings.RPC_HOST, settings.RPC_PORT,
                 settings.CHAIN_NAME)
    asset = api.issue(uploaded_user.wallet, asset_name, 100000, 1, 0,
                      {"file_name": f.name,  "password": password, "sha256": file_hash})
    return file_name, asset_name, file_hash


def contact_email(data):
    """ Contact confirmation email """
    user_to = [data.email]
    admin_to = [settings.SALES_EMAIL]

    # user conformation email
    html_template = get_template('email_templates/contact_confirmation_html_template.html')
    text_template = get_template('email_templates/contact_confirmation_text_template.txt')
    user_subject = u'Thanks for your Request'
    try:
        contact_send_email(user_subject, user_to, data, text_template, html_template)
    except:
        pass

    # Admin Email
    admin_subject = u'Received one request'
    admin_html_template = get_template('email_templates/contact_admin_html_template.html')
    admin_text_template = get_template('email_templates/contact_admin_text_template.txt')
    try:
        contact_send_email(admin_subject, admin_to, data, admin_text_template, admin_html_template)
    except:
        pass


def contact_send_email(subject, to, data, text_template, html_template):
    from_email = settings.DEFAULT_FROM_EMAIL
    context = Context({'data': data})
    text_content = text_template.render(context)
    html_content = html_template.render(context)

    # Rich email message -  text and HTML
    msg = EmailMultiAlternatives(subject, text_content, from_email, to)
    msg.attach_alternative(html_content, "text/html")
    msg.send()


def send_otp(request):
    totp = pyotp.TOTP('base32secret3232')
    token = totp.now()
    request.session['token'] = token
    request.session['sent_to'] = request.user.phone_number
    expire_time = datetime.datetime.now() + datetime.timedelta(minutes=2)
    request.session['token_expire'] = calendar.timegm(expire_time.timetuple())
    if request.user.two_factor_method == 'p' and request.user.wallet_two_factor:
        text = "CyberBlocs wallet transfer One time password is " + token
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        client.messages.create(to=request.user.phone_number,
                               from_=settings.TWILIO_DEFAULT_CALLERID,
                               body=text)
    elif request.user.two_factor_method == 'e' and request.user.wallet_two_factor:
        two_factor_email({'to': request.user.email, 'otp': token})
    return True


def verify_otp(request):
    otp_status = False
    token_expire = request.session.get('token_expire', None)
    token_expire = datetime.datetime.utcfromtimestamp(token_expire)
    if token_expire > datetime.datetime.now() and request.session['token'] == request.POST.get('otp'):
        otp_status = True
    del request.session['token']
    del request.session['token_expire']
    return otp_status


def two_factor_email(data):
    """ Send OTP via email """
    to = [data['to']]
    otp = data['otp']

    # user conformation email
    html_template = get_template('email_templates/email_otp.html')
    text_template = get_template('email_templates/email_otp.txt')
    subject = u'Cyberblocs One time password'
    from_email = settings.DEFAULT_FROM_EMAIL
    context = Context({'otp': otp})
    text_content = text_template.render(context)
    html_content = html_template.render(context)

    # Rich email message -  text and HTML
    msg = EmailMultiAlternatives(subject, text_content, from_email, to)
    msg.attach_alternative(html_content, "text/html")
    msg.send()


def file_transfer(request):
    transfer_to = User.objects.get(email=request.session.get('transfer_to_email'))
    transfer_quantity = request.session['transfer_quantity']
    file_obj = Files.objects.get(id=request.session['file_id'])
    file_obj.users.add(transfer_to)
    api = Savoir(settings.RPC_USER, settings.RPC_PASSWORD, settings.RPC_HOST, settings.RPC_PORT,
                 settings.CHAIN_NAME)
    asset = api.sendassetfrom(request.user.wallet, transfer_to.wallet, file_obj.asset_name, int(transfer_quantity))
    file_access, created = FileAccess.objects.get_or_create(user=transfer_to, file=file_obj)
    file_access.wallet_balance += int(transfer_quantity)
    file_access.save()
    file_access2 = FileAccess.objects.get(user=request.user, file=file_obj)
    file_access2.wallet_balance -= int(transfer_quantity)
    file_access2.save()
    message = 'Received to wallet'
    update_transaction_history(file_access.user, file_access2.user, file_access.user, file_obj, message)
    message = 'Transferred to wallet'
    update_transaction_history(file_access2.user, file_access2.user, file_access.user, file_obj, message)
    file_manager_obj, created = FileManager.objects.get_or_create(user=transfer_to, text='/')
    file_manager_obj.files.add(file_obj)


def update_transaction_history(user, sender, receiver, file_obj, message):
    Transactions.objects.create(user=user, receiver=receiver, sender=sender,
                                file=file_obj, status=message)


def send_contact_email(sender, instance, **kwargs):
    if kwargs['created']:
        contact_email(instance)
post_save.connect(send_contact_email, sender=ContactRequest, dispatch_uid="send_contact_email")