import os
import json
import hashlib
import subprocess

from django.shortcuts import render
from django.conf import settings
from django.core.files import File
from django.http import HttpResponse, HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.views.generic import View, TemplateView
from django.utils.encoding import smart_str
from django.http import StreamingHttpResponse
from django.shortcuts import get_object_or_404

from Savoir import Savoir
import pyotp
from twilio.rest import Client

from apps.accounts.models import User
from apps.accounts.forms import SignupForm, EditProfileImageForm
from apps.multichain.models import Files, AccessRequest, Transactions, FileManager, FileAccess
from apps.multichain.forms import UploadFileForm, ContactUsForm
from apps.utils.views import contact_email, handle_uploaded_file, two_factor_email, file_transfer, update_transaction_history

totp = pyotp.TOTP('base32secret3232')


class Home(TemplateView):
    template_name = "multichain/home.html"

    def get_context_data(self, **kwargs):
        context = super(Home, self).get_context_data(**kwargs)
        context['transactions_count'] = Transactions.objects.all().count()
        context['wallets_count'] = User.objects.all().count()
        context['files_count'] = Files.objects.all().count()
        return context

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated():
            return HttpResponseRedirect(reverse('dashboard'))
        context = self.get_context_data(**kwargs)
        return self.render_to_response(context)


class CreateWalletView(View):
    template_name = 'multichain/create_wallet.html'

    def get(self, request, *args, **kwargs):
        if self.request.user.wallet:
            return HttpResponseRedirect(reverse('dashboard'))
        return render(request, self.template_name, {})

    def post(self, request, *args, **kwargs):
        ctx = dict()
        try:
            api = Savoir(settings.RPC_USER, settings.RPC_PASSWORD, settings.RPC_HOST, settings.RPC_PORT,
                         settings.CHAIN_NAME)
            response = api.getnewaddress()
            api.grant(response, 'receive')
            self.request.user.wallet = response
            self.request.user.save()
            message = 'Created a new wallet'
            update_transaction_history(request.user, request.user, request.user, None, message)
            ctx['status'] = 'success'
        except Exception as e:
            print "Error:", e
            ctx['status'] = 'error'
        return HttpResponse(json.dumps(ctx), content_type='application/json')


class DashboardView(View):
    template_name = 'multichain/dashboard.html'
    admin_template_name = 'multichain/admin_dashboard.html'

    def get(self, request, *args, **kwargs):
        if not self.request.user.wallet:
            return HttpResponseRedirect(reverse('create_wallet'))
        files = Files.objects.filter(removed=False)
        transactions = Transactions.objects.filter(user=request.user)
        admin_wallet = settings.ADMIN_ADDRESS
        if request.user.admin:
            return render(request, self.admin_template_name, {'files': files, 'transactions': transactions})
        transactions = transactions.filter(user=request.user)
        return render(request, self.template_name, {'files': files, 'transactions': transactions,
                                                    'admin_wallet': admin_wallet})


class AccessRequestView(TemplateView):
    template_name = 'multichain/access_request.html'

    def get_context_data(self, **kwargs):
        context = super(AccessRequestView, self).get_context_data(**kwargs)
        context['access_requests'] = AccessRequest.objects.all()
        context['pending_requests'] = AccessRequest.objects.filter(status=AccessRequest.PENDING)
        context['accepted_requests'] = AccessRequest.objects.filter(status=AccessRequest.APPROVED)
        context['rejected_requests'] = AccessRequest.objects.filter(status=AccessRequest.REJECTED)
        return context

    def post(self, request, *args, **kwargs):
        file_id = request.POST.get("id")
        file_obj = Files.objects.get(id=file_id)
        AccessRequest.objects.create(file=file_obj, from_user=self.request.user, to_user=file_obj.created_by,
                                     requester_comment=request.POST.get("requester_comment"))
        message = 'Sent doc access request'
        update_transaction_history(request.user, request.user, file_obj.created_by, file_obj, message)
        message = 'Received doc access request'
        update_transaction_history(file_obj.created_by, request.user, file_obj.created_by, file_obj, message)
        return HttpResponseRedirect(reverse('dashboard')+'?status=ok')


class DeleteFileView(TemplateView):
    template_name = 'multichain/access_request.html'

    def post(self, request, *args, **kwargs):
        file_id = request.POST.get("id")
        file_obj = Files.objects.get(id=file_id)
        file_obj.removed = True
        file_obj.save()
        return HttpResponseRedirect(reverse('dashboard')+'?status=delete')


class ManageRequestView(TemplateView):
    template_name = 'multichain/access_request.html'

    def post(self, request, *args, **kwargs):
        approve = request.POST.get("approve")
        access_id = request.POST.get("id")
        access_obj = AccessRequest.objects.get(id=access_id)
        file_obj = Files.objects.get(id=access_obj.file.id)
        file_owner_access = FileAccess.objects.get(file=file_obj, user=request.user)
        if approve == 'false':
            access_obj.status = AccessRequest.REJECTED
            access_obj.reason = request.POST.get("reason")
            access_obj.save()

            message = 'Rejected the doc request'
            update_transaction_history(access_obj.from_user, request.user, access_obj.from_user, file_obj, message)
            update_transaction_history(request.user, request.user, access_obj.from_user, file_obj, message)
            return HttpResponseRedirect(reverse('dashboard') + '?status=reject')
        else:
            quantity = int(request.POST.get("quantity"))
            if not file_owner_access.wallet_balance > quantity:
                return HttpResponseRedirect(reverse('dashboard') + '?status=insufficient_balance')
            if request.user.wallet_two_factor:
                token = totp.now()
                request.session['two_factor'] = {'token': token, 'reason': request.POST.get("reason"),
                                                 'quantity': quantity, 'manage_request_id': request.POST.get("id")}
                request.session['wallet_transfer'] = True
                if request.user.two_factor_method == User.PHONE:
                    request.session['sent_to'] = request.user.phone_number
                    text = "CyberBlocs wallet transfer One time password is " + token
                    client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
                    message = client.messages.create(to=request.user.phone_number,
                                                     from_=settings.TWILIO_DEFAULT_CALLERID,
                                                     body=text)
                else:
                    request.session['sent_to'] = request.user.email
                    two_factor_email({'to': request.user.email, 'otp': token})
                return HttpResponseRedirect(reverse('verify_token'))
            api = Savoir(settings.RPC_USER, settings.RPC_PASSWORD, settings.RPC_HOST, settings.RPC_PORT,
                         settings.CHAIN_NAME)
            asset = api.sendassetfrom(request.user.wallet, access_obj.from_user.wallet, file_obj.asset_name, quantity)
            access_obj.status = AccessRequest.APPROVED
            access_obj.reason = request.POST.get("reason")
            file_owner_access.wallet_balance -= quantity
            file_owner_access.save()
            file_access_obj, created = FileAccess.objects.get_or_create(user=access_obj.from_user, file=access_obj.file)
            file_access_obj.wallet_balance += quantity
            file_access_obj.save()
            access_obj.save()

            message = 'Approved the doc request'
            update_transaction_history(access_obj.from_user, request.user, access_obj.from_user, file_obj, message)
            update_transaction_history(request.user, request.user, access_obj.from_user, file_obj, message)
        return HttpResponseRedirect(reverse('dashboard')+'?status=grant')


class TwoFactorManageRequestView(View):

    def get(self, request, *args, **kwargs):
        access_obj = AccessRequest.objects.get(id=request.session['two_factor']['manage_request_id'])
        file_obj = Files.objects.get(id=access_obj.file.id)
        file_owner_access = FileAccess.objects.get(file=file_obj, user=request.user)
        quantity = int(request.session['two_factor']['quantity'])
        if file_owner_access.wallet_balance > quantity and 'wallet_transfer' in request.session:

            request.session['transfer_to_email'] = access_obj.from_user.email
            request.session['transfer_quantity'] = request.session['two_factor']['quantity']
            request.session['file_id'] = access_obj.file.id
            file_transfer(request)

            access_obj.status = AccessRequest.APPROVED
            access_obj.reason = request.session['two_factor']['reason']
            access_obj.save()

            message = 'Approved the doc request'
            update_transaction_history(access_obj.from_user, request.user, access_obj.from_user, file_obj, message)
            update_transaction_history(request.user, request.user, access_obj.from_user, file_obj, message)

            del request.session['transfer_to_email']
            del request.session['wallet_transfer']
            del request.session['transfer_quantity']
            del request.session['file_id']
            del request.session['two_factor']
            return HttpResponseRedirect(reverse('dashboard')+'?status=grant')
        return HttpResponseRedirect(reverse('dashboard')+'?status=error')


class ManageUsersView(TemplateView):
    template_name = 'multichain/manage_user.html'

    def get_context_data(self, **kwargs):
        context = super(ManageUsersView, self).get_context_data(**kwargs)
        context['users'] = User.objects.filter(admin=False)
        return context


class CreateUserView(TemplateView):
    template_name = 'multichain/edit_user.html'

    def post(self, request, *args, **kwargs):
        create_form = SignupForm(data=request.POST)
        if create_form.is_valid():
            create_form.save()
            return HttpResponseRedirect(reverse('manage_users')+'?status=create')
        return HttpResponseRedirect(reverse('create_user')+'?email=exist')


class EditUserView(TemplateView):
    template_name = 'multichain/edit_user.html'

    def get_context_data(self, **kwargs):
        context = super(EditUserView, self).get_context_data(**kwargs)
        context['edit_user'] = User.objects.get(id=kwargs.get('id'))
        context['edit'] = True
        return context

    def post(self, request, *args, **kwargs):
        if request.user.admin and not request.user.id == int(kwargs.get('id')):
            user = User.objects.get(id=kwargs.get('id'))
            user.first_name = request.POST.get("first_name")
            user.last_name = request.POST.get("last_name")
            user.save()
            return HttpResponseRedirect(reverse('manage_users')+'?status=ok')
        else:
            user = request.user
            if request.POST.get("name"):
                name = request.POST.get("name").split()
                user.first_name = " ".join(name[:1])
                user.last_name = " ".join(name[1:])
            if request.FILES.get("image"):
                user.image = request.FILES.get("image")
            if request.POST.get("remove_image") and request.POST.get("remove_image") == 'true':
                user.image = ''
            user.save()
            return HttpResponseRedirect(reverse('dashboard') + '?update=true')


class UserRecordPermissionsView(TemplateView):
    template_name = 'multichain/user_record_permissions.html'

    def get_context_data(self, **kwargs):
        context = super(UserRecordPermissionsView, self).get_context_data(**kwargs)
        user = User.objects.get(id=kwargs.get('id'))
        context['user'] = user
        context['access_records'] = AccessRequest.objects.filter(from_user=user, status=AccessRequest.APPROVED)
        return context


class DeleteUserView(View):

    def post(self, request, *args, **kwargs):
        user = User.objects.get(id=kwargs.get('id'))
        user.delete()
        return HttpResponseRedirect(reverse('manage_users')+'?status=delete')


class DownloadFileView(View):

    def get(self, request, *args, **kwargs):
        file_id = request.GET.get("id")
        try:
            file_obj = Files.objects.get(id=file_id, removed=False)
        except:
            return HttpResponseRedirect(reverse('dashboard') + '?file=removed')
        api = Savoir(settings.RPC_USER, settings.RPC_PASSWORD, settings.RPC_HOST, settings.RPC_PORT,
                     settings.CHAIN_NAME)
        balance = api.getaddressbalances(request.user.wallet)
        access_status = False
        for item in balance:
            if item.get("name") == file_obj.asset_name and item.get("qty") > 0:
                access_status = True
                break
        if not access_status:
            return HttpResponseRedirect(reverse('dashboard') + '?permission=false')
        file_details = api.listassets(file_obj.asset_name)
        file_details = file_details[0].get("details")
        file_hash = file_details.get("sha256")
        file_password = file_details.get("password")
        path = settings.BASE_DIR + '/media/files/' + file_hash + '-' + file_obj.file + '.bin'
        output_path = settings.BASE_DIR + '/media/files/' + file_hash + '-' + file_obj.file
        process = subprocess.Popen(['openssl', 'aes-256-cbc', '-d', '-a', '-in', path, '-out',
                                    output_path, '-pass', 'pass:' + file_password])
        process.wait()
        current_hash = hashlib.sha256(open(output_path, 'rb').read()).hexdigest()
        if not current_hash == file_hash:
            return HttpResponseRedirect(reverse('dashboard') + '?file=changed')
        result_file = open(output_path, "rd")
        response = StreamingHttpResponse(result_file, content_type="application/force-download")
        response['Content-Disposition'] = 'attachment; filename=%s' % smart_str(file_obj.file)
        os.remove(output_path)
        access_obj = FileAccess.objects.get(user=request.user, file=file_obj)
        access_obj.downloads += 1
        access_obj.save()
        Transactions.objects.create(user=request.user, receiver=request.user, sender=request.user,
                                    file=file_obj, status='Downloaded doc from wallet')
        return response


class UploadFile(View):

    def post(self, request, *args, **kwargs):
        encrypted_file, asset_name, file_hash = handle_uploaded_file(request.FILES['file'], request.user)
        form = UploadFileForm({'title': request.POST.get('title'), 'file': encrypted_file, 'asset_name': asset_name,
                               'file_hash': file_hash, 'created_by': request.user.id})
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('dashboard')+'?status=create')
        return HttpResponseRedirect(reverse('dashboard')+'?status=error')


class ContactUsRequestView(View):

    def post(self, request, *args, **kwargs):
        if request.is_ajax():
            ctx = {}
            contact_form = ContactUsForm(request.POST)
            if contact_form.is_valid():
                instance = contact_form.save()
                contact_email(instance)
                ctx['status'] = 'success'
            else:
                ctx['errors'] = contact_form.errors
        return HttpResponse(json.dumps(ctx), content_type="application/json")


class ManageUserFileAccessView(TemplateView):
    template_name = 'multichain/manage_user_file_access.html'

    def get_context_data(self, **kwargs):
        context = super(ManageUserFileAccessView, self).get_context_data(**kwargs)
        doc = get_object_or_404(Files, id=kwargs['id'])
        file_access_obj = FileAccess.objects.filter(file=doc)
        doc_granted_users = [item.user for item in file_access_obj]
        doc_granted_user_ids = [user.id for user in doc_granted_users]
        doc_users = doc.users.all()
        users = User.objects.all()
        visibility_granted_users = doc_users.exclude(id__in=doc_granted_user_ids)
        visibility_granted_user_ids = [user.id for user in visibility_granted_users]

        users = users.exclude(id__in=visibility_granted_user_ids)
        context['users'] = users.exclude(id__in=doc_granted_user_ids)
        context['visibility_granted_users'] = visibility_granted_users
        context['record_granted_users'] = doc_granted_users
        context['record'] = doc
        return context

    def post(self, request, *args, **kwargs):
        record = get_object_or_404(Files, id=kwargs['id'])
        file_access_obj = FileAccess.objects.filter(file=record)
        record.users.clear()
        if request.POST.getlist('user'):
            for item in request.POST.getlist('user'):
                user = User.objects.get(id=item)
                record.users.add(user)
            for file_access in file_access_obj:
                record.users.add(file_access.user)
            return HttpResponseRedirect(reverse('dashboard')+'?shared=shared')
        for file_access in file_access_obj:
            record.users.add(file_access.user)
        return HttpResponseRedirect(reverse('dashboard')+'?shared=private')

