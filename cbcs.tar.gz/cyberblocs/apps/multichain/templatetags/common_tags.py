from django import template

from apps.multichain.models import AccessRequest


register = template.Library()


@register.assignment_tag()
def request_status(user, file):
    try:
        access_obj = AccessRequest.objects.get(user=user, file=file)
        if access_obj.status == AccessRequest.PENDING:
            return "Pending"
        elif access_obj.status == AccessRequest.REJECTED:
            return "Rejected"
        else:
            return access_obj
    except:
        return False
