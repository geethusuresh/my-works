from django import forms

from apps.multichain.models import Files, ContactRequest


class UploadFileForm(forms.ModelForm):

    class Meta:
        model = Files
        fields = ('title', 'file', 'asset_name', 'file_hash', 'created_by')


class ContactUsForm(forms.ModelForm):
    """
    form for saving contact requests
    """

    class Meta:
        model = ContactRequest
        fields = ('name', 'email', 'subject', 'message')