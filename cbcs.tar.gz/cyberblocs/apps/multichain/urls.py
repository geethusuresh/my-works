from django.conf.urls import url
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt

from apps.multichain import views


urlpatterns = [
                url(r'^$', login_required(views.DashboardView.as_view()), name='dashboard'),
                url(r'^create-wallet/$', login_required(views.CreateWalletView.as_view()), name='create_wallet'),
                url(r'^access-request/$', login_required(views.AccessRequestView.as_view()), name='access_request'),
                url(r'^upload-file/$', login_required(views.UploadFile.as_view()), name='upload_file'),
                url(r'^downlaod-file/$', login_required(views.DownloadFileView.as_view()), name='download_file'),
                url(r'^delete-file/$', login_required(views.DeleteFileView.as_view()), name='delete_file'),
                url(r'^manage-request/$', login_required(views.ManageRequestView.as_view()), name='manage_request'),
                url(r'^two-factor-manage-request/$', login_required(views.TwoFactorManageRequestView.as_view()), name='two_factor_manage_request'),
                url(r'^manage-users/$', login_required(views.ManageUsersView.as_view()), name='manage_users'),
                url(r'^delete-user/(?P<id>[-\w]+)/$', login_required(views.DeleteUserView.as_view()), name='delete_user'),
                url(r'^edit-user/(?P<id>[-\w]+)/$', login_required(views.EditUserView.as_view()), name='edit_user'),
                url(r'^create-user/$', login_required(views.CreateUserView.as_view()), name='create_user'),
                url(r'^manage-user-file-access/(?P<id>[-\w]+)/$', login_required(views.ManageUserFileAccessView.as_view()), name='manage_user_file_access'),
                url(r'^user-permissions/(?P<id>[-\w]+)/$', login_required(views.UserRecordPermissionsView.as_view()), name='user_permissions'),

                url(r'^contact-request/$', views.ContactUsRequestView.as_view(), name='contact_request'),
                ]
