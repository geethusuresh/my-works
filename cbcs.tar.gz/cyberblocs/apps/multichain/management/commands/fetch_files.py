import os
from os import listdir
from os.path import isfile, join

from django.core.management import BaseCommand
from django.core.files import File
from django.core.files.base import ContentFile

from apps.multichain.forms import UploadFileForm
from apps.utils.views import handle_uploaded_file
from apps.accounts.models import User


class Command(BaseCommand):
    # Show this when the user types help
    help = "Fetch the files from drive and store into projects media folder"

    def handle(self, *args, **options):
        path = '/home/savad/cyberblocs'
        files = [f for f in listdir(path) if isfile(join(path, f))]
        for item in files:
            file_path = join(path, item)
            local_file = open(file_path)
            django_file = File(local_file, name=item)
            admin_user = User.objects.filter(admin=True)[0]
            encrypted_file, asset_name, file_hash = handle_uploaded_file(django_file, admin_user)
            form = UploadFileForm({'title': item, 'file': encrypted_file, 'asset_name': asset_name,
                                   'admin_wallet_balance': 100000, 'file_hash': file_hash})
            if form.is_valid():
                form.save()
                os.remove(file_path)



