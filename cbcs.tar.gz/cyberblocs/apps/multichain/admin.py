from django.contrib import admin

from apps.multichain.models import Files, AccessRequest, Transactions, FileManager, ContactRequest, FileAccess


admin.site.register(Files)
admin.site.register(AccessRequest)
admin.site.register(Transactions)
admin.site.register(ContactRequest)
admin.site.register(FileAccess)


class FileManagerAdmin(admin.ModelAdmin):
    list_display = ['__unicode__', 'user']
    filter_horizontal = ['files']

admin.site.register(FileManager, FileManagerAdmin)
