from django.db import models
from django.db.models.signals import post_save


class Files(models.Model):
    title = models.CharField(max_length=255)
    file = models.CharField(max_length=1000)
    asset_name = models.CharField(max_length=255, null=True, blank=True)
    file_hash = models.CharField(max_length=127, null=True, blank=True)
    # admin_wallet_balance = models.PositiveIntegerField(default=0)
    users = models.ManyToManyField('accounts.User', blank=True)
    removed = models.BooleanField(default=False)
    created_by = models.ForeignKey('accounts.User', related_name='created_by')
    created = models.DateTimeField("Created", auto_now_add=True)

    def __str__(self):
        return u'%s' % self.title


def create_file_access(sender, instance, **kwargs):
    if kwargs['created']:
        instance.users.add(instance.created_by)
        FileAccess.objects.create(user=instance.created_by, file=instance, wallet_balance=100000)
        file_manager_obj, created = FileManager.objects.get_or_create(user=instance.created_by, text='/')
        file_manager_obj.files.add(instance)
        Transactions.objects.create(user=instance.created_by, receiver=instance.created_by, sender=instance.created_by,
                                    file=instance, status='File Uploaded & received 100000 wallet balance')
post_save.connect(create_file_access, sender=Files, dispatch_uid="create_file_access")


class AccessRequest(models.Model):
    PENDING = 'p'
    APPROVED = 'a'
    REJECTED = 'r'
    REQUEST_STATUS = (
        (PENDING, "Pending"),
        (APPROVED, "Approved"),
        (REJECTED, "Rejected")
    )
    from_user = models.ForeignKey('accounts.User', related_name='request_from_user')
    to_user = models.ForeignKey('accounts.User', related_name='request_to_user')
    file = models.ForeignKey(Files, null=True)
    status = models.CharField(max_length=1, default='p', choices=REQUEST_STATUS)
    requester_comment = models.CharField(max_length=1023, null=True, blank=True)
    reason = models.CharField(max_length=1023, null=True, blank=True)
    downloads = models.PositiveIntegerField(default=0)
    created = models.DateTimeField("Created", auto_now_add=True)

    def __str__(self):
        return u'%s' % self.from_user


class FileAccess(models.Model):
    user = models.ForeignKey('accounts.User')
    file = models.ForeignKey(Files)
    wallet_balance = models.PositiveIntegerField(default=0)
    downloads = models.PositiveIntegerField(default=0)
    created = models.DateTimeField("Created", auto_now_add=True)


def create_file_manager_entry(sender, instance, **kwargs):
    if kwargs['created']:
        file_manager_obj, created = FileManager.objects.get_or_create(user=instance.user, text='/')
        file_manager_obj.files.add(instance.file)
post_save.connect(create_file_manager_entry, sender=FileAccess, dispatch_uid="create_file_manager_entry")


class Transactions(models.Model):
    user = models.ForeignKey('accounts.User', related_name='transaction_user')
    sender = models.ForeignKey('accounts.User', null=True, blank=True, related_name='sender')
    receiver = models.ForeignKey('accounts.User', null=True, blank=True, related_name='receiver')
    quantity = models.PositiveIntegerField(default=0)
    file = models.ForeignKey(Files, null=True, blank=True)
    status = models.CharField(max_length=511, null=True, blank=True)
    transaction_id = models.CharField(max_length=255, null=True, blank=True)
    created = models.DateTimeField("Created", auto_now_add=True)

    def __str__(self):
        return u'%s' % self.user

    def downloads(self):
        try:
            access_obj = AccessRequest.objects.get(file=self.file, user=self.user)
            return access_obj.downloads
        except:
            return 0


class FileManager(models.Model):
    user = models.ForeignKey('accounts.User')
    parent = models.ForeignKey('self', null=True, blank=True,
                               help_text='Keep this blank if it is a parent menu', related_name='child')
    text = models.CharField(max_length=255)
    files = models.ManyToManyField(Files, blank=True)

    def __unicode__(self):
        text = self.text
        parent = self.parent
        while parent:
            text = parent.text + "  >  " + text
            if parent.parent:
                parent = parent.parent
            else:
                parent = False
        return text

    class Meta:
        verbose_name = 'File Manager'
        verbose_name_plural = 'File Manager'


class ContactRequest(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)
    subject = models.CharField(max_length=255, null=True, blank=True)
    message = models.TextField()
    created_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return u'%s' % self.name
