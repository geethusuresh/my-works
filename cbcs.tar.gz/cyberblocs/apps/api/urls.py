from django.conf.urls import include, url

from rest_framework.routers import DefaultRouter
from rest_framework_expiring_authtoken.views import obtain_expiring_auth_token

from apps.api import views

router = DefaultRouter()
router.register(r'me', views.UserView, base_name="me")
router.register(r'create-user', views.CreateUserViewSet, base_name="create_user_api")
router.register(r'user-basic', views.SimpleUserViewSet, base_name="user_simple")
router.register(r'user-detail', views.UserViewSet, base_name="user_detail")
router.register(r'create-wallet', views.CreateWalletViewSet, base_name="create_wallet")
router.register(r'list-files', views.ListFileViewSet, base_name="list_files")
router.register(r'end-user-list-files', views.EndUserListFileViewSet, base_name="end_user_list_files")
router.register(r'end-user-list-shared-files', views.EndUserListSharedFileViewSet, base_name="end_user_shared_files")
router.register(r'delete-file', views.DeleteFileViewSet, base_name="delete_file")
router.register(r'access-request', views.AccessRequestViewSet, base_name="access_request")
router.register(r'external-access-request', views.ExternalAccessRequestViewSet, base_name="external_access_request")
router.register(r'user-file-request', views.UserRequestDetailsViewSet, base_name="user_file_requests")
router.register(r'file-details', views.FileDetailsViewSet, base_name="file_details")
router.register(r'file-granted-users', views.FileGrantedUsersViewSet, base_name="file_granted_users")
router.register(r'manage-request', views.ManageRequestViewSet, base_name="manage_requests")
router.register(r'file-manager', views.FileManagerViewSet, base_name="file_manager")
router.register(r'contact-us', views.ContactUsViewSet, base_name="contact_us")
router.register(r'uploaded-files', views.UploadedFileDetailsViewSet, base_name="uploaded_file_details")


urlpatterns = (
    url(r'^v1/', include(router.urls)),
    url(r'^v1/upload-file/$', views.FileUploadView.as_view(), name='upload_file_api'),
    url(r'^v1/update-file-manager/$', views.UpdateFileManagerView.as_view(), name='update_file_manager'),
    url(r'^v1/create-file-manager/$', views.CreateFileManagerView.as_view(), name='create_file_manager'),
    url(r'^v1/create-folder/$', views.CreateFolderView.as_view(), name='create_folder'),
    url(r'^v1/rename-folder/$', views.RenameFolderView.as_view(), name='rename_folder'),
    url(r'^v1/transfer-generate-otp/$', views.UserFileTransferGenerateOPTView.as_view(), name='transfer_generate_otp'),
    url(r'^v1/transfer-confirm/$', views.UserFileTransferView.as_view(), name='transfer_confirm'),
    url(r'^v1/transaction-count/$', views.TransactionCount.as_view(), name='transaction_count'),
    url(r'^v1/api-token-auth/', obtain_expiring_auth_token)
)
