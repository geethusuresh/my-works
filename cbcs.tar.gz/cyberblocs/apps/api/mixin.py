from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import MultipleObjectsReturned

from rest_framework import viewsets
from rest_framework import permissions
from rest_framework import serializers
from rest_framework.authentication import SessionAuthentication, TokenAuthentication
from rest_framework_expiring_authtoken.authentication import ExpiringTokenAuthentication

from apps.accounts.models import User


class UserRequired(object):
    """Mixin to check User is authenticated

    If nor user is not authenticated HTTP 401 UNAUTHORIZED will raise
    """
    permission_classes = [permissions.IsAuthenticated, ]
    # authentication_classes = [SessionAuthentication, ]
    authentication_classes = [ExpiringTokenAuthentication, SessionAuthentication, ]


class UserValidationMixin(object):

    def validate_token(self, value):
        """
        Check object exist in model
        """
        if self.context['request'].user.pk == 0:
            raise serializers.ValidationError("Object does not exist")
        return value


class UserProfileMixin(UserRequired, viewsets.ModelViewSet):
    http_method_names = ['get', ]

    def get_queryset(self):
        user = self.request.user
        if user.admin:
            queryset = self.model.objects.all()
        else:
            queryset = self.model.objects.filter(id=user.id)
        return queryset
