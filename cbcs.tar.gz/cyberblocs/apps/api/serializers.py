import json

from django.core.exceptions import ObjectDoesNotExist
from django.contrib.humanize.templatetags.humanize import naturaltime
from django.core.urlresolvers import reverse
from django.core.exceptions import MultipleObjectsReturned
from django.db.models import Q

from rest_framework import serializers
# from sorl.thumbnail import get_thumbnail

from apps.accounts.models import User
from apps.multichain.models import Files, AccessRequest, FileManager, FileAccess, ContactRequest


class SimpleUserListSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', )
        read_only_fields = ('id', 'username')


class CreateUserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(max_length=255, min_length=8, allow_blank=False)

    class Meta:
        model = User
        fields = ('email', )

    def validate_email(self, value):
        user = User.objects.filter(Q(email=value) | Q(username=value))
        if not user:
            return value
        raise serializers.ValidationError("Email already exist")


class UserListSerializer(SimpleUserListSerializer):
    class Meta:
        model = User
        fields = SimpleUserListSerializer.Meta.fields + ('first_name', 'last_name', 'admin', 'wallet', )
        read_only_fields = SimpleUserListSerializer.Meta.fields + ('first_name', 'last_name', 'admin', 'wallet', )


class UserDetailSerializer(UserListSerializer):
    class Meta:
        model = User
        fields = UserListSerializer.Meta.fields + ('image', 'phone_number', 'two_factor', 'wallet_two_factor', )
        read_only_fields = UserListSerializer.Meta.fields + ('image', 'phone_number', 'two_factor', 'wallet_two_factor', )


class FileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Files
        fields = ('id', 'title', 'created', 'file')
        read_only_fields = ('id', 'title', 'created', 'file')


class FileDetailSerializer(FileSerializer):
    users = UserListSerializer(many=True)

    class Meta:
        model = Files
        fields = FileSerializer.Meta.fields + ('users', )
        read_only_fields = FileSerializer.Meta.fields + ('users', )


class EndUserFileSerializer(serializers.ModelSerializer):
    is_owner = serializers.SerializerMethodField(source='get_is_owner')

    class Meta:
        model = Files
        fields = ('id', 'title', 'created', 'file', 'is_owner')
        read_only_fields = ('id', 'title', 'created', 'file', 'is_owner')

    def get_is_owner(self, obj):
        if self.context['request'].user == obj.created_by:
            return True
        return False


class FileAccessSerializer(serializers.ModelSerializer):
    file_details = FileSerializer(source='file')

    class Meta:
        model = FileAccess
        fields = ('id', 'user', 'created', 'file_details', 'wallet_balance')
        read_only_fields = ('id', 'user', 'created', 'file_details', 'wallet_balance')


class ManageAccessRequestSerializer(serializers.ModelSerializer):
    action = serializers.ChoiceField(allow_blank=False, choices=('granted', 'rejected'))

    class Meta:
        model = AccessRequest
        fields = ('id', 'user', 'status', 'action')
        read_only_fields = ('id', 'user', 'status')


class AccessRequestSerializer(serializers.ModelSerializer):
    file = serializers.CharField(max_length=255, allow_blank=False)
    from_user = UserListSerializer()
    wallet_balance = serializers.SerializerMethodField(source='get_wallet_balance')

    class Meta:
        model = AccessRequest
        fields = ('id', 'file', 'from_user', 'to_user', 'status', 'created', 'reason',
                  'requester_comment', 'wallet_balance')
        read_only_fields = ('id', 'from_user', 'to_user', 'status', 'created', 'reason',
                            'requester_comment', 'wallet_balance')

    def validate_file(self, value):
        try:
            Files.objects.get(id=value)
            return value
        except:
            raise serializers.ValidationError("File not exist")

    def get_wallet_balance(self, obj):
        file_access = FileAccess.objects.filter(user=self.context['request'].user, file=obj.file)
        if file_access:
            return file_access[0].wallet_balance


class UserFileRequestDetailsSerializer(SimpleUserListSerializer):
    file_requests = AccessRequestSerializer(source='get_file_requests', read_only=True, many=True, )

    class Meta:
        model = User
        fields = SimpleUserListSerializer.Meta.fields + ('file_requests', )
        read_only_fields = SimpleUserListSerializer.Meta.fields + ('file_requests', )


class FileManagerSerializer(serializers.ModelSerializer):
    files = FileSerializer(many=True)

    class Meta:
        model = FileManager
        fields = ('id', 'user', 'parent', 'text', 'files')
        read_only_fields = ('id', 'user', 'files')


class ContactUsSerializer(serializers.ModelSerializer):

    class Meta:
        model = ContactRequest
        fields = ('id', 'name', 'email', 'subject', 'message', )
        read_only_fields = ('id', )
