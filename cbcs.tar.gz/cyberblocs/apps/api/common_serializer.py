from rest_framework import serializers


class ImageSerializer(serializers.ModelSerializer):
    image_url = serializers.SerializerMethodField()

    class Meta:
        fields = ('image_url', 'alt_text', )

    def get_image_url(self, obj):
        return self.context['request'].build_absolute_uri(obj.get_image())


class ImageJsonSerializer(serializers.Serializer):
    image_url = serializers.SerializerMethodField()

    class Meta:
        fields = ('image_url', 'alt_text', )

    def get_image_url(self, obj):
        return self.context['request'].build_absolute_uri(obj.get_image())
