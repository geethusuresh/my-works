import datetime

from django.core.exceptions import MultipleObjectsReturned
from django.conf import settings
from django.db.models import Q

from rest_framework import viewsets
from rest_framework import views
from rest_framework.response import Response

from Savoir import Savoir
import pyotp

from apps.api.mixin import UserRequired
from apps.api import mixin
from apps.api import serializers
from apps.accounts.models import User
from apps.multichain.forms import UploadFileForm
from apps.multichain.models import Files, AccessRequest, FileManager, FileAccess, Transactions, ContactRequest
from apps.utils.views import copy_folder, handle_uploaded_file, send_otp, verify_otp, two_factor_email, file_transfer


class UserView(UserRequired, viewsets.ModelViewSet):
    """
    Use this endpoint to retrieve current user details
    """
    http_method_names = ['get', ]
    model = User
    serializer_class = serializers.UserDetailSerializer
    queryset = User.objects.all()

    def get_object(self):
        return self.request.user

    def list(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)


class SimpleUserViewSet(mixin.UserProfileMixin):
    http_method_names = ['get', 'delete']
    serializer_class = serializers.SimpleUserListSerializer
    model = User
    queryset = User.objects.all()


class UserViewSet(mixin.UserProfileMixin):
    serializer_class = serializers.UserListSerializer
    model = User


class CreateUserViewSet(mixin.UserProfileMixin):
    http_method_names = ['post', ]
    serializer_class = serializers.CreateUserSerializer
    model = User


class CreateWalletViewSet(mixin.UserProfileMixin):
    http_method_names = ['put', ]
    serializer_class = serializers.UserListSerializer
    queryset = User.objects.all()
    model = User

    def perform_update(self, serializer):
        api = Savoir(settings.RPC_USER, settings.RPC_PASSWORD, settings.RPC_HOST, settings.RPC_PORT,
                     settings.CHAIN_NAME)
        wallet = api.getnewaddress()
        api.grant(wallet, 'receive')
        serializer.save(wallet=wallet)


class FileGrantedUsersViewSet(UserViewSet):

    def get_queryset(self):
        file_obj = Files.objects.get(id=self.request.GET.get('file_id'))
        file_access = FileAccess.objects.filter(file=file_obj)
        queryset = [item.user for item in file_access]
        return queryset


class ListFileViewSet(UserRequired, viewsets.ModelViewSet):
    http_method_names = ['get', ]
    serializer_class = serializers.FileSerializer
    queryset = Files.objects.filter(removed=False)
    model = Files

    def get_queryset(self):
        queryset = self.queryset
        if self.request.GET.get('type') == 'private':
            queryset = queryset.filter(users=None)
        if self.request.GET.get('type') == 'shared':
            queryset = queryset.exclude(users=None)
        return queryset


class EndUserListFileViewSet(ListFileViewSet):
    serializer_class = serializers.EndUserFileSerializer

    def get_queryset(self):
        queryset = self.queryset
        queryset = queryset.filter(users__id=self.request.user.id)
        return queryset


class EndUserListSharedFileViewSet(UserRequired, viewsets.ModelViewSet):
    http_method_names = ['get', ]
    serializer_class = serializers.FileAccessSerializer
    queryset = FileAccess.objects.all()
    model = FileAccess

    def get_queryset(self):
        queryset = self.queryset
        queryset = queryset.filter(user=self.request.user)
        return queryset


class DeleteFileViewSet(ListFileViewSet):
    http_method_names = ['delete', ]

    def get_queryset(self):
        user = self.request.user
        if user.admin:
            queryset = Files.objects.all()
            return queryset


class UserRequestDetailsViewSet(mixin.UserProfileMixin):
    serializer_class = serializers.UserFileRequestDetailsSerializer
    model = User


class AccessRequestViewSet(mixin.UserProfileMixin, viewsets.ModelViewSet):
    http_method_names = ['get', 'post', ]
    serializer_class = serializers.AccessRequestSerializer
    model = AccessRequest
    queryset = AccessRequest.objects.all()

    def perform_create(self, serializer):
        file_obj = Files.objects.get(id=self.request.POST.get('file'))
        serializer.save(from_user=self.request.user, to_user=file_obj.created_by, file=file_obj, )

    def get_queryset(self):
        return self.queryset.filter(from_user=self.request.user)


class ExternalAccessRequestViewSet(AccessRequestViewSet):
    http_method_names = ['get', ]
    serializer_class = serializers.AccessRequestSerializer

    def get_queryset(self):
        return self.queryset.filter(to_user=self.request.user)


class FileDetailsViewSet(UserRequired, viewsets.ModelViewSet):
    http_method_names = ['get', ]
    serializer_class = serializers.FileDetailSerializer
    model = Files
    queryset = Files.objects.all()

    def get_queryset(self):
        return self.queryset.filter(created_by=self.request.user)
        # user = self.request.user
        # if user.admin:
        #     return self.queryset
        # return self.queryset.filter(users__id__in=[self.request.user.id])


class UploadedFileDetailsViewSet(FileDetailsViewSet):
    serializer_class = serializers.FileDetailSerializer

    def get_queryset(self):
        queryset = self.queryset.filter(created_by=self.request.user)
        return queryset


class ManageRequestViewSet(mixin.UserProfileMixin, viewsets.ModelViewSet):
    http_method_names = ['put', ]
    serializer_class = serializers.ManageAccessRequestSerializer
    model = AccessRequest
    queryset = AccessRequest.objects.all()

    def perform_update(self, serializer):
        if self.request.POST.get('action') == 'rejected':
            serializer.save(status=AccessRequest.REJECTED)
        elif self.request.POST.get('action') == 'granted':
            api = Savoir(settings.RPC_USER, settings.RPC_PASSWORD, settings.RPC_HOST, settings.RPC_PORT,
                         settings.CHAIN_NAME)
            data = serializer.save(status=AccessRequest.APPROVED)
            asset = api.sendassettoaddress(data.user.wallet, data.file.asset_name, 1)

    def get_queryset(self):
        user = self.request.user
        if user.admin:
            return self.model.objects.all()
        return []


class FileUploadView(views.APIView):
    permission_classes = [mixin.permissions.IsAuthenticated, ]
    authentication_classes = [mixin.ExpiringTokenAuthentication, ]

    def post(self, request, *args, **kwargs):
        ctx = {}
        form = UploadFileForm({'title': request.POST.get('title'), 'file': request.FILES.get('file')})
        if form.is_valid():
            encrypted_file, asset_name, file_hash = handle_uploaded_file(request.FILES['file'], request.user)
            form = UploadFileForm({'title': request.POST.get('title'), 'file': encrypted_file,
                                   'asset_name': asset_name, 'file_hash': file_hash})
            form.save()
            ctx['status'] = 'success'
            return Response(ctx)
        ctx['status'] = 'error'
        ctx['errors'] = dict(form.errors.items())
        return Response(ctx)


class FileManagerViewSet(mixin.UserProfileMixin, viewsets.ModelViewSet):
    http_method_names = ['get', 'put', 'post', 'delete' ]
    serializer_class = serializers.FileManagerSerializer
    model = FileManager
    queryset = FileManager.objects.all()
    pagination_class = None

    def get_queryset(self):
        queryset = self.queryset.filter(user=self.request.user)
        if self.request.GET.get('load') == 'initial':
            queryset = queryset.filter(Q(parent=None) | Q(parent__text='/'))
        elif self.request.GET.get('load'):
            queryset = queryset.filter(Q(parent__id=self.request.GET.get('load')) | Q(id=self.request.GET.get('load')))
        return queryset


class UpdateFileManagerView(views.APIView):
    permission_classes = [mixin.permissions.IsAuthenticated, ]

    def post(self, request, *args, **kwargs):
        ctx = {}
        if self.request.POST.get('action') == 'delete':
            file_manager = FileManager.objects.get(id=self.request.POST.get('parent'))
            file_obj = Files.objects.get(id=self.request.POST.get('id'))
            file_manager.files.remove(file_obj)
        elif self.request.POST.get('id') and self.request.POST.get('parent'):
            file_manager = FileManager.objects.get(id=self.request.POST.get('parent'))
            file_obj = Files.objects.get(id=self.request.POST.get('id'))
            file_manager.files.add(file_obj)
        if self.request.POST.get('action') == 'cut' and self.request.POST.get('cut_parent'):
            file_manager = FileManager.objects.get(id=self.request.POST.get('cut_parent'))
            file_manager.files.remove(file_obj)
        ctx['status'] = 'success'
        return Response(ctx)


class CreateFileManagerView(views.APIView):
    permission_classes = [mixin.permissions.IsAuthenticated, ]

    def post(self, request, *args, **kwargs):
        ctx = {}
        file_manager = FileManager.objects.get(id=self.request.POST.get('id'))
        file_manager_id = file_manager.id
        if self.request.POST.get('action') == 'delete':
            file_manager.delete()
            ctx['status'] = 'success'
            return Response(ctx)
        parent = FileManager.objects.get(id=self.request.POST.get('parent'))
        if self.request.POST.get('action') == 'copy':
            files_obj = file_manager.files.all()
            file_manager.pk = None
            file_manager.parent = parent
            file_manager.save()
            for item in files_obj:
                file_manager.files.add(item)
            copy_folder([{'id': file_manager_id, 'parent': file_manager.id}])
        if self.request.POST.get('action') == 'cut':
            file_manager.parent = parent
            file_manager.save()
        ctx['status'] = 'success'
        return Response(ctx)


class CreateFolderView(views.APIView):
    permission_classes = [mixin.permissions.IsAuthenticated, ]

    def post(self, request, *args, **kwargs):
        ctx = {}
        if request.POST.get('name'):
            parent = FileManager.objects.get(id=request.POST.get('parent'))
            file_manager = FileManager.objects.create(user=request.user, text=request.POST.get('name'), parent=parent)
            file_manager.save()
            ctx['status'] = 'success'
            ctx['id'] = file_manager.id
            return Response(ctx)
        ctx['status'] = 'error'
        return Response(ctx)


class RenameFolderView(views.APIView):
    permission_classes = [mixin.permissions.IsAuthenticated, ]

    def post(self, request, *args, **kwargs):
        ctx = {}
        if request.POST.get('name') and request.POST.get('id'):
            file_manager = FileManager.objects.get(id=request.POST.get('id'))
            file_manager.text = request.POST.get('name')
            file_manager.save()
            ctx['status'] = 'success'
            return Response(ctx)
        ctx['status'] = 'error'
        return Response(ctx)


class UserFileTransferGenerateOPTView(views.APIView):
    permission_classes = [mixin.permissions.IsAuthenticated, ]

    def post(self, request, *args, **kwargs):
        ctx = dict()
        ctx['status'] = 'error'
        try:
            user = User.objects.get(email=request.POST.get('email'))
            if not user.wallet:
                user = None
                ctx['status'] = 'email_error'
        except:
            user = None
            ctx['status'] = 'email_error'
        try:
            file_access = FileAccess.objects.get(file__id=request.POST.get('file_id'), user=request.user)
            quantity = True
            if file_access.wallet_balance < int(request.POST.get('quantity'))+1:
                if user:
                    ctx['status'] = 'qty_error'
                quantity = False
        except:
            file_access = False
            if user:
                ctx['status'] = 'qty_error'
        if user and file_access and quantity:
            response = send_otp(request)
            request.session['transfer_to_email'] = request.POST.get('email')
            request.session['transfer_quantity'] = request.POST.get('quantity')
            request.session['file_id'] = request.POST.get('file_id')
            ctx['status'] = 'success'
            if not request.user.wallet_two_factor:
                file_transfer(request)
                ctx['status'] = 'completed'
        return Response(ctx)


class UserFileTransferView(views.APIView):
    permission_classes = [mixin.permissions.IsAuthenticated, ]

    def post(self, request, *args, **kwargs):
        ctx = dict()
        if request.POST.get('otp'):
            response = verify_otp(request)
            if response and request.session.get('transfer_to_email') and request.session.get('transfer_quantity'):
                file_transfer(request)
                ctx['status'] = 'success'
            else:
                ctx['status'] = 'invalid_otp'
        else:
            ctx['status'] = 'error'
        del request.session['transfer_to_email']
        del request.session['transfer_quantity']
        del request.session['file_id']
        return Response(ctx)


class ContactUsViewSet(viewsets.ModelViewSet):
    """
    View for saving Contact request
    @inputparams;
    {
        "name:23",
        "email:enduser@cyberblocs.com",
        "subject:help",
        "message:Lorem Ipsum"
    }
    @outputparams;
    {
        "id:3",
        "name:23",
        "email:enduser@cyberblocs.com",
        "subject:help",
        "message:Lorem Ipsum"
    }
    """
    http_method_names = ['post', 'get']
    serializer_class = serializers.ContactUsSerializer
    model = ContactRequest
    queryset = ContactRequest.objects.all()


class TransactionCount(views.APIView):
    """
    View for returning Transaction details
    @outputparams;
    {
        "transactions_count:3",
        "wallets_count:23",
        "email:files_count@cyberblocs.com"
    }
    """

    @staticmethod
    def get(request, *args, **kwargs):
        ctx = dict()
        ctx['transactions_count'] = Transactions.objects.all().count()
        ctx['wallets_count'] = User.objects.all().count()
        ctx['files_count'] = Files.objects.all().count()
        return Response(ctx)
