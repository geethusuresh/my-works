from django.conf.urls import url
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import TemplateView

from apps.accounts import views


urlpatterns = [
                url(r'^login/$', views.LoginView.as_view(), name='login'),
                url(r'^two-factor-authentication/$', views.TwoFactorAuthenticationSetupView.as_view(),
                    name='two_factor'),
                url(r'^verify-token/$', views.VerifyTokenView.as_view(), name='verify_token'),
                url(r'^disable-two-factor/$', views.TwoFactorDisableView.as_view(), name='disable_two_factor'),
                url(r'^priority-two-factor/$', views.TwoFactorOptionView.as_view(), name='two_factor_options'),
                url(r'^login/next/validate-otp/$', views.TwoFactorLoginView.as_view(), name='login_otp'),
                url(r'^password-change/$', views.ChangePassword.as_view(), name='password_change'),

                url(r'^password_reset/$', 'django.contrib.auth.views.password_reset',
                   {'template_name': 'accounts/password_reset_form.html'}, name='password_reset'),
                url(r'^password_reset/done/$', 'django.contrib.auth.views.password_reset_done',
                   {'template_name': 'accounts/password_reset_done.html'}, name='password_reset_done'),
                url(r'^reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
                   'django.contrib.auth.views.password_reset_confirm', {'template_name': 'accounts/password_reset_confirm.html'},  name='password_reset_confirm'),
                url(r'^reset/done/$', 'django.contrib.auth.views.password_reset_complete',
                   {'template_name': 'accounts/password_reset_complete.html'}, name='password_reset_complete'),
                ]
