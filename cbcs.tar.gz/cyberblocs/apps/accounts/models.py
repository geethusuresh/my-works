# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.template import loader
from django.core.mail import send_mail
from django.contrib.auth.models import AbstractUser
from django.db.models.signals import post_save
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.contrib.auth.tokens import default_token_generator
from django.conf import settings

from apps.multichain.models import AccessRequest


class User(AbstractUser):
    PHONE = 'p'
    EMAIL = 'e'
    TWO_FACTOR_CHOICES = ((PHONE, 'Phone'), (EMAIL, 'Email'))
    admin = models.BooleanField(default=False)
    wallet = models.CharField(max_length=256, null=True, blank=True)
    image = models.ImageField(upload_to='profile', default='/static/images/user-img-dummy.jpg')
    phone_number = models.CharField(max_length=32, null=True, blank=True)
    two_factor_method = models.CharField(max_length=1, choices=TWO_FACTOR_CHOICES, null=True, blank=True)
    login_two_factor = models.BooleanField(default=False)
    wallet_two_factor = models.BooleanField(default=False)

    def __unicode__(self):
        if self.first_name == '':
            return self.username
        else:
            return u'%s %s' % (self.first_name, self.last_name)

    def save(self, *args, **kwargs):
        if not self.pk:
            user = self
            if self.email:
                user.username = self.email
        super(User, self).save(*args, **kwargs)

    def get_file_requests(self):
        return AccessRequest.objects.filter(user__id=self.id)


def send_password_reset_email(sender, instance, **kwargs):
    if kwargs['created'] and not instance.is_superuser and instance.email:
        user = instance
        protocol = 'http'
        domain = settings.DOMAIN
        subject_template_name = 'accounts/password_reset_subject.txt'
        email_template_name = 'accounts/password_reset_email.html'
        from_email = settings.DEFAULT_FROM_EMAIL
        c = {
            'email': user.email,
            'domain': domain,
            'protocol': protocol,
            'uid': urlsafe_base64_encode(force_bytes(user.pk)),
            'user': user,
            'token': default_token_generator.make_token(user),
        }
        subject = loader.render_to_string(subject_template_name, c)
        # Email subject *must not* contain newlines
        subject = ''.join(subject.splitlines())
        email = loader.render_to_string(email_template_name, c)
        try:
            send_mail(subject, email, from_email, [user.email])
        except:
            pass
post_save.connect(send_password_reset_email, sender=User, dispatch_uid="send_password_reset_email")
