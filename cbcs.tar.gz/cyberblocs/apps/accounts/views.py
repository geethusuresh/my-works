# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import json

from django.shortcuts import render
from django.http import HttpResponse
from django.core.urlresolvers import reverse
from django.conf import settings
from django.http import HttpResponseRedirect
from django.views.generic import TemplateView
from django.shortcuts import get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm

import pyotp
from twilio.rest import Client

from apps.accounts.models import User
from apps.utils.views import JSONResponseMixin, two_factor_email

totp = pyotp.TOTP('base32secret3232')


class LoginView(TemplateView, JSONResponseMixin):
    template_name = 'accounts/sign_in.html'

    def get(self, request, *args, **kwargs):
        if self.request.user.is_authenticated():
            return HttpResponseRedirect(reverse('dashboard'))
        return render(request, self.template_name, {})

    def post(self, request, *args, **kwargs):
        ctx = {}
        login_form = AuthenticationForm(data=request.POST)
        if not request.POST.get('remember_me', None):
            request.session.set_expiry(0)
        if login_form.is_valid():
            user = authenticate(username=request.POST['username'], password=request.POST['password'])
            if user is not None:
                if user.is_active and not user.login_two_factor:
                    login(request, user)
                    ctx['status'] = 'success'
                    return HttpResponse(json.dumps(ctx), content_type='application/json')
                elif user.is_active and user.login_two_factor:
                    token = totp.now()
                    request.session['two_factor'] = {'token': token, 'user': user.id}
                    if user.two_factor_method == User.PHONE:
                        request.session['sent_to'] = user.phone_number
                        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)

                        text = "Your CyberBlocs One time password is " + token
                        client.messages.create(to=user.phone_number, from_=settings.TWILIO_DEFAULT_CALLERID,
                                               body=text)
                    else:
                        request.session['sent_to'] = user.email
                        two_factor_email({'to': user.email, 'otp': token})
                    ctx['status'] = 'two_factor'
                    return HttpResponse(json.dumps(ctx), content_type='application/json')
                else:
                    ctx['errors'] = 'User is inactive'
            else:
                ctx['errors'] = 'Invalid User'
        else:
            ctx['errors'] = login_form.errors
            ctx['non_field_errors'] = login_form.non_field_errors()
        return HttpResponse(json.dumps(ctx), content_type='application/json')


class ProfileView(TemplateView):
    """
    View to render basic profile page.
    """
    template_name = 'multichain/dashboard.html'

    def get_context_data(self, **kwargs):
        context = super(ProfileView, self).get_context_data(**kwargs)
        context['user'] = get_object_or_404(User, username=self.request.user.username)
        return context


class ChangePassword(TemplateView):
    template_name = 'multichain/change_password.html'

    def post(self, request, *args, **kwargs):
        user = request.user
        old_password = request.POST.get('old_password', None)
        password1 = request.POST.get('password1', None)
        password2 = request.POST.get('password2', None)
        if user.check_password(old_password) and password1 == password2:
            user.set_password(password1)
            user.save()
            return HttpResponseRedirect(reverse('password_reset_complete') + '?change=true')
        return render(request, self.template_name, {'status': 'error'})


class TwoFactorAuthenticationSetupView(TemplateView):
    template_name = 'accounts/two_factor.html'

    def post(self, request, *args, **kwargs):
        user = request.user
        if request.POST.get('type') == 'mobile' and request.POST.get('phone_number'):
            user.phone_number = request.POST.get('phone_number')
            user.save()
            client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
            token = totp.now()
            request.session['two_factor'] = {'token': token, 'type': 'mobile',
                                             'phone_number': request.POST.get('phone_number')}
            request.session['sent_to'] = user.phone_number
            text = "Your CyberBlocs One time password is " + token
            client.messages.create(to=request.POST.get('phone_number'), from_=settings.TWILIO_DEFAULT_CALLERID,
                                   body=text)
            return HttpResponseRedirect(reverse('verify_token'))
        if request.POST.get('type') == 'email':
            token = totp.now()
            request.session['sent_to'] = user.email
            request.session['two_factor'] = {'token': token, 'type': 'email', }
            two_factor_email({'to': user.email, 'otp': token})
            return HttpResponseRedirect(reverse('verify_token'))
        return render(request, self.template_name, {'status': 'error'})


class VerifyTokenView(TemplateView):
    template_name = 'accounts/verify_token.html'

    def post(self, request, *args, **kwargs):
        user = request.user
        if request.POST.get('otp') and request.session.get('two_factor')['token'] == request.POST.get('otp'):
            if totp.verify(request.POST.get('otp')) or not totp.verify(request.POST.get('otp')):
                if 'wallet_transfer' in request.session:
                    return HttpResponseRedirect(reverse('two_factor_manage_request'))
                else:
                    return HttpResponseRedirect(reverse('two_factor_options'))
        return HttpResponseRedirect(reverse('verify_token') + '?verify=incorrect')


class TwoFactorDisableView(TemplateView):
    template_name = 'accounts/verify_token.html'

    def get(self, request, *args, **kwargs):
        user = request.user
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        token = totp.now()
        request.session['two_factor_token'] = token
        request.session['two_factor_disable'] = True
        request.session['phone_number'] = user.phone_number
        text = "Your CyberBlocs One time password is " + token
        message = client.messages.create(to=user.phone_number, from_=settings.TWILIO_DEFAULT_CALLERID,
                                         body=text)
        return HttpResponseRedirect(reverse('verify_token'))


class TwoFactorOptionView(TemplateView):
    template_name = 'accounts/two_factor_options.html'

    def post(self, request, *args, **kwargs):
        user = request.user
        user.login_two_factor = False
        user.wallet_two_factor = False
        if request.POST.get('two_factor_login'):
            user.login_two_factor = True
        if request.POST.get('wallet_two_factor'):
            user.wallet_two_factor = True
        if request.session['two_factor']['type'] == 'mobile':
            user.two_factor_method = User.PHONE
        if request.session['two_factor']['type'] == 'email':
            user.two_factor_method = User.EMAIL
        user.save()
        del request.session['two_factor']
        return HttpResponseRedirect(reverse('dashboard') + '?two_factor=updated')


class TwoFactorLoginView(TemplateView):
    template_name = 'accounts/verify_token.html'

    def post(self, request, *args, **kwargs):
        if request.POST.get('otp') and request.session.get('two_factor')['token'] == request.POST.get('otp'):
            if totp.verify(request.POST.get('otp')) or not totp.verify(request.POST.get('otp')):
                user = User.objects.get(id=request.session['two_factor']['user'])
                user.backend = 'django.contrib.auth.backends.ModelBackend'
                login(request, user)
                del request.session['two_factor']
                return HttpResponseRedirect(reverse('dashboard'))
        return HttpResponseRedirect(reverse('login') + '?otp=false')
