__author__ = 'savad'
import random
import re

from django.contrib.auth.forms import AuthenticationForm
from django import forms
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ObjectDoesNotExist

from apps.accounts.models import User


class SignupForm(forms.ModelForm):
    """
    form for user signup
    """
    first_name = forms.CharField(label=_("First Name"))
    last_name = forms.CharField(label=_("Last Name"))
    email = forms.EmailField(label=_("Email"))
    # password = forms.CharField(label=_("Password"), widget=forms.PasswordInput,)

    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email', )

    def __init__(self, *args, **kwargs):
        super(SignupForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].widget.attrs['placeholder'] = _('Full Name')
        self.fields['email'].widget.attrs['placeholder'] = _('Email')
        # self.fields['password'].widget.attrs['placeholder'] = _('Password')
        self.fields['first_name'].widget.attrs['class'] = 'form-control'
        self.fields['email'].widget.attrs['class'] = 'form-control'
        # self.fields['password'].widget.attrs['class'] = 'form-control password_show'

    def save(self, commit=True, **kwargs):
        user = super(SignupForm, self).save(commit=False, **kwargs)
        first_name = self.cleaned_data['first_name']
        data = {'first_name': first_name}
        user.username = self.generate_username(**data)
        # user.set_password(self.cleaned_data['password'])
        user.save()
        return user

    def generate_username(self, first_name=None, username=None):
        first_name = re.sub(' ', '', first_name)
        if first_name:
            username = first_name.lower()
        try:
            User.objects.get(username=username)
            username = self.get_random_user(username)
            self.generate_username(username)
        except:
            pass
        return username

    def get_random_user(self, username):
        username = username + str(random.randint(1, 1000))
        return username

    def clean_email(self):
        email = self.cleaned_data["email"]
        email = str(email)
        try:
            User.objects.get(email=email)
        except User.DoesNotExist:
            return email
        raise forms.ValidationError(_("This email ID already exists."))


class LoginForm(AuthenticationForm):
    """
    Form for using login
    """
    username = forms.EmailField(label=_("Email"))
    password = forms.CharField(label=_("Password"), widget=forms.PasswordInput,)

    def __init__(self, *args, **kwargs):
        super(LoginForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs['placeholder'] = _('Email')
        self.fields['username'].widget.attrs['class'] = 'form-control'
        self.fields['password'].widget.attrs['placeholder'] = _('Password')
        self.fields['password'].widget.attrs['class'] = 'form-control'


class UserCreationAdminForm(UserCreationForm):
    """
    Override to use custom user model in django admin user creation
    """
    def clean_username(self):
        # Since User.username is unique, this check is redundant,
        # but it sets a nicer error message than the ORM. See #13147.
        username = self.cleaned_data["username"]
        try:
            User._default_manager.get(username=username)
        except User.DoesNotExist:
            return username
        raise forms.ValidationError(
            self.error_messages['duplicate_username'],
            code='duplicate_username',
        )


class EditProfileForm(forms.ModelForm):
    """
    form for updating user profile information
    """
    first_name = forms.CharField(label=_("First Name"))
    email = forms.EmailField(label=_("Email"))

    class Meta:
        model = User
        fields = ('first_name', 'email', )


class EditProfileImageForm(forms.ModelForm):
    image = forms.ImageField(label=_("Image"))

    class Meta:
        model = User
        fields = ('image', )