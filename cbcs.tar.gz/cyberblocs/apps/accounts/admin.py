from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import ugettext_lazy as _

from models import User
from apps.accounts import forms


class UserAdmin(UserAdmin):
    add_form = forms.UserCreationAdminForm
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        (_('Personal info'), {'fields': ('first_name', 'last_name', 'email', 'image', 'wallet', 'phone_number',
                                         'login_two_factor', 'wallet_two_factor', 'two_factor_method', 'admin')}),
        (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser',
                                       'groups', 'user_permissions')}),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
    )
    filter_horizontal = ('groups', 'user_permissions',)
    # readonly_fields = ('wallet', )


admin.site.register(User, UserAdmin)

