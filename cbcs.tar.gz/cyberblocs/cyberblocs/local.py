import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RPC_USER = 'multichainrpc'
RPC_PASSWORD = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
RPC_HOST = 'localhost'
RPC_PORT = '7204'
CHAIN_NAME = 'casb'
ADMIN_ADDRESS = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}


EMAIL_HOST = '192.168.31.35'
EMAIL_PORT = 25
EMAIL_HOST_USER = 'CyberBlocs@marlabs.com'
DEFAULT_FROM_EMAIL = 'CyberBlocs@marlabs.com'
SALES_EMAIL = 'savad.ali@marlabs.com'