function CyberBlocsController($scope, $http){

    $scope.file_manager = false;
    $scope.shared_files = false;
    $scope.files = false;
    $scope.parent = false;
    $scope.prev_parent = [];
    $scope.next_parent = [];
    $scope.node = ['Home'];
    $scope.prev_node = [];
    $scope.next_node = [];

    $scope.copy_id = false;
    $scope.copy_type = false;

    $scope.cut_id = false;
    $scope.cut_type = false;
    $scope.cut_parent = false;

    $scope.paste_name = false;
    $scope.refresh = false;

    $scope.current_files = false;
    $scope.current_folders = false;
    $scope.next_files = [];
    $scope.next_folders = [];
    $scope.prev_files = [];
    $scope.prev_folders = [];

    $scope.choose_email = true;

    $scope.menu_items = {
                "open": {name: "Open"},
                "cut": {name: "Cut"},
                "copy": {name: "Copy"},
                "delete": {name: "Delete"}

            };

    $scope.paste_menu_enable = function (){
        $scope.menu_items = {
                "open": {name: "Open"},
                "cut": {name: "Cut"},
                "copy": {name: "Copy"},
                "paste": {name: "Paste"},
                "delete": {name: "Delete"}

            }
    };

    $scope.paste_menu_disable = function (){
        $scope.menu_items = {
                "open": {name: "Open"},
                "cut": {name: "Cut"},
                "copy": {name: "Copy"},
                "delete": {name: "Delete"}

            }
    };

    $scope.csrf_token = $('input[name="csrfmiddlewaretoken"]').val();

    $('#transaction_table').DataTable({
        "columns": [
            null, null, null, null, null
        ]
    });

    $scope.ListFiles = function () {
        $http.get("/api/v1/list-files/?type=shared")
        .then(function(response) {
            $scope.files = response.data;
        });
    };

    $scope.UploadedFiles = function () {
        $http.get("/api/v1/uploaded-files/")
        .then(function(response) {
            $scope.uploaded_files = response.data;
        });
    };

    $scope.EndUserListFiles = function () {
        $http.get("/api/v1/end-user-list-files/")
        .then(function(response) {
            $scope.files = response.data;
        });
    };

    $scope.EndUserListSharedFiles = function () {
        $http.get("/api/v1/end-user-list-shared-files/")
        .then(function(response) {
            $scope.shared_files = response.data;
        });
    };

    $scope.MyAccessRequestList = function () {
        $http.get("/api/v1/access-request/")
        .then(function(response) {
            $scope.requested_files = response.data;
        });
    };

    $scope.AccessRequests = function () {
        $http.get("/api/v1/external-access-request/")
        .then(function(response) {
            $scope.access_requests = response.data;
        });
    };

    $scope.ShowUsers = function (id) {
        $scope.file_accessing_users = []
        var url = "/api/v1/file-granted-users/?file_id="+id;
        $http.get(url)
        .then(function(response) {
            $scope.file_accessing_users = response.data;
        });
    };

    $scope.TransferFile = function (id) {
        $scope.transfer_file = []
        angular.forEach($scope.shared_files, function(v, k) {
            if(v.file_details.id == id){
                $scope.transfer_file=v;
            }
        });

    };

    $scope.showEditWindow = function (id) {
        $scope.edit_window = true;
    };

    $scope.turnOffEditWindow = function (id) {
        $scope.edit_window = false;
        $('#image_file').val('');
        $('#profile_edit_image').attr('src', $('#profile_image').attr('src'));
    };

    $scope.showEmail = function () {
        $scope.choose_email = true;
        $scope.choose_mobile = false;
    };

    $scope.showMobile = function () {
        $scope.choose_email = false;
        $scope.choose_mobile = true;
    };

    $scope.validateTwoFactorTypeForm = function () {
        var val = $( 'input[name=type]:checked' ).val();
        if (val=='mobile'){
            var mobile = $('#phone_number').val();
            if (!mobile){
                swal("Error!", "Please enter mobile number with country code!", "error"); return false;
            }
            if(mobile.charAt(0)!='+'){
                swal("Invalid Phone Number!", "Please enter mobile number with country code!", "error"); return false;
            }
        }
        $('#otp_form').submit();
    };

    $scope.removePic = function () {
        $('#profile_image').attr('src', '/static/images/user-img-dummy.jpg');
        $('#image_file').val('');
        $('#remove_prof_img').val('true');
        $('#remove_pic').attr('style', 'display: none');
    };

    $scope.SendAccessRequest = function ($event) {
        var elmt = $event.currentTarget;
        swal({
          title: "Are you sure?",
          text: "Your doc access request will forward to the doc owner for an approval",
          type: "input",
          showCancelButton: true,
          confirmButtonColor: "#40a062",
          confirmButtonText: "Yes, Request it!",
          closeOnConfirm: false,
          inputPlaceholder: "Write your Comment"
        },
        function(inputValue){
          if (inputValue === false) return false;

          if (inputValue === "") {
            swal.showInputError("You need to write something!");
            return false;
          }
            $(elmt).closest("form").append("<input type='hidden' name='requester_comment' value='"+inputValue+"'>")
            $(elmt).closest("form").submit();
        });
    };

    $scope.FileApprove = function ($event) {
       var elmt = $event.currentTarget;
        var balance = $(elmt).attr('balance');
        console.log(balance, 'balance')
       swal({
          title: "Are you sure?",
          text: "Once you approve this request, you will not be able to revoke in future. Please enter your comments",
          type: "input",
          showCancelButton: true,
          confirmButtonColor: "#40a062",
          confirmButtonText: "Proceed",
          closeOnConfirm: false
        },
        function(inputValue){
          if (inputValue === false) return false;

          if (inputValue === "") {
            swal.showInputError("Please enter your comment!");
            return false;
          }
            $(elmt).closest("form").append("<input type='hidden' name='reason' value='"+inputValue+"'>")
            swal({
              title: "Enter the quantity",
              text: "Please specify the quantity.\n Number of transfer available is " + balance,
              type: "input",
              inputType: "number",
              showCancelButton: true,
              confirmButtonColor: "#40a062",
              confirmButtonText: "Yes, Approve it!",
              closeOnConfirm: false
            },
            function(inputValue){
              if (inputValue === false) return false;

              if (inputValue === "") {
                  swal.showInputError("Please enter valid quantity");
                  return false;
              }
              else if (inputValue > balance) {
                  swal.showInputError("Please enter the lesser quantity");
                  return false;
              }else{
                $(elmt).closest("form").append("<input type='hidden' name='quantity' value='"+inputValue+"'>")
                $(elmt).closest("form").submit();
              }
            });$(':input[type="number"]').attr('min', 1); $(':input[type="number"]').attr('max', balance);
        });
    };

    $scope.FileReject = function ($event) {
        var elmt = $event.currentTarget;
        swal({
          title: "Are you sure?",
          text: "Why you are rejecting?",
          type: "input",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Yes, Reject it!",
          closeOnConfirm: false
        },
        function(inputValue){
          if (inputValue === false) return false;

          if (inputValue === "") {
            swal.showInputError("You need to write something!");
            return false;
          }
            $(elmt).closest("form").append("<input type='hidden' name='reason' value='"+inputValue+"'>")
            $(elmt).closest("form").submit();
        });
    };

    $scope.TransferGenerateOTP = function () {
        $('.transfer_hide').hide();
        $http({
            method: 'POST',
            url: '/api/v1/transfer-generate-otp/',
            headers : {'Content-Type' : 'application/x-www-form-urlencoded',},
            data: $.param({'email': $scope.transfer_to_email,
                           'quantity': $scope.transfer_quantity,
                           'file_id': $scope.transfer_file.file_details.id,
                           'csrfmiddlewaretoken':$scope.csrf_token})
            })
        .then(function(response) {
            if (response.data.status=='success'){$('.transfer_otp').show();}
            else if(response.data.status=='email_error'){swal("Error!", "Invalid email ID!", "error");
                $scope.transfer_to_email = "";
                $scope.transfer_quantity = "";
                $('.transfer_hide').show();
            }else if(response.data.status=='qty_error'){swal("Error!", "Invalid Quantity!", "error");
                $scope.transfer_to_email = "";
                $scope.transfer_quantity = "";
                $('.transfer_hide').show();
            }else if(response.data.status=='completed'){
                $scope.transfer_quantity = "";
                swal("Success!", "Successfully transferred!", "success"); $('.transfer_hide').show();$('#sharepopup').modal('hide');
            }
            else{ swal("Error!", "Something went wrong!", "error"); $scope.transfer_to_email = "";
                $scope.transfer_quantity = "";
                $scope.transfer_to_email = "";
                $('.transfer_hide').show();}
        });

    };

    $scope.TransferConfirm = function () {
        $('.transfer_hide').show();
        $('.transfer_otp').hide();
        $scope.transfer_to_email = "";
        $http({
            method: 'POST',
            url: '/api/v1/transfer-confirm/',
            headers : {'Content-Type' : 'application/x-www-form-urlencoded',},
            data: $.param({'otp': $scope.transfer_otp,
                           'csrfmiddlewaretoken':$scope.csrf_token})
            })
        .then(function(response) { console.log(response)
            $('.close').click();
            $scope.transfer_otp = "";
            $('.transfer_otp').hide();
            $('.transfer_hide').show();
            if (response.data.status=='success'){
                angular.forEach($scope.shared_files, function(v, k) {
                    if(v.file_details.id == $scope.transfer_file.id){
                        v.wallet_balance=v.wallet_balance-$scope.transfer_quantity;
                    }
                });

                $scope.transfer_quantity = "";
                swal("Success!", "Successfully transferred!", "success");
            }else{ swal("Error!", "OTP verification failed!", "error"); $scope.transfer_quantity = ""; }
        });

    };

    $scope.ngRepeatFinishedAllFiles = function (){
        $('#file_table').DataTable({
            "columns": [
                null, null, {"orderable": false}
            ]
        });
    };

    $scope.ngRepeatFinishedAutherizedFiles = function (){
        $('#autherized_file_table').DataTable({
            "columns": [
                null, null, {"orderable": false}, null, {"orderable": false}
            ]
        });
    };

    $scope.ngRepeatUploadFilesFinished = function (){
        $('#uploaded_files').DataTable({
            "columns": [
                null, null, {"orderable": false}, {"orderable": false}, {"orderable": false}, null, {"orderable": false}, {"orderable": false}
            ]
        });
    };

    $scope.DeleteFileManager = function (id) {
        $http({
            method: 'POST',
            url: '/api/v1/create-file-manager/',
            headers : {'Content-Type' : 'application/x-www-form-urlencoded',},
            data: $.param({'id': id, 'action': 'delete', 'csrfmiddlewaretoken':$scope.csrf_token})
            })
        .then(function(response) {
            // on success
        });
    };

    $scope.UpdateFileManager = function (id, parent, action) {

        var file_exist = false;
        if(action!='delete') {
            angular.forEach($scope.current_files, function (v, k) {
                if (v.name.toLowerCase() === $scope.paste_name.toLowerCase()) {
                    file_exist = true;
                }
            });
        };

        if (file_exist){
            $scope.cut_id = false;
            $scope.copy_id = false;
            $scope.RefreshFileManager(); swal("Error!", "Another file with same name already exist", "error");
            return false;
         }

        $http({
            method: 'POST',
            url: '/api/v1/update-file-manager/',
            headers : {'Content-Type' : 'application/x-www-form-urlencoded',},
            data: $.param({'id': id, 'parent': parent, 'action': action, 'cut_parent': $scope.cut_parent, 'csrfmiddlewaretoken':$scope.csrf_token })
            })
        .then(function(response) {
            $scope.copy_id = false;
            $scope.cut_id = false;
            $scope.RefreshFileManager();
        });
    };

    $scope.UpdateFolder = function (id, parent, action) {

            if (action=='cut'){
                if (id==parent){
                   $scope.cut_id = false;
                    $scope.copy_id = false;
                    $scope.RefreshFileManager(); swal("Error!", "You cannot move a folder into itself.", "error");
                    return false;
                }
            }

            folder_exist = false;
            angular.forEach($scope.current_folders, function(v, k) {
                if(v.name.toLowerCase() === $scope.paste_name.toLowerCase()){
                    folder_exist = true;
                }
            });

            if (folder_exist){
                    $scope.cut_id = false;
                    $scope.copy_id = false;
                    $scope.RefreshFileManager(); swal("Error!", "Folder with same name already exist", "error");
                    return false;
             }

            $http({
                method: 'POST',
                url: '/api/v1/create-file-manager/',
                headers : {'Content-Type' : 'application/x-www-form-urlencoded',},
                data: $.param({'id': id, 'parent': parent, 'action': action, 'csrfmiddlewaretoken':$scope.csrf_token})
                })
            .then(function(response) {
                $scope.copy_id = false;
                $scope.cut_id = false;
                $scope.RefreshFileManager();
            });
        };

    $scope.ListFileManager = function (id) {
        if (id == 'initial'){ url = "/api/v1/file-manager/?load=initial"}
        else{ url = "/api/v1/file-manager/?load="+ id;if ($scope.refresh == false){ $scope.prev_parent.push($scope.parent);} $scope.parent = id; }

        if ($scope.refresh == false){

            if ($scope.current_folders){
                $scope.prev_folders.push($scope.current_folders);
                $scope.current_folders=[];
                $scope.back_button = true;
            }else{
                $scope.current_folders=[];
            }
            if ($scope.current_files){
                $scope.prev_files.push($scope.current_files);
                $scope.current_files=[];
                $scope.back_button = true;
            }else{
                $scope.current_files=[];
            }

            $scope.next_parent = [];
            $scope.next_files = [];
            $scope.next_folders = [];
            $scope.next_node = [];
        }else{$scope.current_files=[]; $scope.current_folders=[];}

        $http.get(url)
        .then(function(response) {
            angular.forEach(response.data, function(value, key) {
                if ($scope.refresh == false){
                    $scope.next_file = [];
                    $scope.next_folders = [];
                    $scope.next_button = false;
                }
                if(!value.parent){
                    $scope.parent = value.id;
                    angular.forEach(value.files, function(v, k) {
                        file_type = (/[.]/.exec(v.file)) ? /[^.]+$/.exec(v.file) : undefined;
                        file = {'name': v.file, 'type': file_type[0], 'id': v.id}
                        $scope.current_files.push(file);
                    });
                }
                else if($scope.parent && value.id == $scope.parent){
                    if ($scope.refresh == false){$scope.node.push(value.text);}
                    angular.forEach(value.files, function(v, k) {
                        file_type = (/[.]/.exec(v.file)) ? /[^.]+$/.exec(v.file) : undefined;
                        file = {'name': v.file, 'type': file_type[0], 'id': v.id}
                        $scope.current_files.push(file);
                    });
                }
                else{
                    folder_data = {'name': value.text, 'id': value.id}
                    $scope.current_folders.push(folder_data);
                }$scope.refresh = false;
            });
        });
    };

    $scope.FileManagerBack = function (){
        $scope.next_node.push($scope.node.pop());
        $scope.next_files.push($scope.current_files);
        $scope.next_folders.push($scope.current_folders);
        $scope.current_files = $scope.prev_files.pop();
        $scope.current_folders = $scope.prev_folders.pop();
        $scope.next_parent.push($scope.parent);
        $scope.parent = $scope.prev_parent.pop();
        $scope.next_button = true;
        if ($scope.prev_folders.length == 0 && $scope.prev_files.length == 0){$scope.back_button = false;}
    };

    $scope.FileManagerNext = function (){
        $scope.node.push($scope.next_node.pop());
        $scope.prev_files.push($scope.current_files);
        $scope.prev_folders.push($scope.current_folders);
        $scope.current_files = $scope.next_files.pop();
        $scope.current_folders = $scope.next_folders.pop();
        $scope.prev_parent.push($scope.parent);
        $scope.parent = $scope.next_parent.pop();
        $scope.back_button = true;
        if ($scope.next_folders.length == 0 && $scope.next_files.length == 0){$scope.next_button = false;}
    };

    $scope.RefreshFileManager = function (){
        $scope.refresh = true;
        $scope.ListFileManager($scope.parent);
    };

    // Right click folder options
    $(function() {
        $.contextMenu({
            selector: '.context-menu-one',
            callback: function(key, options) {
                var m = "clicked: " + key;
                if(key == 'open'){
                    $(this).dblclick();
                }else if (key == 'copy'){
                    $scope.paste_menu_enable();
                    $scope.cut_id = false;
                    $scope.cut_parent = false;
                    $scope.copy_id = $(this).attr('data-id');
                    $scope.copy_type = $(this).attr('data-type');
                    $scope.paste_name = $(this).attr('data-name');
                    $scope.RefreshFileManager();
                }else if (key == 'cut'){
                    $scope.paste_menu_enable();
                    $scope.copy_id = false;
                    $scope.cut_id = $(this).attr('data-id');
                    $scope.cut_type = $(this).attr('data-type');
                    $scope.cut_parent = $scope.parent;
                    $scope.paste_name = $(this).attr('data-name');
                    $scope.RefreshFileManager();

                }else if(key == 'paste'){
                    $scope.paste_menu_disable();
                    if($scope.copy_id){
                        if($scope.copy_type=='folder'){
                            $scope.UpdateFolder($scope.copy_id, $scope.parent, 'copy')
                        }
                        else if($scope.copy_type=='file'){
                            $scope.UpdateFileManager($scope.copy_id, $scope.parent, 'copy')
                        }
                    }
                    else if($scope.cut_id){
                        if($scope.cut_type=='folder'){
                            $scope.UpdateFolder($scope.cut_id, $scope.parent, 'cut')
                        }
                        else if($scope.cut_type=='file'){
                            $scope.UpdateFileManager($scope.cut_id, $scope.parent, 'cut')
                        }
                    }
                }else if(key == 'delete'){
                    $(this).attr('style', 'display: none');
                    if($(this).attr('data-type')=='folder'){ $scope.DeleteFileManager($(this).attr('data-id')); }
                    else if($(this).attr('data-type')=='file'){
                        $scope.UpdateFileManager($(this).attr('data-id'),$scope.parent, 'delete')
                    }
                }
            },
            items: $scope.menu_items
        });

        $('.context-menu-one').on('click', function(e){
            // console.log('clicked', this);
        })
    });

    $scope.NewFolder = function (){
        swal({
          title: "New folder",
          text: "Enter folder name:",
          type: "input",
          showCancelButton: true,
          closeOnConfirm: false,
          animation: "slide-from-top",
          inputPlaceholder: "Folder name"
        },
        function(inputValue){
            folder_exist = false;
            if (inputValue === false) return false;

            if (inputValue === "") {
                swal.showInputError("Folder name is required!");
                return false
            }
            else if(inputValue){
                angular.forEach($scope.current_folders, function(v, k) {
                    if(v.name.toLowerCase() === inputValue.toLowerCase()){
                        folder_exist = true;
                    }
                });
            }
            if (folder_exist){swal.showInputError("Folder name already exist!"); return false}
          $http({
              method: 'POST',
              url: '/api/v1/create-folder/',
              headers : {'Content-Type' : 'application/x-www-form-urlencoded',},
              data: $.param({'name': inputValue, 'parent': $scope.parent, 'csrfmiddlewaretoken':$scope.csrf_token })
        })
        .then(function(response) {
             if(response.data.status=='success'){
                 $scope.RefreshFileManager();
             }
        });

          swal("Success!", "Your folder " + inputValue + " is created", "success");

        });

    }


}