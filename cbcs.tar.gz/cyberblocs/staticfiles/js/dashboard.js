/**
 * Created by savad on 9/8/17.
 */
$('.hidewallet').click(function(){
    $('#wallet_display').hide();
    $('#wallet_label').show();
    $('.hidewallet').hide();
});

$('#wallet_label').click(function(){
    $('#wallet_display').show();
    $('#wallet_label').hide();
    $('.hidewallet').show();
});

$(document).ready(function(){
    var elmt;
    $(".request_access").click(function (e){
        e.preventDefault();
        var elmt = e.target;

        swal({
          title: "Are you sure?",
          text: "Your doc access request will forward to Admin for an approval",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#40a062",
          confirmButtonText: "Yes, Request it!",
          closeOnConfirm: false
        },
        function(){
            $(elmt).closest("form").submit();
        });
    });
});


    function download_file(e){
        e.preventDefault();
        var elmt = e.target;
        id = $(elmt).attr('data-id');
        swal({
          title: "Sending",
          text: "Sending download request to Blockchain",
          html: true,
          timer: 2000,
          showConfirmButton: false
        },
        function(){
              swal({
              title: "Verifying your wallet",
              text: "Sending download request to Blockchain <span style='color: green'>OK</span> <br><br>Analysing your wallet balance..",
              html: true,
              timer: 2000,
              showConfirmButton: false
            },
                function(){
                      swal({
                      title: "Decrypting Doc",
                      text: "Sending download request to Blockchain <span style='color: green'>OK</span><br><br>Analysing your wallet balance <span style='color: green'>OK</span><br><br>Decrypting file using aes-256 algorithm..",
                      html: true,
                      timer: 5000,
                      showConfirmButton: false
                    },
                        function(){
                              swal({
                              title: "Ready to Download",
                              text: "Sending download request to Blockchain <span style='color: green'>OK</span><br><br>Analysing your wallet balance <span style='color: green'>OK</span><br><br>Decrypting file using aes-256 algorithm <span style='color: green'>OK</span><br><br> <button class='cancel'>Cancel</button><a href='/dashboard/downlaod-file/?id="+id+"'><button>Download</button></a> ",
                              html: true,
                               showConfirmButton: false
                            }
                            );
                        }
                    );
                }
            );
        }
        );
    };

    $(".edit_btn").click(function (e){
        $(".profile_edit").attr('style', 'display: block');
        $(".profile_edit_off").attr('style', 'display: none');
        if ( $('#profile_image').attr('src') == '/static/images/user-img-dummy.jpg' ){ $('#remove_pic').attr('style', 'display: none') }
    });
    $(".edit_cancel").click(function (e){
        $(".profile_edit").attr('style', 'display: none');
        $(".profile_edit_off").attr('style', 'display: block');
        $('#image_file').val('');
        $('#profile_image').attr('src', $('#profile_image').attr('data-src'));
    });

    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#profile_image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#image_file").change(function(){
        $('#remove_prof_img').val('false');
        $('#remove_pic').attr('style', 'display: block');
        readURL(this);
    });
    $(".remove_pic").click(function(){
        $('#profile_image').attr('src', '/static/images/user-img-dummy.jpg');
        $('#profile_edit_image').attr('src', '/static/images/user-img-dummy.jpg');
        $('#image_file').val('');
        $('#remove_prof_img').val('true');
        $('#remove_pic').attr('style', 'display: none');
    });
    $(".onoffswitch").click(function() {
        if('{{ request.user.two_factor }}' == 'True') {
            swal({
              title: "Are you sure?",
              text: "Do you want to disable two factor Authentication?",
              type: "warning",
              confirmButtonColor: "#C70039",
              showCancelButton: true,
              confirmButtonText: "Yes, Disable!",
              closeOnConfirm: false
            },
            function(isConfirm){
                if (isConfirm) {
                    window.location.href = 'disable_two_factor'
                }
            });
        }
        else{
            window.location.href = '/accounts/two-factor-authentication/'
        }
    });


    // Slide show
    $(document).ready(function(){
      $('.slidearea').slick({
       autoplay: true,
       adaptiveHeight: true,
       arrows :false
      });
    });

    $(document).ready(function(){
        $('.custom-file-input input[type="file"]').change(function(e){
            $(this).siblings('input[type="text"]').val(e.target.files[0].name);
        });
    });
    $("#upload_file").click(function (e){
        e.preventDefault();
        if (!$("#input_file").val()){ sweetAlert("Error", "Please choose a doc", "error");  return;}
        if (!$("#doc_name").val()){ sweetAlert("Error", "Please enter doc name", "error");  return;}
        var f = $("#input_file")[0].files[0]; console.log(f.size)
        if (f.size > 2048000 || f.fileSize > 2048000){ sweetAlert("Error", "The maximum allowed size is 2Mb", "error");  return;}
        $('#upload_form').submit();
     });

$(document).ready(function(){
    if ('{{ request.GET.status}}' == 'delete'){
        swal("Success!", "Doc has been deleted!", "success")
    }
    else if ('{{ request.GET.status}}' == 'create'){
        swal("Success!", "Doc has been uploaded!", "success")
    }
    else if ('{{ request.GET.status}}' == 'error'){
        swal("Error!", "Some thing went wrong!", "error")
    }
    else if ('{{ request.GET.verify}}' == 'true'){
        swal("Success!", "Your Account is protected with two factor authentication", "success")
    }
    else if ('{{ request.GET.two_factor}}' == 'updated'){
        swal("Success!", "Two factor authentication priority updated", "success")
    }
    else if ('{{ request.GET.update}}' == 'true'){
        swal("Success!", "Profile successfully updated", "success")
    }
    else if ('{{ request.GET.shared}}' == 'shared'){
        swal("Success!", "Successfully changed the doc visibility", "success")
    }
    else if ('{{ request.GET.shared}}' == 'private'){
        swal("Success!", "Doc privacy changed to private", "success")
    }

    if ('{{ request.GET.status}}' == 'ok'){
        swal("Success!", "Request successfully submitted!", "success")
    }
    if ('{{ request.GET.change}}' == 'true'){
        swal("Success!", "Password successfully updated!", "success")
    }
    if ('{{ request.GET.permission}}' == 'false'){
        swal("Error!", "Multichain wallet balance verification failed!", "warning")
    }
    if ('{{ request.GET.file}}' == 'removed'){
        swal("Error!", "Admin removed the file!", "warning")
    }
    if ('{{ request.GET.file}}' == 'changed'){
        swal("Error!", "File has been tampered", "error")
    }
    if ('{{ request.GET.verify}}' == 'False'){
        swal("Success!", "Two factor authentication disabled", "success")
    }
    if ('{{ request.GET.status}}' == 'reject'){
        swal("Success!", "Request Rejected!", "success")
    }
    else if ('{{ request.GET.status}}' == 'grant'){
        swal("Success!", "Access granted!", "success")
    }

//    window.history.replaceState(null, null, window.location.pathname);
});